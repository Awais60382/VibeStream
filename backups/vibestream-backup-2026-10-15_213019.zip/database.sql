-- VibeStream database backup
-- Created: 2026-10-15 21:30:19
-- Database: vibestream

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

-- ----------------------------
-- Table `admin_activity_log`
-- ----------------------------
DROP TABLE IF EXISTS `admin_activity_log`;
CREATE TABLE `admin_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(100) NOT NULL,
  `action` varchar(30) NOT NULL,
  `details` varchar(500) NOT NULL DEFAULT '',
  `page` varchar(100) NOT NULL DEFAULT '',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_time` (`admin_username`,`created_at`),
  KEY `idx_time` (`created_at`),
  KEY `idx_action` (`action`)
) ENGINE=InnoDB AUTO_INCREMENT=332 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('1', 'OwnerHunter', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-11 21:11:08'),
('2', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-11 21:11:08'),
('3', 'OwnerHunter', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-11 21:43:08'),
('4', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-11 21:43:08'),
('5', 'OwnerHunter', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-11 21:44:36'),
('6', 'OwnerHunter', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-11 21:45:29'),
('7', 'OwnerHunter', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-11 21:45:40'),
('8', 'OwnerHunter', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-11 21:45:42'),
('9', 'OwnerHunter', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-11 21:45:48'),
('10', 'OwnerHunter', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-11 21:46:27'),
('11', 'OwnerHunter', 'premium', 'Cancelled Premium for Instant', 'premium.php', '::1', '2026-10-11 21:47:04'),
('12', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 21:47:21'),
('13', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-11 21:52:05'),
('14', 'OwnerHunter', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-11 21:52:07'),
('15', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-11 21:52:11'),
('16', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 21:52:16'),
('17', 'OwnerHunter', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-11 21:52:36'),
('18', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 21:52:44'),
('19', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-11 21:52:47'),
('20', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 21:52:49'),
('21', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 21:52:58'),
('22', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-11 21:53:00'),
('23', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 21:53:02'),
('24', 'OwnerHunter', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-11 21:53:08'),
('25', 'OwnerHunter', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-11 21:53:36'),
('26', 'OwnerHunter', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-11 21:54:23'),
('27', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-11 21:54:28'),
('28', 'OwnerHunter', 'page_view', 'Opened report.php', 'report.php', '::1', '2026-10-11 21:54:47'),
('29', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-11 21:55:35'),
('30', 'OwnerHunter', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-11 21:55:45'),
('31', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-11 21:55:51'),
('32', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 21:55:53'),
('33', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 21:55:58'),
('34', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 21:56:05'),
('35', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 21:56:12'),
('36', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 21:56:20'),
('37', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-11 21:56:23'),
('38', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 21:56:29'),
('39', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 21:56:31'),
('40', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 22:01:06'),
('41', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-11 22:02:10'),
('42', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 22:02:12'),
('43', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 22:02:15'),
('44', 'OwnerHunter', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-11 22:02:16'),
('45', 'OwnerHunter', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-11 22:02:24'),
('46', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 22:02:28'),
('47', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 22:04:33'),
('48', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 22:04:38'),
('49', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 22:05:13'),
('50', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 22:05:44'),
('51', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 22:06:10'),
('52', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 22:06:15'),
('53', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 22:07:55'),
('54', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 22:09:37'),
('55', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 22:11:09'),
('56', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 22:11:14'),
('57', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-11 22:13:01'),
('58', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 22:13:03'),
('59', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 22:13:10'),
('60', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-11 22:13:15'),
('61', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 22:13:19'),
('62', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 22:13:21'),
('63', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-11 22:13:30'),
('64', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 22:13:33'),
('65', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 22:15:44'),
('66', 'OwnerHunter', 'page_view', 'Opened free-name.php', 'free-name.php', '::1', '2026-10-11 22:15:53'),
('67', 'OwnerHunter', 'page_view', 'Opened free-name.php', 'free-name.php', '::1', '2026-10-11 22:19:01'),
('68', 'OwnerHunter', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-11 22:19:04'),
('69', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-11 22:20:01'),
('70', 'OwnerHunter', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-11 22:20:09'),
('71', 'OwnerHunter', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-11 22:20:10'),
('72', 'OwnerHunter', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-11 22:20:12'),
('73', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-11 22:20:14'),
('74', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-11 22:20:15'),
('75', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-11 22:20:17'),
('76', 'OwnerHunter', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-11 22:20:18'),
('77', 'OwnerHunter', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-11 22:20:23'),
('78', 'OwnerHunter', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-11 22:20:29'),
('79', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-11 22:20:31'),
('80', 'OwnerHunter', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-11 22:20:35'),
('81', 'OwnerHunter', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-11 22:20:45'),
('82', 'OwnerHunter', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-11 22:42:33'),
('83', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-11 22:42:40'),
('84', 'OwnerHunter', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-11 22:55:59'),
('85', 'OwnerHunter', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-11 22:58:12'),
('86', 'OwnerHunter', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-11 23:01:41'),
('87', 'OwnerHunter', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-11 23:04:01'),
('88', 'OwnerHunter', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-11 23:04:06'),
('89', 'OwnerHunter', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-11 23:06:13'),
('90', 'OwnerHunter', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-11 23:08:58'),
('91', 'OwnerHunter', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-11 23:09:11'),
('92', 'OwnerHunter', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-11 23:10:07'),
('93', 'OwnerHunter', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-11 23:21:06'),
('94', 'OwnerHunter', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-11 23:22:21'),
('95', 'OwnerHunter', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-11 23:22:52'),
('96', 'OwnerHunter', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-11 23:28:26'),
('97', 'OwnerHunter', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-11 23:30:46'),
('98', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-11 23:58:18'),
('99', 'OwnerHunter', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-11 23:58:26'),
('100', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-11 23:58:30');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('101', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 00:06:48'),
('102', 'OwnerHunter', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-12 00:06:54'),
('103', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 00:59:29'),
('104', 'OwnerHunter', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-12 00:59:33'),
('105', 'OwnerHunter', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-12 01:03:03'),
('106', 'OwnerHunter', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-12 18:18:25'),
('107', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 18:18:25'),
('108', 'OwnerHunter', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-12 18:21:02'),
('109', 'OwnerHunter', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-12 18:21:49'),
('110', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 18:21:49'),
('111', 'OwnerHunter', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-12 18:22:27'),
('112', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 18:22:27'),
('113', 'OwnerHunter', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-12 18:22:28'),
('114', 'OwnerHunter', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-12 18:22:34'),
('115', 'OwnerHunter', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-12 18:32:36'),
('116', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 18:33:56'),
('117', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 18:36:14'),
('118', 'OwnerHunter', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-12 18:48:46'),
('119', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 18:48:46'),
('120', 'OwnerHunter', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-12 18:49:02'),
('121', 'OwnerHunter', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-12 18:49:03'),
('122', 'OwnerHunter', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-12 18:49:04'),
('123', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 18:49:07'),
('124', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 19:03:48'),
('125', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 19:06:49'),
('126', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 19:17:18'),
('127', 'OwnerHunter', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-12 19:18:47'),
('128', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 19:21:05'),
('129', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 19:23:20'),
('130', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 19:30:42'),
('131', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 19:37:15'),
('132', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 19:37:23'),
('133', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 19:39:48'),
('134', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 19:45:11'),
('135', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 19:56:40'),
('136', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:00:46'),
('137', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:03:17'),
('138', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:07:03'),
('139', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:09:45'),
('140', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:12:16'),
('141', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:14:59'),
('142', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:19:01'),
('143', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:21:14'),
('144', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:31:55'),
('145', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:34:16'),
('146', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:37:35'),
('147', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:40:28'),
('148', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:44:21'),
('149', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:46:57'),
('150', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:49:43'),
('151', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:52:01'),
('152', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 20:59:02'),
('153', 'OwnerHunter', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-12 20:59:05'),
('154', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 20:59:12'),
('155', 'OwnerHunter', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-12 21:00:52'),
('156', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 21:00:52'),
('157', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 21:06:54'),
('158', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 21:07:07'),
('159', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 21:09:44'),
('160', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 21:20:48'),
('161', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 21:20:56'),
('162', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 21:23:38'),
('163', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 21:26:15'),
('164', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 21:26:19'),
('165', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 21:29:23'),
('166', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 21:31:28'),
('167', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 21:34:10'),
('168', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 21:36:35'),
('169', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 21:37:47'),
('170', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 21:43:42'),
('171', 'OwnerHunter', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-12 22:03:10'),
('172', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 22:03:10'),
('173', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-12 22:03:24'),
('174', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-12 22:03:29'),
('175', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-12 22:03:31'),
('176', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-12 22:03:42'),
('177', 'OwnerHunter', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-12 22:03:49'),
('178', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-12 22:03:50'),
('179', 'OwnerHunter', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-12 22:04:12'),
('180', 'OwnerHunter', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-12 22:05:42'),
('181', 'OwnerHunter', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-12 22:09:06'),
('182', 'OwnerHunter', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-12 22:09:18'),
('183', 'OwnerHunter', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-12 22:13:40'),
('184', 'OwnerHunter', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-12 22:20:24'),
('185', 'OwnerHunter', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-12 22:20:58'),
('186', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-12 22:21:11'),
('187', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-12 22:27:48'),
('188', 'OwnerHunter', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-12 22:27:50'),
('189', 'OwnerHunter', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-12 23:06:37'),
('190', 'OwnerHunter', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-13 19:00:01'),
('191', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-13 19:00:01'),
('192', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-13 19:12:59'),
('193', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 19:13:15'),
('194', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 19:16:32'),
('195', 'OwnerHunter', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-13 19:18:37'),
('196', 'OwnerHunter', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-13 19:18:43'),
('197', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 19:19:00'),
('198', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 19:22:17'),
('199', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 19:25:28'),
('200', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 19:30:12');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('201', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 19:34:33'),
('202', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 19:38:15'),
('203', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 19:41:50'),
('204', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 19:44:15'),
('205', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 19:46:40'),
('206', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-13 20:00:18'),
('207', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 20:00:27'),
('208', 'OwnerHunter', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-13 20:06:39'),
('209', 'Muhammad_Awais_9585bc8a', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-13 20:06:57'),
('210', 'Muhammad_Awais_9585bc8a', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-13 20:06:57'),
('211', 'Muhammad_Awais_9585bc8a', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-13 20:21:20'),
('212', 'Muhammad_Awais_9585bc8a', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 20:21:23'),
('213', 'OwnerHunter', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-13 20:21:53'),
('214', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-13 20:21:53'),
('215', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 20:21:58'),
('216', 'Muhammad_Awais_9585bc8a', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-13 20:22:27'),
('217', 'Muhammad_Awais_9585bc8a', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-13 20:22:27'),
('218', 'Muhammad_Awais_9585bc8a', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 20:22:30'),
('219', 'OwnerHunter', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-13 20:22:52'),
('220', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-13 20:22:52'),
('221', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-13 20:22:56'),
('222', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-13 20:23:16'),
('223', 'OwnerHunter', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-13 20:23:22'),
('224', 'OwnerHunter', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-13 20:23:28'),
('225', 'OwnerHunter', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-13 20:25:20'),
('226', 'OwnerHunter', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-13 20:25:24'),
('227', 'OwnerHunter', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-13 20:25:54'),
('228', 'OwnerHunter', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-14 18:47:44'),
('229', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 18:47:44'),
('230', 'OwnerHunter', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-14 18:48:06'),
('231', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-14 18:48:22'),
('232', 'OwnerHunter', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-14 18:53:22'),
('233', 'OwnerHunter', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-14 18:55:29'),
('234', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 18:56:27'),
('235', 'OwnerHunter', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-14 18:56:32'),
('236', 'OwnerHunter', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-14 18:56:44'),
('237', 'OwnerHunter', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 18:58:06'),
('238', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 19:00:08'),
('239', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-14 19:00:11'),
('240', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-14 19:00:17'),
('241', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 19:00:58'),
('242', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-14 19:01:15'),
('243', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-14 19:01:21'),
('244', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-14 19:01:27'),
('245', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-14 19:01:30'),
('246', 'VibeStream', 'page_view', 'Opened free-name.php', 'free-name.php', '::1', '2026-10-14 19:01:34'),
('247', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-14 19:02:03'),
('248', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-14 19:02:07'),
('249', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-14 19:02:19'),
('250', 'VibeStream', 'page_view', 'Opened free-name.php', 'free-name.php', '::1', '2026-10-14 19:02:21'),
('251', 'VibeStream', 'page_view', 'Opened free-name.php', 'free-name.php', '::1', '2026-10-14 19:05:50'),
('252', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-14 19:06:43'),
('253', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-14 19:06:46'),
('254', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 19:17:41'),
('255', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-14 19:18:00'),
('256', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-14 19:18:03'),
('257', 'VibeStream', 'page_view', 'Opened free-name.php', 'free-name.php', '::1', '2026-10-14 19:18:07'),
('258', 'VibeStream', 'page_view', 'Opened free-name.php', 'free-name.php', '::1', '2026-10-14 19:20:49'),
('259', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-14 19:20:53'),
('260', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-14 19:21:12'),
('261', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-14 19:22:13'),
('262', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-14 19:26:01'),
('263', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 19:29:36'),
('264', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-14 19:33:35'),
('265', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-14 19:33:45'),
('266', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-14 19:33:48'),
('267', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-14 19:33:59'),
('268', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-14 19:39:32'),
('269', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 19:39:43'),
('270', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 19:43:16'),
('271', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 19:49:25'),
('272', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-14 19:49:41'),
('273', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 19:49:44'),
('274', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 19:52:29'),
('275', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 19:59:36'),
('276', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 20:02:19'),
('277', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-14 20:03:32'),
('278', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-14 20:17:09'),
('279', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 20:17:14'),
('280', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 20:25:44'),
('281', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-14 20:25:46'),
('282', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-14 20:25:49'),
('283', 'VibeStream', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-14 20:25:50'),
('284', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-14 20:25:51'),
('285', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-14 20:25:56'),
('286', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-14 20:26:06'),
('287', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-14 20:26:16'),
('288', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-14 20:26:31'),
('289', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-14 20:40:00'),
('290', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-14 20:44:20'),
('291', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-14 20:44:49'),
('292', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-14 20:55:39'),
('293', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 20:55:43'),
('294', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 20:57:48'),
('295', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-14 23:46:20'),
('296', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 23:46:20'),
('297', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-14 23:46:27'),
('298', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 23:50:10'),
('299', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-14 23:52:27'),
('300', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-15 23:19:00');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('301', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-15 23:19:00'),
('302', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-15 23:24:02'),
('303', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-15 23:24:29'),
('304', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-15 23:37:21'),
('305', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-15 23:46:11'),
('306', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-15 23:46:11'),
('307', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-15 23:53:37'),
('308', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-15 23:53:42'),
('309', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-15 23:53:49'),
('310', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-15 23:53:58'),
('311', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-15 23:54:05'),
('312', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-15 23:54:15'),
('313', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-15 23:54:17'),
('314', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-15 23:56:37'),
('315', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-15 23:56:44'),
('316', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-15 23:56:46'),
('317', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-16 00:07:22'),
('318', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-16 00:07:31'),
('319', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-16 00:07:50'),
('320', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-16 00:12:31'),
('321', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-16 00:12:40'),
('322', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-16 00:12:52'),
('323', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-16 00:13:01'),
('324', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-16 00:16:04'),
('325', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-16 00:16:09'),
('326', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-16 00:17:00'),
('327', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-16 00:19:57'),
('328', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-16 00:20:18'),
('329', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-16 00:23:56'),
('330', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-16 00:27:49'),
('331', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-16 00:29:57');

-- ----------------------------
-- Table `admin_group_members`
-- ----------------------------
DROP TABLE IF EXISTS `admin_group_members`;
CREATE TABLE `admin_group_members` (
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_read_id` int(11) NOT NULL DEFAULT 0,
  `joined_at` datetime NOT NULL,
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_group_members` (`group_id`, `user_id`, `last_read_id`, `joined_at`) VALUES
('1', '10', '0', '2026-10-11 21:53:25'),
('1', '11', '0', '2026-10-11 21:53:25'),
('1', '15', '0', '2026-10-11 21:53:25');

-- ----------------------------
-- Table `admin_group_messages`
-- ----------------------------
DROP TABLE IF EXISTS `admin_group_messages`;
CREATE TABLE `admin_group_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `sender_name` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `created_at` datetime NOT NULL,
  `edited_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_group` (`group_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `admin_groups`
-- ----------------------------
DROP TABLE IF EXISTS `admin_groups`;
CREATE TABLE `admin_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_groups` (`id`, `name`, `created_by`, `created_at`) VALUES
('1', 'WHY', '10', '2026-10-11 21:53:25');

-- ----------------------------
-- Table `admin_messages`
-- ----------------------------
DROP TABLE IF EXISTS `admin_messages`;
CREATE TABLE `admin_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `edited_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_messages_inbox` (`recipient_id`,`is_read`),
  KEY `idx_admin_messages_pair` (`sender_id`,`recipient_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_messages` (`id`, `sender_id`, `recipient_id`, `body`, `is_read`, `created_at`, `edited_at`) VALUES
('1', '1', '7', 'hi wsp', '0', '2026-10-08 01:37:57', NULL),
('2', '1', '7', 'hi', '0', '2026-10-08 19:10:48', NULL),
('3', '1', '8', 'hi', '0', '2026-10-08 19:11:20', NULL);

-- ----------------------------
-- Table `channel_profiles`
-- ----------------------------
DROP TABLE IF EXISTS `channel_profiles`;
CREATE TABLE `channel_profiles` (
  `username` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL DEFAULT '',
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `channel_profiles` (`username`, `description`, `updated_at`) VALUES
('VibeStream', 'This is the offical VibeStream Channel', '2026-10-14 18:58:49');

-- ----------------------------
-- Table `comment_votes`
-- ----------------------------
DROP TABLE IF EXISTS `comment_votes`;
CREATE TABLE `comment_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `vote` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_comment_votes_comment_user` (`comment_id`,`username`),
  KEY `idx_comment_votes_comment` (`comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `comment_votes` (`id`, `comment_id`, `username`, `vote`, `created_at`) VALUES
('1', '29', 'deleted_c6849d61', '-1', '2026-10-10 01:30:28');

-- ----------------------------
-- Table `comments`
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `comment_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `hearted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `comments` (`id`, `video_id`, `username`, `comment_text`, `created_at`, `hearted`) VALUES
('34', '-4BzpL7pcnj', 'VibeStream', 'gg', '2026-10-11 03:19:10', '0');

-- ----------------------------
-- Table `content_reports`
-- ----------------------------
DROP TABLE IF EXISTS `content_reports`;
CREATE TABLE `content_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_table` varchar(20) NOT NULL,
  `content_id` varchar(64) NOT NULL,
  `content_type` varchar(10) NOT NULL,
  `reason` varchar(30) NOT NULL,
  `details` varchar(500) NOT NULL DEFAULT '',
  `reporter` varchar(100) NOT NULL,
  `status` varchar(12) NOT NULL DEFAULT 'open',
  `created_at` datetime NOT NULL,
  `reviewed_by` varchar(100) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `one_report_per_user` (`content_table`,`content_id`,`reporter`),
  KEY `status_idx` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `content_reports` (`id`, `content_table`, `content_id`, `content_type`, `reason`, `details`, `reporter`, `status`, `created_at`, `reviewed_by`, `reviewed_at`) VALUES
('1', 'videos', 'TQ671jx2LHK', 'video', 'other', 'testing', 'OwnerHunter', 'dismissed', '2026-10-11 21:59:24', 'OwnerHunter', '2026-10-11 21:59:45'),
('2', 'videos', 'rqcUKdldcNy', 'short', 'other', 'testing', 'OwnerHunter', 'removed', '2026-10-12 19:27:05', 'OwnerHunter', '2026-10-12 19:28:36');

-- ----------------------------
-- Table `owner_notices`
-- ----------------------------
DROP TABLE IF EXISTS `owner_notices`;
CREATE TABLE `owner_notices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `from_name` varchar(100) NOT NULL DEFAULT '',
  `to_id` int(11) NOT NULL,
  `to_name` varchar(100) NOT NULL DEFAULT '',
  `body` varchar(1000) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'sent',
  `seen_at` datetime DEFAULT NULL,
  `done_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_to` (`to_id`,`status`),
  KEY `idx_from` (`from_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `owner_notices` (`id`, `from_id`, `from_name`, `to_id`, `to_name`, `body`, `status`, `seen_at`, `done_at`, `created_at`) VALUES
('1', '14', 'VibeStream', '11', 'Instant', 'why u offline?', 'sent', NULL, NULL, '2026-10-14 19:34:12'),
('2', '14', 'VibeStream', '11', 'Instant', 'why u offline?', 'sent', NULL, NULL, '2026-10-14 19:39:23');

-- ----------------------------
-- Table `premium_end_alerts`
-- ----------------------------
DROP TABLE IF EXISTS `premium_end_alerts`;
CREATE TABLE `premium_end_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `plan` varchar(10) NOT NULL,
  `started_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `ended_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `seen_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_period` (`username`,`started_at`,`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=438 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `premium_end_alerts` (`id`, `username`, `plan`, `started_at`, `expires_at`, `ended_at`, `created_at`, `seen_at`) VALUES
('1', 'aqsa', 'monthly', '2026-10-11 19:23:52', '2026-11-11 19:23:52', '2026-10-11 19:24:12', '2026-10-11 19:55:47', '2026-10-11 19:58:50'),
('2', 'Instant', 'monthly', '2026-10-11 19:24:01', '2026-11-11 19:24:01', '2026-10-11 19:24:07', '2026-10-11 19:55:47', '2026-10-11 19:58:50'),
('25', 'Instant', 'daily', '2026-10-11 19:59:11', '2026-10-12 19:59:11', '2026-10-11 21:47:04', '2026-10-11 21:47:04', '2026-10-11 21:47:13');

-- ----------------------------
-- Table `premium_members`
-- ----------------------------
DROP TABLE IF EXISTS `premium_members`;
CREATE TABLE `premium_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `plan` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'active',
  `started_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `premium_members` (`id`, `username`, `plan`, `status`, `started_at`, `expires_at`, `updated_at`) VALUES
('3', 'VibeStream', 'yearly', 'active', '2026-10-11 01:37:10', '2027-10-12 01:37:10', '2026-10-11 01:37:10');

-- ----------------------------
-- Table `premium_requests`
-- ----------------------------
DROP TABLE IF EXISTS `premium_requests`;
CREATE TABLE `premium_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `plan` varchar(10) NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `txn_ref` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_txn_ref` (`txn_ref`),
  KEY `idx_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `subscription_seen`
-- ----------------------------
DROP TABLE IF EXISTS `subscription_seen`;
CREATE TABLE `subscription_seen` (
  `user_id` int(11) NOT NULL,
  `channel_key` varchar(191) NOT NULL,
  `seen_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`channel_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
-- Table `user_notification_prefs`
-- ----------------------------
DROP TABLE IF EXISTS `user_notification_prefs`;
CREATE TABLE `user_notification_prefs` (
  `user_id` int(11) NOT NULL,
  `uploads` tinyint(1) NOT NULL DEFAULT 1,
  `comments` tinyint(1) NOT NULL DEFAULT 1,
  `likes` tinyint(1) NOT NULL DEFAULT 1,
  `subscribers` tinyint(1) NOT NULL DEFAULT 1,
  `desktop_notifs` tinyint(1) NOT NULL DEFAULT 0,
  `subscriptions` tinyint(1) NOT NULL DEFAULT 1,
  `recommended` tinyint(1) NOT NULL DEFAULT 1,
  `channel_activity` tinyint(1) NOT NULL DEFAULT 1,
  `comment_activity` tinyint(1) NOT NULL DEFAULT 1,
  `mentions` tinyint(1) NOT NULL DEFAULT 1,
  `content_reuse` tinyint(1) NOT NULL DEFAULT 1,
  `promotions` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_notification_prefs` (`user_id`, `uploads`, `comments`, `likes`, `subscribers`, `desktop_notifs`, `subscriptions`, `recommended`, `channel_activity`, `comment_activity`, `mentions`, `content_reuse`, `promotions`) VALUES
('9', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '1', '0'),
('14', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0');

-- ----------------------------
-- Table `user_notifications`
-- ----------------------------
DROP TABLE IF EXISTS `user_notifications`;
CREATE TABLE `user_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'upload',
  `channel_name` varchar(255) NOT NULL DEFAULT '',
  `actor` varchar(255) NOT NULL DEFAULT '',
  `video_id` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `message` varchar(500) NOT NULL DEFAULT '',
  `link` varchar(500) NOT NULL DEFAULT '',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_notifications_user` (`user_id`,`is_read`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_notifications` (`id`, `user_id`, `type`, `channel_name`, `actor`, `video_id`, `title`, `message`, `link`, `is_read`, `created_at`) VALUES
('4', '9', 'like', 'aqsa', 'aqsa', '6nvdR8clMIk', 'Eat Everything In A Grocery Store, Win $1,000,000', 'aqsa liked your video: Eat Everything In A Grocery Store, Win $1,000,000', 'watch.php?id=6nvdR8clMIk', '0', '2026-10-10 01:38:03'),
('7', '1', 'comment', 'Instant', 'Instant', 'IFUtsXdwk-A', 'Clean Transformation 🔥 | One Piece EP 1001 👒 | #onepiece #luffy', 'Instant commented on your short: \"gg\"', 'shorts.php?id=IFUtsXdwk-A', '1', '2026-10-10 12:35:27'),
('8', '11', 'like', 'VibeStream', 'OwnerHunter', 'aNsGJAzNt0h', '$10,000 Every Day You Survive In The Wilderness', 'OwnerHunter liked your video: $10,000 Every Day You Survive In The Wilderness', 'watch.php?id=aNsGJAzNt0h', '0', '2026-10-11 02:57:06'),
('9', '10', 'comment', 'VibeStream', 'OwnerHunter', '-4BzpL7pcnj', 'Even Gods Like Ice cream 😭', 'OwnerHunter commented on your short: \"gg\"', 'shorts.php?id=-4BzpL7pcnj', '0', '2026-10-11 03:19:10'),
('10', '14', 'video', 'deleted_15', 'Muhammad_Awais_9585bc8a', '5nFGnsSBkXN', 'I Gave People $1,000,000 But ONLY 1 Minute To Spend It!', 'Muhammad_Awais_9585bc8a uploaded a new video: I Gave People $1,000,000 But ONLY 1 Minute To Spend It!', 'watch.php?id=5nFGnsSBkXN', '1', '2026-10-11 21:42:14'),
('11', '10', 'like', 'VibeStream', 'OwnerHunter', 'MO1j8vJHKNl', 'Making a song in the style of…', 'OwnerHunter liked your short: Making a song in the style of…', 'shorts.php?id=MO1j8vJHKNl', '0', '2026-10-12 22:24:03'),
('13', '10', 'comment', 'VibeStream', 'OwnerHunter', 'MO1j8vJHKNl', 'Making a song in the style of…', 'OwnerHunter commented on your short: \"@OwnerHunter gg\"', 'shorts.php?id=MO1j8vJHKNl', '0', '2026-10-12 22:24:20'),
('14', '10', 'like', 'VibeStream', 'OwnerHunter', '-4BzpL7pcnj', 'Even Gods Like Ice cream 😭', 'OwnerHunter liked your short: Even Gods Like Ice cream 😭', 'shorts.php?id=-4BzpL7pcnj', '0', '2026-10-12 22:26:07'),
('15', '10', 'like', 'VibeStream', 'OwnerHunter', '4ZLZUhJHbW0', 'Bot\'s😭 #roblox #bloxfurit #bloxfruits #shorts', 'OwnerHunter liked your short: Bot\'s😭 #roblox #bloxfurit #bloxfruits #shorts', 'shorts.php?id=4ZLZUhJHbW0', '0', '2026-10-12 22:26:11'),
('16', '10', 'like', 'VibeStream', 'OwnerHunter', '5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', 'OwnerHunter liked your short: Goku Gets A New Outfit From Whis!', 'shorts.php?id=5ABfNhJvTTs', '0', '2026-10-12 22:26:15'),
('17', '15', 'like', 'VibeStream', 'OwnerHunter', 'gXeE57uu-Kw', 'Ranking the most beautiful violin sounds moment 🎶✨ #sehar', 'OwnerHunter liked your short: Ranking the most beautiful violin sounds moment 🎶✨ #sehar', 'shorts.php?id=gXeE57uu-Kw', '1', '2026-10-12 22:26:18'),
('18', '15', 'subscriber', 'VibeStream', 'OwnerHunter', '', '', 'OwnerHunter subscribed to your channel', 'profile.php?u=OwnerHunter', '1', '2026-10-12 23:25:43'),
('19', '11', 'notice', 'VibeStream', 'VibeStream', '', 'Owner notice', 'VibeStream sent you a notice: why u offline?', 'adminpanel/owner-notices.php?id=1', '0', '2026-10-14 19:34:12'),
('20', '11', 'notice', 'VibeStream', 'VibeStream', '', 'Owner notice', 'VibeStream sent you a notice: why u offline?', 'adminpanel/owner-notices.php?id=2', '0', '2026-10-14 19:39:23');

-- ----------------------------
-- Table `user_subscriptions`
-- ----------------------------
DROP TABLE IF EXISTS `user_subscriptions`;
CREATE TABLE `user_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` int(11) NOT NULL,
  `channel_name` varchar(255) NOT NULL,
  `channel_username` varchar(50) NOT NULL DEFAULT '',
  `channel_key` char(64) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_subscriptions_subscriber_channel` (`subscriber_id`,`channel_key`),
  KEY `idx_user_subscriptions_channel` (`channel_username`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_subscriptions` (`id`, `subscriber_id`, `channel_name`, `channel_username`, `channel_key`, `created_at`) VALUES
('14', '9', 'AdminAwais', 'AdminAwais', '2e4f1de113181fa1246dd7a3a32e8da22d3288ff2d77aff58bb7fe935c055cb5', '2026-10-10 01:32:38'),
('15', '10', 'deleted_c6849d61', 'awais', '911f313901d83fa1036e05d22837952420afdf721f25de64333dd9030a0e9062', '2026-10-10 01:38:01'),
('16', '11', 'AdminAwais', 'AdminAwais', '2e4f1de113181fa1246dd7a3a32e8da22d3288ff2d77aff58bb7fe935c055cb5', '2026-10-10 12:34:08'),
('17', '11', 'admin', 'admin', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', '2026-10-10 12:36:46'),
('18', '11', 'aqsa', 'aqsa', '53be87fd1a0d505db2677c206f8d7ed80814577cb56ea1f1eba9833092a17a98', '2026-10-10 12:36:57'),
('19', '11', 'deleted_c6849d61', 'awais', '911f313901d83fa1036e05d22837952420afdf721f25de64333dd9030a0e9062', '2026-10-10 12:37:10'),
('21', '15', 'deleted_c6849d61', 'awais', '911f313901d83fa1036e05d22837952420afdf721f25de64333dd9030a0e9062', '2026-10-11 21:10:34'),
('23', '15', 'VibeStream', 'OwnerHunter', 'bc64c51161839bb85975db95313394134eb1cbbbcc99a92f5b2a004196148d99', '2026-10-11 21:42:38');

-- ----------------------------
-- Table `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_active` datetime DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`, `last_active`, `password_changed_at`, `avatar`) VALUES
('10', 'aqsa', 'aqsa@gmail.com', '$2y$10$pHyTDaecRwOrYPkMc/ejGeMs1ELR02QqHf03IZTeQKtFJ4LEAMIzK', 'user', '2026-10-10 01:37:31', NULL, NULL, NULL),
('11', 'Instant', 'instant@gmail.com', '$2y$10$Yl4uMVerNyJq3a0xLZiSWuMj/lv6lBs/CJ7DDGdv5PffyrPNLjuUC', 'Admin', '2026-10-10 12:12:50', NULL, NULL, NULL),
('14', 'VibeStream', 'muhammadawaiscom0@gmail.com', '$2y$10$rcPb3R6guj72FjfQzyqbTeJsbXYmiPpP9DgajFzPsniBu4zwKiV5i', 'Admin', '2026-10-11 00:56:58', '2026-10-16 00:30:13', NULL, 'uploads/avatars/dd30e8310a106b73d2c444627cf4f15e.png');

-- ----------------------------
-- Table `video_comments`
-- ----------------------------
DROP TABLE IF EXISTS `video_comments`;
CREATE TABLE `video_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `comment_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `video_likes`
-- ----------------------------
DROP TABLE IF EXISTS `video_likes`;
CREATE TABLE `video_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_like` (`video_id`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `videos`
-- ----------------------------
DROP TABLE IF EXISTS `videos`;
CREATE TABLE `videos` (
  `id` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `views` int(11) DEFAULT 0,
  `type` varchar(20) DEFAULT 'video',
  `username` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `likes` int(11) DEFAULT 0,
  `subscribers` int(11) DEFAULT 0,
  `channel_name` varchar(255) NOT NULL,
  `video_url` varchar(500) NOT NULL,
  `dislikes` int(11) NOT NULL DEFAULT 0,
  `category` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `videos` (`id`, `title`, `views`, `type`, `username`, `created_at`, `likes`, `subscribers`, `channel_name`, `video_url`, `dislikes`, `category`) VALUES
('-4BzpL7pcnj', 'Even Gods Like Ice cream 😭', '8', 'short', 'aqsa', '2026-10-09 22:50:48', '2', '1', 'aqsa', 'https://www.youtube.com/watch?v=jZCxYTKi_EM', '0', 'anime'),
('4ZLZUhJHbW0', 'Bot\'s😭 #roblox #bloxfurit #bloxfruits #shorts', '6', 'short', 'aqsa', '2026-10-09 22:52:32', '1', '1', 'aqsa', 'https://www.youtube.com/watch?v=0Y_pDZItZgw', '0', 'gaming'),
('5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', '11', 'short', 'aqsa', '2026-10-09 22:55:21', '3', '1', 'aqsa', 'https://www.youtube.com/watch?v=46yZdMybV6A', '0', 'anime'),
('6lrPGbgxpQr', 'DOFFY FACE LUFFY NEW MOVE 👿🔥', '4', 'short', 'VibeStream', '2026-10-11 18:11:56', '2', '1', 'VibeStream', 'https://www.youtube.com/watch?v=7sSoXWCGKXc', '0', 'anime'),
('aNsGJAzNt0h', '$10,000 Every Day You Survive In The Wilderness', '2', 'video', 'Instant', '2026-10-10 09:14:38', '1', '0', 'Instant', 'https://www.youtube.com/watch?v=U_LlX4t0A9I', '0', 'travel'),
('BhAczqf1ci9', '30 Celebrities Fight For $1,000,000!', '0', 'video', 'VibeStream', '2026-10-11 18:30:31', '0', '1', 'VibeStream', 'https://www.youtube.com/watch?v=QJI0an6irrA', '0', 'gaming'),
('MKLKE72odDM', 'We Survived Every Places On Earth !', '1', 'video', 'Instant', '2026-10-10 09:16:43', '0', '0', 'Instant', 'https://www.youtube.com/watch?v=JwMJkOt__yg', '0', 'fun'),
('MO1j8vJHKNl', 'Making a song in the style of…', '9', 'short', 'aqsa', '2026-10-09 22:39:54', '1', '1', 'aqsa', 'https://www.youtube.com/watch?v=WFXPeguh3lk', '0', 'music'),
('MUiqU20kGZ5', 'Is Charging While Using Your Phone Killing the Battery?', '2', 'video', 'VibeStream', '2026-10-11 18:40:29', '0', '1', 'VibeStream', 'https://www.youtube.com/watch?v=Lj4LMlGr4og', '0', 'facts'),
('nuTUjH70f8g', 'Microsoft Showed Me Their Secret Phone Five Years Ago.', '0', 'video', 'VibeStream', '2026-10-11 18:19:06', '0', '1', 'VibeStream', 'https://www.youtube.com/watch?v=RxW7PXKkztQ', '0', 'facts'),
('RUP0hxEsgBl', '$10,000 Every Day You Survive In Minecraft', '1', 'video', 'VibeStream', '2026-10-11 18:33:54', '0', '1', 'VibeStream', 'https://www.youtube.com/watch?v=h8VE9_aHd94', '0', 'gaming'),
('t2M0CYUpLF8', 'Survive 100 Days Trapped, Win $500,000', '6', 'video', 'Instant', '2026-10-10 09:16:09', '0', '0', 'Instant', 'https://www.youtube.com/watch?v=9RhWXPcKBI8', '0', 'gaming'),
('TQ671jx2LHK', 'I Survived 100 Days on One Block', '12', 'video', 'Instant', '2026-10-10 09:13:49', '0', '0', 'Instant', 'https://www.youtube.com/watch?v=kJu5VMN3yow', '0', 'gaming');

-- ----------------------------
-- Table `vs_comment_votes`
-- ----------------------------
DROP TABLE IF EXISTS `vs_comment_votes`;
CREATE TABLE `vs_comment_votes` (
  `comment_id` bigint(20) unsigned NOT NULL,
  `voter` varchar(191) NOT NULL,
  `vote` tinyint(4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`comment_id`,`voter`),
  KEY `idx_vs_comment_votes_voter` (`voter`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `vs_comment_votes` (`comment_id`, `voter`, `vote`, `created_at`) VALUES
('28', 'adminawais', '1', '2026-10-10 12:44:31'),
('31', 'adminawais', '1', '2026-10-10 12:44:29'),
('32', 'adminawais', '1', '2026-10-10 12:44:28'),
('33', 'adminawais', '1', '2026-10-10 12:44:27'),
('33', 'instant', '-1', '2026-10-10 12:36:21');

-- ----------------------------
-- Table `watch_history`
-- ----------------------------
DROP TABLE IF EXISTS `watch_history`;
CREATE TABLE `watch_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `video_id` varchar(64) NOT NULL,
  `watched_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_watch_history_user_video` (`user_id`,`video_id`),
  KEY `idx_watch_history_user_time` (`user_id`,`watched_at`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `watch_history` (`id`, `user_id`, `video_id`, `watched_at`) VALUES
('2', '9', 'rqcUKdldcNy', '2026-10-10 01:32:42'),
('3', '9', 'IFUtsXdwk-A', '2026-10-10 01:23:20'),
('4', '9', 'M5es7CsVsak', '2026-10-10 01:32:35'),
('6', '9', '6nvdR8clMIk', '2026-10-10 01:31:46'),
('9', '10', '6nvdR8clMIk', '2026-10-10 01:38:00'),
('10', '10', 'IFUtsXdwk-A', '2026-10-10 01:39:57'),
('30', '1', 'IFUtsXdwk-A', '2026-10-10 12:44:02'),
('31', '12', 'BHZcLwxyeM', '2026-10-10 14:03:57'),
('32', '12', 'rqcUKdldcNy', '2026-10-10 14:03:58'),
('33', '12', 'MO1j8vJHKNl', '2026-10-10 14:03:59'),
('34', '12', '-4BzpL7pcnj', '2026-10-10 14:03:59'),
('35', '12', '4ZLZUhJHbW0', '2026-10-10 14:03:56'),
('36', '12', '5ABfNhJvTTs', '2026-10-10 14:03:56'),
('41', '12', 'TQ671jx2LHK', '2026-10-11 00:25:50'),
('59', '15', 'gXeE57uu-Kw', '2026-10-11 21:10:46'),
('60', '15', 'rqcUKdldcNy', '2026-10-11 21:10:50'),
('61', '15', 'MO1j8vJHKNl', '2026-10-11 21:10:50'),
('62', '15', '-4BzpL7pcnj', '2026-10-11 21:10:50'),
('63', '15', '4ZLZUhJHbW0', '2026-10-11 21:10:51'),
('64', '15', '5ABfNhJvTTs', '2026-10-11 21:10:51'),
('73', '15', '6lrPGbgxpQr', '2026-10-11 21:42:34'),
('86', '14', 'rqcUKdldcNy', '2026-10-12 22:28:27'),
('87', '14', 'MUiqU20kGZ5', '2026-10-13 20:00:08');

-- ----------------------------
-- Table `watch_history_prefs`
-- ----------------------------
DROP TABLE IF EXISTS `watch_history_prefs`;
CREATE TABLE `watch_history_prefs` (
  `user_id` int(11) NOT NULL,
  `paused` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `watch_history_prefs` (`user_id`, `paused`) VALUES
('14', '0');

-- ----------------------------
-- Triggers
-- ----------------------------
DELIMITER $$
DROP TRIGGER IF EXISTS `vs_users_lock_insert`$$
CREATE TRIGGER vs_users_lock_insert BEFORE INSERT ON `users` FOR EACH ROW
                 BEGIN
                   IF LOWER(TRIM(NEW.`email`)) = 'muhammadawaiscom0@gmail.com' THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'That email belongs to the owner.';
                   END IF;
                 END$$
DROP TRIGGER IF EXISTS `vs_users_lock_update`$$
CREATE TRIGGER vs_users_lock_update BEFORE UPDATE ON `users` FOR EACH ROW
                 BEGIN
                   IF OLD.`id` = '14' AND (COALESCE(LOWER(TRIM(NEW.`role`)), '') <> 'admin' OR COALESCE(LOWER(TRIM(NEW.`email`)), '') <> 'muhammadawaiscom0@gmail.com') THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The owner account cannot be changed this way.';
                   END IF;
                   IF OLD.`id` <> '14' AND LOWER(TRIM(NEW.`email`)) = 'muhammadawaiscom0@gmail.com' THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'That email belongs to the owner.';
                   END IF;
                   IF LOWER(TRIM(OLD.`role`)) = 'admin' AND COALESCE(LOWER(TRIM(NEW.`role`)), '') <> 'admin' AND COALESCE(@vs_owner_ok, 0) <> 1 THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only the owner can remove admin access.';
                   END IF;
                 END$$
DROP TRIGGER IF EXISTS `vs_users_lock_delete`$$
CREATE TRIGGER vs_users_lock_delete BEFORE DELETE ON `users` FOR EACH ROW
                 BEGIN
                   IF OLD.`id` = '14' THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The owner account cannot be deleted.';
                   END IF;
                   IF LOWER(TRIM(OLD.`role`)) = 'admin' AND COALESCE(@vs_owner_ok, 0) <> 1 THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only the owner can delete admin accounts.';
                   END IF;
                 END$$
DELIMITER ;

SET FOREIGN_KEY_CHECKS=1;
-- End of backup
