<?php
return array (
  'logo' => 'uploads/site-branding/9e162a19207a6d23e15fed22c4719a37.png',
  'app_name' => 'VibeStreams',
  'app_description' => 'Discover, watch, and share videos on VibeStream.',
  'default_theme' => 'dark',
  'notification' => 
  array (
    'message' => 'The site logo was updated by OwnerHunter.',
    'created_at' => '2026-10-12T15:36:13+02:00',
    'read_by' => 
    array (
      0 => 'id:14',
      1 => 'id:15',
    ),
  ),
  'uploads_enabled' => true,
  'max_upload_mb' => 200,
  'maintenance_enabled' => false,
  'maintenance_message' => 'VibeStream is down of some errors maintenance break. Please check back soon.',
  'categories' => 
  array (
    0 => 'Music',
    1 => 'Gaming',
    2 => 'Movies',
    3 => 'Live',
    4 => 'Sports',
    5 => 'News',
    6 => 'Fashion',
    7 => 'Education',
    8 => 'Anime',
  ),
  'category_colors' => 
  array (
    'music' => '#8b5cf6',
    'gaming' => '#f59e0b',
    'facts' => '#7c3aed',
    'movies' => '#ef4444',
    'live' => '#ec4899',
    'sports' => '#10b981',
    'news' => '#3b82f6',
    'fashion' => '#d946ef',
    'education' => '#0ea5e9',
    'anime' => '#f43f5e',
    'comedy' => '#f97316',
    'food' => '#84cc16',
    'travel' => '#14b8a6',
    'tech' => '#6366f1',
    'cars' => '#64748b',
    'animals' => '#a16207',
    'art' => '#c026d3',
    'fun' => '#f59e0b',
  ),
  'admin_logo' => NULL,
);
