-- VibeStream database backup
-- Created: 2026-11-04 05:56:14
-- Database: vibestream

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

-- ----------------------------
-- Table `admin_activity_log`
-- ----------------------------
DROP TABLE IF EXISTS `admin_activity_log`;
CREATE TABLE `admin_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(100) NOT NULL,
  `action` varchar(30) NOT NULL,
  `details` varchar(500) NOT NULL DEFAULT '',
  `page` varchar(100) NOT NULL DEFAULT '',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_time` (`admin_username`,`created_at`),
  KEY `idx_time` (`created_at`),
  KEY `idx_action` (`action`)
) ENGINE=InnoDB AUTO_INCREMENT=1598 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('1149', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-27 21:26:16'),
('1150', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 21:26:16'),
('1151', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 21:28:19'),
('1152', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 21:28:43'),
('1153', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 21:28:47'),
('1154', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 21:28:48'),
('1155', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 21:28:49'),
('1156', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-27 21:35:09'),
('1157', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 21:35:23'),
('1158', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-27 21:35:28'),
('1159', 'VibeStream', 'user', 'Set the title of \"MuhammadAwais\" to CEO', 'user_profile.php', '::1', '2026-10-27 21:35:37'),
('1160', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 21:35:54'),
('1161', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-27 21:36:05'),
('1162', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 21:56:02'),
('1163', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 21:56:15'),
('1164', 'VibeStream', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-27 21:57:11'),
('1165', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:00:58'),
('1166', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 22:02:08'),
('1167', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 22:02:10'),
('1168', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 22:02:11'),
('1169', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 22:02:11'),
('1170', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 22:02:12'),
('1171', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:05:30'),
('1172', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:07:56'),
('1173', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:31:08'),
('1174', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 22:33:19'),
('1175', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 22:33:20'),
('1176', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 22:33:22'),
('1177', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:33:23'),
('1178', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:37:22'),
('1179', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 22:38:00'),
('1180', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 22:38:12'),
('1181', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 22:38:13'),
('1182', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 22:38:15'),
('1183', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-27 22:38:18'),
('1184', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-27 22:39:30'),
('1185', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-27 22:40:11'),
('1186', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 22:40:15'),
('1187', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-27 22:40:24'),
('1188', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-27 22:41:25'),
('1189', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-27 22:41:45'),
('1190', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:41:49'),
('1191', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:44:27'),
('1192', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 22:45:29'),
('1193', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 22:47:32'),
('1194', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 22:47:56'),
('1195', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 22:48:00'),
('1196', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 22:48:02'),
('1197', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:49:18'),
('1198', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 22:49:58'),
('1199', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 22:50:09'),
('1200', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 22:50:15'),
('1201', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 22:50:28'),
('1202', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 22:50:32'),
('1203', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-27 22:50:39'),
('1204', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 22:50:43'),
('1205', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-27 22:50:48'),
('1206', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-27 22:50:50'),
('1207', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-27 22:50:54'),
('1208', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-27 22:50:58'),
('1209', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-27 22:51:12'),
('1210', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-27 22:51:29'),
('1211', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:54:56'),
('1212', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-27 22:58:11'),
('1213', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:58:11'),
('1214', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:00:25'),
('1215', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-27 23:00:48'),
('1216', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-27 23:01:39'),
('1217', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 23:01:39'),
('1218', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 23:01:57'),
('1219', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-27 23:02:10'),
('1220', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-27 23:02:25'),
('1221', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-27 23:03:26'),
('1222', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 23:03:26'),
('1223', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 23:03:59'),
('1224', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 23:04:03'),
('1225', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:04:09'),
('1226', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-27 23:06:26'),
('1227', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:06:32'),
('1228', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 23:06:55'),
('1229', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 23:07:05'),
('1230', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-27 23:08:06'),
('1231', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-27 23:08:11'),
('1232', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:08:15'),
('1233', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-27 23:08:34'),
('1234', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 23:08:52'),
('1235', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 23:08:57'),
('1236', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 23:09:20'),
('1237', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 23:09:33'),
('1238', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 23:09:41'),
('1239', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 23:09:59'),
('1240', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-27 23:10:10'),
('1241', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 23:10:13'),
('1242', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-27 23:10:22'),
('1243', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-27 23:10:36'),
('1244', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-27 23:10:46'),
('1245', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-27 23:11:01'),
('1246', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-27 23:11:11'),
('1247', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-27 23:11:15'),
('1248', 'VibeStream', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-27 23:11:20');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('1249', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-27 23:11:29'),
('1250', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-27 23:11:40'),
('1251', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:11:50'),
('1252', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-27 23:12:13'),
('1253', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-27 23:12:25'),
('1254', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-27 23:12:36'),
('1255', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 23:18:50'),
('1256', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-27 23:18:51'),
('1257', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 23:21:17'),
('1258', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 23:21:18'),
('1259', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 23:21:18'),
('1260', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 23:21:19'),
('1261', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 23:21:19'),
('1262', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 23:21:20'),
('1263', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-27 23:21:20'),
('1264', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-27 23:21:21'),
('1265', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-27 23:21:38'),
('1266', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-27 23:21:38'),
('1267', 'VibeStream', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-27 23:21:39'),
('1268', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:21:39'),
('1269', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-27 23:21:40'),
('1270', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-27 23:21:41'),
('1271', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 23:23:38'),
('1272', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 23:23:42'),
('1273', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 23:24:13'),
('1274', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 23:24:48'),
('1275', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-27 23:24:59'),
('1276', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-27 23:28:16'),
('1277', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-27 23:31:30'),
('1278', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 23:38:04'),
('1279', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-27 23:39:53'),
('1280', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 23:40:07'),
('1281', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 23:44:58'),
('1282', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:48:09'),
('1283', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:54:22'),
('1284', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-27 23:57:59'),
('1285', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-27 23:58:02'),
('1286', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-28 00:06:03'),
('1287', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-28 00:13:23'),
('1288', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-28 00:26:05'),
('1289', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-28 20:35:51'),
('1290', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-28 20:35:51'),
('1291', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-28 20:36:21'),
('1292', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-28 20:36:32'),
('1293', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-28 20:36:33'),
('1294', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-28 20:36:34'),
('1295', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-28 20:36:37'),
('1296', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-28 20:36:38'),
('1297', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-28 20:36:40'),
('1298', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-28 20:36:41'),
('1299', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-28 20:36:42'),
('1300', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-28 23:35:42'),
('1301', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-28 23:35:42'),
('1302', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-28 23:42:09'),
('1303', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-28 23:44:53'),
('1304', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-28 23:47:59'),
('1305', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-29 00:05:36'),
('1306', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-29 00:05:40'),
('1307', 'VibeStream', 'settings', 'App settings saved: categories (31), category colours', 'platform-settings.php', '::1', '2026-10-29 00:07:50'),
('1308', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-29 00:07:50'),
('1309', 'VibeStream', 'settings', 'App settings saved: categories (30)', 'platform-settings.php', '::1', '2026-10-29 00:08:00'),
('1310', 'VibeStream', 'settings', 'App settings saved: no changes', 'platform-settings.php', '::1', '2026-10-29 00:24:03'),
('1311', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-29 00:24:03'),
('1312', 'VibeStream', 'settings', 'App settings saved: no changes', 'platform-settings.php', '::1', '2026-10-29 00:31:24'),
('1313', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-29 00:31:24'),
('1314', 'VibeStream', 'settings', 'App settings saved: categories (31)', 'platform-settings.php', '::1', '2026-10-29 00:35:58'),
('1315', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-29 00:35:58'),
('1316', 'VibeStream', 'settings', 'App settings saved: categories (30)', 'platform-settings.php', '::1', '2026-10-29 00:36:09'),
('1317', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-29 00:40:45'),
('1318', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-29 00:45:14'),
('1319', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-29 00:49:56'),
('1320', 'VibeStream', 'settings', 'App settings saved: allowed video formats (mp4, webm, mov, mkv, avi, m4v), daily upload limit 0 → 50', 'platform-settings.php', '::1', '2026-10-29 00:51:07'),
('1321', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-29 00:56:11'),
('1322', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-29 01:03:49'),
('1323', 'VibeStream', 'settings', 'App settings saved: search engines blocked', 'platform-settings.php', '::1', '2026-10-29 01:06:56'),
('1324', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-29 01:06:56'),
('1325', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-29 01:07:15'),
('1326', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-29 21:53:40'),
('1327', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-29 21:53:40'),
('1328', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-29 22:04:50'),
('1329', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-29 22:07:04'),
('1330', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-29 22:07:04'),
('1331', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-29 22:13:57'),
('1332', 'VibeStream', 'page_view', 'Opened upload-failures.php', 'upload-failures.php', '::1', '2026-10-29 22:13:59'),
('1333', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-29 22:14:02'),
('1334', 'VibeStream', 'page_view', 'Opened upload-failures.php', 'upload-failures.php', '::1', '2026-10-29 22:14:04'),
('1335', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-29 22:14:09'),
('1336', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-31 01:32:38'),
('1337', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 01:32:38'),
('1338', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 01:38:02'),
('1339', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 01:40:56'),
('1340', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-31 01:41:08'),
('1341', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-31 01:41:11'),
('1342', 'VibeStream', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-31 01:41:12'),
('1343', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 01:41:15'),
('1344', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-31 02:29:38'),
('1345', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 02:29:38'),
('1346', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-31 02:29:48'),
('1347', 'VibeStream', 'page_view', 'Opened products.php', 'products.php', '::1', '2026-10-31 02:29:51'),
('1348', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-31 02:29:53');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('1349', 'VibeStream', 'page_view', 'Opened products.php', 'products.php', '::1', '2026-10-31 02:29:54'),
('1350', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-31 02:30:08'),
('1351', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-31 02:30:11'),
('1352', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-31 02:30:13'),
('1353', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-31 02:30:15'),
('1354', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-31 02:30:17'),
('1355', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-31 02:30:21'),
('1356', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-31 02:30:25'),
('1357', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-31 02:30:27'),
('1358', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-31 02:30:29'),
('1359', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-31 02:30:33'),
('1360', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-31 02:30:41'),
('1361', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-31 02:30:44'),
('1362', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-31 02:30:47'),
('1363', 'VibeStream', 'page_view', 'Opened header.php', 'header.php', '::1', '2026-10-31 02:34:25'),
('1364', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 02:34:32'),
('1365', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-31 02:34:38'),
('1366', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-31 02:34:41'),
('1367', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-31 02:34:45'),
('1368', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-31 02:34:48'),
('1369', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-31 02:35:07'),
('1370', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-31 02:36:35'),
('1371', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-31 02:37:39'),
('1372', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-31 02:37:45'),
('1373', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-31 02:38:13'),
('1374', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-31 02:38:16'),
('1375', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-31 02:44:54'),
('1376', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-31 02:44:59'),
('1377', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-31 02:45:05'),
('1378', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-31 02:45:10'),
('1379', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-31 02:45:45'),
('1380', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-31 02:49:29'),
('1381', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-31 02:49:34'),
('1382', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-31 02:54:03'),
('1383', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-31 02:54:13'),
('1384', 'VibeStream', 'user', 'Gave the CEO title to \"MuhammadAwais\"', 'user_profile.php', '::1', '2026-10-31 02:54:20'),
('1385', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-31 02:54:32'),
('1386', 'VibeStream', 'user', 'Removed the CEO title from \"MuhammadAwais\"', 'admins.php', '::1', '2026-10-31 02:54:35'),
('1387', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-31 02:54:39'),
('1388', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-31 02:54:42'),
('1389', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-31 02:54:44'),
('1390', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 02:54:52'),
('1391', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 02:59:27'),
('1392', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 03:02:05'),
('1393', 'VibeStream', 'page_view', 'Opened products.php', 'products.php', '::1', '2026-10-31 03:02:08'),
('1394', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-31 03:02:09'),
('1395', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 03:02:10'),
('1396', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-31 03:02:20'),
('1397', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-31 03:02:34'),
('1398', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-31 03:02:50'),
('1399', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-31 03:16:12'),
('1400', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 03:17:09'),
('1401', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-31 03:17:54'),
('1402', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-31 03:19:05'),
('1403', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-31 03:27:01'),
('1404', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-31 03:27:19'),
('1405', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-31 03:27:33'),
('1406', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-31 03:30:00'),
('1407', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-31 03:38:05'),
('1408', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-31 03:41:37'),
('1409', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 03:41:40'),
('1410', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 03:43:53'),
('1411', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-31 03:44:16'),
('1412', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-31 03:45:46'),
('1413', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 03:46:29'),
('1414', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-31 03:46:41'),
('1415', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-31 03:51:33'),
('1416', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-31 22:30:05'),
('1417', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 22:30:05'),
('1418', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-31 22:30:11'),
('1419', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-31 22:30:14'),
('1420', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-31 22:30:16'),
('1421', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-31 22:34:30'),
('1422', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-31 22:34:39'),
('1423', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-31 22:37:48'),
('1424', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-31 22:37:51'),
('1425', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-31 22:39:26'),
('1426', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-31 22:43:38'),
('1427', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-31 22:47:59'),
('1428', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 22:47:59'),
('1429', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-31 22:48:07'),
('1430', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-31 22:49:57'),
('1431', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-31 22:51:45'),
('1432', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 22:53:56'),
('1433', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-31 22:54:02'),
('1434', 'VibeStream', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-10-31 22:54:07'),
('1435', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 22:54:21'),
('1436', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-31 22:54:33'),
('1437', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-31 22:54:49'),
('1438', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-31 22:57:59'),
('1439', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-31 22:59:22'),
('1440', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 23:05:14'),
('1441', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 23:08:09'),
('1442', 'VibeStream', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-10-31 23:08:14'),
('1443', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-31 23:08:16'),
('1444', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-31 23:25:32'),
('1445', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-01 00:23:08'),
('1446', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-11-01 00:23:13'),
('1447', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-11-01 00:23:18'),
('1448', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-01 00:44:06');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('1449', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-11-01 00:44:27'),
('1450', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-11-01 00:44:29'),
('1451', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-11-01 00:44:35'),
('1452', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-11-01 00:45:05'),
('1453', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-11-01 00:45:06'),
('1454', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-11-01 00:45:16'),
('1455', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-01 00:45:39'),
('1456', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-01 00:51:56'),
('1457', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-01 00:55:25'),
('1458', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-11-01 00:58:25'),
('1459', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-11-01 00:58:26'),
('1460', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-11-01 00:59:33'),
('1461', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-11-01 01:03:14'),
('1462', 'VibeStream', 'settings', 'App logo changed', 'platform-settings.php', '::1', '2026-11-01 01:03:19'),
('1463', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-11-01 01:07:32'),
('1464', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-11-01 01:10:10'),
('1465', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-11-01 01:13:31'),
('1466', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-01 01:51:34'),
('1467', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-11-01 01:51:39'),
('1468', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-11-01 01:51:52'),
('1469', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-11-01 01:57:51'),
('1470', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-11-01 23:03:36'),
('1471', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-01 23:03:36'),
('1472', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-11-01 23:03:43'),
('1473', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-11-01 23:04:12'),
('1474', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:04:31'),
('1475', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-11-01 23:04:51'),
('1476', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-11-01 23:05:12'),
('1477', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-11-01 23:05:36'),
('1478', 'VibeStream', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-11-01 23:05:38'),
('1479', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:05:47'),
('1480', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-11-01 23:05:50'),
('1481', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:05:51'),
('1482', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-11-01 23:05:58'),
('1483', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-11-01 23:05:59'),
('1484', 'VibeStream', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-11-01 23:06:05'),
('1485', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-11-01 23:06:06'),
('1486', 'VibeStream', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-11-01 23:06:08'),
('1487', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-11-01 23:06:09'),
('1488', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:07:42'),
('1489', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-11-01 23:07:46'),
('1490', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-11-01 23:07:48'),
('1491', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-01 23:07:50'),
('1492', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-11-01 23:07:51'),
('1493', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-11-01 23:07:52'),
('1494', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:07:53'),
('1495', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-11-01 23:07:58'),
('1496', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-11-01 23:07:59'),
('1497', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-11-01 23:08:00'),
('1498', 'VibeStream', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-11-01 23:08:02'),
('1499', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-11-01 23:08:05'),
('1500', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-11-01 23:08:08'),
('1501', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:09:52'),
('1502', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-01 23:16:03'),
('1503', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-11-01 23:16:55'),
('1504', 'VibeStream', 'page_view', 'Opened Edit video', 'editvideos.php', '::1', '2026-11-01 23:18:58'),
('1505', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:19:04'),
('1506', 'VibeStream', 'page_view', 'Opened Edit video', 'editvideos.php', '::1', '2026-11-01 23:19:10'),
('1507', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:19:15'),
('1508', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-11-01 23:19:19'),
('1509', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:19:40'),
('1510', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-11-01 23:19:41'),
('1511', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:19:42'),
('1512', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-01 23:31:50'),
('1513', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:32:01'),
('1514', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-11-01 23:32:08'),
('1515', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:32:52'),
('1516', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-01 23:35:29'),
('1517', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-11-01 23:35:36'),
('1518', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-11-01 23:40:04'),
('1519', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-11-01 23:40:05'),
('1520', 'VibeStream', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-11-01 23:42:55'),
('1521', 'VibeStream', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-11-01 23:47:01'),
('1522', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-01 23:47:28'),
('1523', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-11-01 23:47:34'),
('1524', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-11-02 19:14:17'),
('1525', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-02 19:14:17'),
('1526', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-11-02 19:18:43'),
('1527', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-11-02 19:18:48'),
('1528', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-02 19:18:50'),
('1529', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-11-02 19:18:52'),
('1530', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-11-02 19:18:53'),
('1531', 'VibeStream', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-11-02 19:18:55'),
('1532', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-11-02 19:18:59'),
('1533', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-11-02 19:19:01'),
('1534', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 19:19:03'),
('1535', 'VibeStream', 'user', 'Gave the CEO title to \"MuhammadAwais\"', 'admins.php', '::1', '2026-11-02 19:19:07'),
('1536', 'VibeStream', 'user', 'Removed the CEO title from \"MuhammadAwais\"', 'admins.php', '::1', '2026-11-02 19:19:19'),
('1537', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 19:22:50'),
('1538', 'VibeStream', 'user', 'Gave the CEO title to \"MuhammadAwais\"', 'admins.php', '::1', '2026-11-02 19:24:03'),
('1539', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-02 19:26:29'),
('1540', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-11-02 19:26:33'),
('1541', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-11-02 19:26:40'),
('1542', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-11-02 19:28:54'),
('1543', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 19:28:58'),
('1544', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 19:46:43'),
('1545', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 20:33:51'),
('1546', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-02 20:33:55'),
('1547', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-11-02 20:33:58'),
('1548', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-11-02 20:34:01');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('1549', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-11-02 20:34:09'),
('1550', 'VibeStream', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-11-02 20:34:11'),
('1551', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-11-02 20:34:16'),
('1552', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-11-02 20:34:18'),
('1553', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 20:35:50'),
('1554', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 20:38:10'),
('1555', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-11-02 20:42:43'),
('1556', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 20:42:54'),
('1557', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-11-02 20:43:10'),
('1558', 'VibeStream', 'user', 'Removed the CEO title from \"MuhammadAwais\"', 'user_profile.php', '::1', '2026-11-02 20:43:23'),
('1559', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 20:43:27'),
('1560', 'VibeStream', 'user', 'Set admin access for account #17 to Full Admin', 'admins.php', '::1', '2026-11-02 20:43:34'),
('1561', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 20:48:39'),
('1562', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 20:57:12'),
('1563', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 21:08:28'),
('1564', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-11-02 21:09:56'),
('1565', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-11-02 21:10:11'),
('1566', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-11-02 21:10:21'),
('1567', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-11-02 21:10:22'),
('1568', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-11-02 21:10:24'),
('1569', 'VibeStream', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-11-02 21:10:46'),
('1570', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-11-02 21:10:49'),
('1571', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-11-02 21:10:51'),
('1572', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-11-02 21:11:26'),
('1573', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-11-02 21:11:29'),
('1574', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-11-02 21:11:30'),
('1575', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-11-02 21:11:35'),
('1576', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-11-02 21:11:39'),
('1577', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-11-02 21:11:57'),
('1578', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-11-02 21:12:08'),
('1579', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-11-02 21:12:12'),
('1580', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-11-02 21:12:19'),
('1581', 'VibeStream', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-11-02 21:12:28'),
('1582', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-11-02 21:12:31'),
('1583', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-11-02 21:13:41'),
('1584', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-02 21:14:38'),
('1585', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-02 23:16:27'),
('1586', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-02 23:24:14'),
('1587', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-02 23:28:34'),
('1588', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-11-02 23:28:48'),
('1589', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-11-02 23:33:52'),
('1590', 'VibeStream', 'page_view', 'Opened top-creators.php', 'top-creators.php', '::1', '2026-11-02 23:33:55'),
('1591', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-02 23:34:07'),
('1592', 'VibeStream', 'page_view', 'Opened top-creators.php', 'top-creators.php', '::1', '2026-11-02 23:34:30'),
('1593', 'VibeStream', 'page_view', 'Opened top-creators.php', 'top-creators.php', '::1', '2026-11-02 23:36:42'),
('1594', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-11-02 23:43:25'),
('1595', 'VibeStream', 'page_view', 'Opened top-creators.php', 'top-creators.php', '::1', '2026-11-02 23:43:27'),
('1596', 'VibeStream', 'page_view', 'Opened top-creators.php', 'top-creators.php', '::1', '2026-11-02 23:46:29'),
('1597', 'VibeStream', 'page_view', 'Opened top-creators.php', 'top-creators.php', '::1', '2026-11-02 23:58:16');

-- ----------------------------
-- Table `admin_alert_reads`
-- ----------------------------
DROP TABLE IF EXISTS `admin_alert_reads`;
CREATE TABLE `admin_alert_reads` (
  `alert_id` bigint(20) unsigned NOT NULL,
  `admin_username` varchar(100) NOT NULL,
  `read_at` datetime NOT NULL,
  PRIMARY KEY (`alert_id`,`admin_username`),
  KEY `admin_alert_read_by` (`admin_username`,`read_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_alert_reads` (`alert_id`, `admin_username`, `read_at`) VALUES
('1', 'MuhammadAwais', '2026-10-25 02:57:56'),
('1', 'VibeStream', '2026-10-24 21:10:17'),
('2', 'VibeStream', '2026-10-27 23:01:45'),
('1', 'VibeStreams', '2026-10-22 22:05:50');

-- ----------------------------
-- Table `admin_alerts`
-- ----------------------------
DROP TABLE IF EXISTS `admin_alerts`;
CREATE TABLE `admin_alerts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `alert_key` varchar(190) NOT NULL,
  `kind` varchar(40) NOT NULL,
  `title` varchar(190) NOT NULL,
  `message` varchar(500) NOT NULL DEFAULT '',
  `href` varchar(255) NOT NULL DEFAULT 'index.php',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alert_key_unique` (`alert_key`),
  KEY `alert_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_alerts` (`id`, `alert_key`, `kind`, `title`, `message`, `href`, `created_at`) VALUES
('1', 'content-report-0', 'report', 'New content report', 'Short reported for other by VibeStreams.', 'reported.php?status=open', '2026-10-22 17:43:57'),
('2', 'admin-login-failed-a4401e329dd0aa14bed468e9a6f52e5f7035965563decab58198f32e1d5c3401', 'admin_login_failed', 'Failed admin sign-in', 'A sign-in attempt for VibeStream failed from IP ::1.', 'admin-activity.php', '2026-10-27 23:00:08');

-- ----------------------------
-- Table `admin_call_reads`
-- ----------------------------
DROP TABLE IF EXISTS `admin_call_reads`;
CREATE TABLE `admin_call_reads` (
  `call_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `read_at` datetime NOT NULL,
  PRIMARY KEY (`call_id`,`user_id`),
  KEY `idx_admin_call_reads_user` (`user_id`,`read_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `admin_call_signals`
-- ----------------------------
DROP TABLE IF EXISTS `admin_call_signals`;
CREATE TABLE `admin_call_signals` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `call_id` char(32) NOT NULL,
  `from_user` int(11) NOT NULL,
  `to_user` int(11) NOT NULL,
  `event_type` varchar(12) NOT NULL,
  `payload` mediumtext NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_call_signals_poll` (`call_id`,`to_user`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_call_signals` (`id`, `call_id`, `from_user`, `to_user`, `event_type`, `payload`, `created_at`) VALUES
('1', '4d45b50e7757dae4f686900fa55f5e53', '14', '17', 'hangup', '', '2026-10-22 00:05:59');

-- ----------------------------
-- Table `admin_calls`
-- ----------------------------
DROP TABLE IF EXISTS `admin_calls`;
CREATE TABLE `admin_calls` (
  `call_id` char(32) NOT NULL,
  `caller_id` int(11) NOT NULL,
  `callee_id` int(11) NOT NULL,
  `media` varchar(8) NOT NULL,
  `status` varchar(12) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`call_id`),
  KEY `idx_admin_calls_caller` (`caller_id`,`status`,`updated_at`),
  KEY `idx_admin_calls_callee` (`callee_id`,`status`,`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_calls` (`call_id`, `caller_id`, `callee_id`, `media`, `status`, `updated_at`) VALUES
('4d45b50e7757dae4f686900fa55f5e53', '14', '17', 'audio', 'ended', '2026-10-22 00:05:59');

-- ----------------------------
-- Table `admin_chat_prefs`
-- ----------------------------
DROP TABLE IF EXISTS `admin_chat_prefs`;
CREATE TABLE `admin_chat_prefs` (
  `user_id` int(11) NOT NULL,
  `chat_key` varchar(20) NOT NULL,
  `pinned` tinyint(4) NOT NULL DEFAULT 0,
  `muted` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`,`chat_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_chat_prefs` (`user_id`, `chat_key`, `pinned`, `muted`) VALUES
('14', 'd17', '0', '0');

-- ----------------------------
-- Table `admin_dashboard_goals`
-- ----------------------------
DROP TABLE IF EXISTS `admin_dashboard_goals`;
CREATE TABLE `admin_dashboard_goals` (
  `goal_month` char(7) NOT NULL,
  `metric` varchar(16) NOT NULL,
  `target` int(10) unsigned NOT NULL,
  `updated_by` varchar(191) NOT NULL DEFAULT '',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`goal_month`,`metric`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_dashboard_goals` (`goal_month`, `metric`, `target`, `updated_by`, `updated_at`) VALUES
('2026-10', 'signups', '5', 'VibeStream', '2026-10-21 23:23:10'),
('2026-10', 'uploads', '5', 'VibeStream', '2026-10-21 23:23:16'),
('2026-11', 'signups', '5', 'VibeStream', '2026-11-01 23:04:04'),
('2026-11', 'uploads', '5', 'VibeStream', '2026-11-01 23:04:10');

-- ----------------------------
-- Table `admin_group_members`
-- ----------------------------
DROP TABLE IF EXISTS `admin_group_members`;
CREATE TABLE `admin_group_members` (
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_read_id` int(11) NOT NULL DEFAULT 0,
  `joined_at` datetime NOT NULL,
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_group_members` (`group_id`, `user_id`, `last_read_id`, `joined_at`) VALUES
('1', '10', '0', '2026-10-11 21:53:25');

-- ----------------------------
-- Table `admin_group_messages`
-- ----------------------------
DROP TABLE IF EXISTS `admin_group_messages`;
CREATE TABLE `admin_group_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `sender_name` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `created_at` datetime NOT NULL,
  `edited_at` datetime DEFAULT NULL,
  `reply_to` int(11) DEFAULT NULL,
  `att_name` varchar(255) DEFAULT NULL,
  `att_path` varchar(120) DEFAULT NULL,
  `att_type` varchar(100) DEFAULT NULL,
  `att_size` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_group` (`group_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `admin_groups`
-- ----------------------------
DROP TABLE IF EXISTS `admin_groups`;
CREATE TABLE `admin_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_groups` (`id`, `name`, `created_by`, `created_at`) VALUES
('1', 'WHY', '10', '2026-10-11 21:53:25');

-- ----------------------------
-- Table `admin_message_history`
-- ----------------------------
DROP TABLE IF EXISTS `admin_message_history`;
CREATE TABLE `admin_message_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `kind` char(1) NOT NULL,
  `conversation_key` varchar(64) NOT NULL,
  `message_id` int(11) NOT NULL,
  `action` varchar(8) NOT NULL,
  `actor_id` int(11) NOT NULL,
  `actor_name` varchar(100) NOT NULL,
  `old_body` text NOT NULL,
  `attachment_name` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_conversation_history` (`conversation_key`,`id`),
  KEY `idx_message_history` (`kind`,`message_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_message_history` (`id`, `kind`, `conversation_key`, `message_id`, `action`, `actor_id`, `actor_name`, `old_body`, `attachment_name`, `created_at`) VALUES
('1', 'd', 'd:14:17', '5', 'deleted', '14', 'VibeStream', '📎 voice-note-1792609577583.webm', 'voice-note-1792609577583.webm', '2026-10-22 00:06:42');

-- ----------------------------
-- Table `admin_messages`
-- ----------------------------
DROP TABLE IF EXISTS `admin_messages`;
CREATE TABLE `admin_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `edited_at` datetime DEFAULT NULL,
  `reply_to` int(11) DEFAULT NULL,
  `att_name` varchar(255) DEFAULT NULL,
  `att_path` varchar(120) DEFAULT NULL,
  `att_type` varchar(100) DEFAULT NULL,
  `att_size` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_messages_inbox` (`recipient_id`,`is_read`),
  KEY `idx_admin_messages_pair` (`sender_id`,`recipient_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
-- Table `admin_msg_reactions`
-- ----------------------------
DROP TABLE IF EXISTS `admin_msg_reactions`;
CREATE TABLE `admin_msg_reactions` (
  `kind` char(1) NOT NULL,
  `msg_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `emoji` varchar(16) NOT NULL,
  PRIMARY KEY (`kind`,`msg_id`,`user_id`),
  KEY `idx_msg` (`kind`,`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `admin_pay_adjust`
-- ----------------------------
DROP TABLE IF EXISTS `admin_pay_adjust`;
CREATE TABLE `admin_pay_adjust` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month` char(7) NOT NULL,
  `username` varchar(100) NOT NULL,
  `hours` decimal(7,2) NOT NULL,
  `reason` varchar(200) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_month_user` (`month`,`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_pay_adjust` (`id`, `month`, `username`, `hours`, `reason`, `created_at`) VALUES
('1', '2026-10', 'muhammadawais', '100.00', 'idk', '2026-10-25 02:16:09'),
('2', '2026-10', 'muhammadawais', '-100.00', 'idk', '2026-10-25 02:20:42'),
('3', '2026-10', 'muhammadawais', '2.00', 'Work hard', '2026-10-25 02:27:37');

-- ----------------------------
-- Table `admin_pay_bonus`
-- ----------------------------
DROP TABLE IF EXISTS `admin_pay_bonus`;
CREATE TABLE `admin_pay_bonus` (
  `task_id` varchar(32) NOT NULL,
  `month` char(7) NOT NULL,
  `username` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `reason` varchar(200) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`task_id`),
  KEY `idx_month_user` (`month`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `admin_pay_log`
-- ----------------------------
DROP TABLE IF EXISTS `admin_pay_log`;
CREATE TABLE `admin_pay_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_pay_log` (`id`, `text`, `created_at`) VALUES
('1', 'Pay rates updated', '2026-10-24 18:15:27'),
('2', 'Pay rates updated', '2026-10-25 00:30:11'),
('3', 'MuhammadAwais marked as pending (2026-10)', '2026-10-25 00:31:48'),
('4', 'MuhammadAwais marked as pending (2026-10)', '2026-10-25 00:31:52'),
('5', 'MuhammadAwais marked as paid (2026-10)', '2026-10-25 00:31:57'),
('6', 'MuhammadAwais marked as do not pay (2026-10): not working', '2026-10-25 02:14:47'),
('7', '+100 hrs for MuhammadAwais: idk', '2026-10-25 02:16:09'),
('8', 'MuhammadAwais marked as allowed to be paid (owner override) (2026-10)', '2026-10-25 02:19:18'),
('9', 'MuhammadAwais marked as do not pay (2026-10): not working', '2026-10-25 02:19:31'),
('10', '-100 hrs for MuhammadAwais: idk', '2026-10-25 02:20:42'),
('11', '+2 hrs for MuhammadAwais: Work hard', '2026-10-25 02:27:37'),
('12', 'MuhammadAwais marked as allowed to be paid (owner override) (2026-10)', '2026-10-25 03:12:13'),
('13', 'MuhammadAwais marked as paid (2026-10)', '2026-10-25 03:12:24'),
('14', 'Pay rates and work times updated', '2026-10-27 23:32:31');

-- ----------------------------
-- Table `admin_pay_months`
-- ----------------------------
DROP TABLE IF EXISTS `admin_pay_months`;
CREATE TABLE `admin_pay_months` (
  `month` char(7) NOT NULL,
  `username` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending',
  `paid_amount` decimal(12,2) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `note` varchar(200) NOT NULL DEFAULT '',
  `override` tinyint(1) NOT NULL DEFAULT 0,
  `paid_by` varchar(100) NOT NULL DEFAULT '',
  `paid_at` datetime DEFAULT NULL,
  PRIMARY KEY (`month`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_pay_months` (`month`, `username`, `status`, `paid_amount`, `updated_at`, `note`, `override`, `paid_by`, `paid_at`) VALUES
('2026-10', 'muhammadawais', 'paid', '430.50', '2026-10-25 03:12:24', '', '1', '', NULL);

-- ----------------------------
-- Table `admin_pay_settings`
-- ----------------------------
DROP TABLE IF EXISTS `admin_pay_settings`;
CREATE TABLE `admin_pay_settings` (
  `username` varchar(100) NOT NULL,
  `rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `title` varchar(60) NOT NULL DEFAULT '',
  `shift_start` char(5) NOT NULL DEFAULT '',
  `shift_end` char(5) NOT NULL DEFAULT '',
  `work_days` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_pay_settings` (`username`, `rate`, `title`, `shift_start`, `shift_end`, `work_days`) VALUES
('muhammadawais', '200.00', 'Admin', '12:32', '13:14', '1,2,7');

-- ----------------------------
-- Table `admin_presence`
-- ----------------------------
DROP TABLE IF EXISTS `admin_presence`;
CREATE TABLE `admin_presence` (
  `user_id` int(11) NOT NULL,
  `last_seen` datetime NOT NULL,
  `typing_chat` varchar(20) DEFAULT NULL,
  `typing_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_presence` (`user_id`, `last_seen`, `typing_chat`, `typing_at`) VALUES
('14', '2026-11-02 21:11:36', NULL, NULL),
('17', '2026-10-25 03:29:16', NULL, NULL);

-- ----------------------------
-- Table `admin_summary_settings`
-- ----------------------------
DROP TABLE IF EXISTS `admin_summary_settings`;
CREATE TABLE `admin_summary_settings` (
  `admin_key` varchar(191) NOT NULL,
  `email` varchar(254) NOT NULL,
  `frequency` varchar(8) NOT NULL,
  `last_sent_on` date DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`admin_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_summary_settings` (`admin_key`, `email`, `frequency`, `last_sent_on`, `updated_at`) VALUES
('14', 'muhammadawaiscom0@gmail.com', 'weekly', NULL, '2026-10-23 22:07:21');

-- ----------------------------
-- Table `admin_user_notes`
-- ----------------------------
DROP TABLE IF EXISTS `admin_user_notes`;
CREATE TABLE `admin_user_notes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `admin_name` varchar(191) NOT NULL,
  `note` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_admin_user_notes_user` (`user_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
-- Table `channel_profiles`
-- ----------------------------
DROP TABLE IF EXISTS `channel_profiles`;
CREATE TABLE `channel_profiles` (
  `username` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL DEFAULT '',
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `channel_profiles` (`username`, `description`, `updated_at`) VALUES
('VibeStream', 'This is the offical VibeStream Channel', '2026-10-24 21:08:31');

-- ----------------------------
-- Table `comment_votes`
-- ----------------------------
DROP TABLE IF EXISTS `comment_votes`;
CREATE TABLE `comment_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `vote` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_comment_votes_comment_user` (`comment_id`,`username`),
  KEY `idx_comment_votes_comment` (`comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `comment_votes` (`id`, `comment_id`, `username`, `vote`, `created_at`) VALUES
('1', '29', 'deleted_c6849d61', '-1', '2026-10-10 01:30:28');

-- ----------------------------
-- Table `comments`
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `comment_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `hearted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `comments` (`id`, `video_id`, `username`, `comment_text`, `created_at`, `hearted`) VALUES
('34', '-4BzpL7pcnj', 'VibeStream', 'gg', '2026-10-11 03:19:10', '0'),
('37', '5ABfNhJvTTs', 'VibeStream', 'gg', '2026-10-16 20:26:32', '0'),
('38', 'MUiqU20kGZ5', 'VibeStream', 'gg', '2026-10-17 19:34:06', '0'),
('39', '5ABfNhJvTTs', 'VibeStream', 'gg', '2026-10-22 17:43:22', '0'),
('40', '6lrPGbgxpQr', 'VibeStream', 'gg', '2026-11-01 23:10:14', '0');

-- ----------------------------
-- Table `content_report_notes`
-- ----------------------------
DROP TABLE IF EXISTS `content_report_notes`;
CREATE TABLE `content_report_notes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `content_table` varchar(20) NOT NULL,
  `content_id` varchar(64) NOT NULL,
  `admin` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `content_lookup` (`content_table`,`content_id`),
  KEY `created_at_idx` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `content_reports`
-- ----------------------------
DROP TABLE IF EXISTS `content_reports`;
CREATE TABLE `content_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_table` varchar(20) NOT NULL,
  `content_id` varchar(64) NOT NULL,
  `content_type` varchar(10) NOT NULL,
  `reason` varchar(30) NOT NULL,
  `details` varchar(500) NOT NULL DEFAULT '',
  `reporter` varchar(100) NOT NULL,
  `status` varchar(12) NOT NULL DEFAULT 'open',
  `created_at` datetime NOT NULL,
  `reviewed_by` varchar(100) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `assigned_to` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `one_report_per_user` (`content_table`,`content_id`,`reporter`),
  KEY `status_idx` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `content_reports` (`id`, `content_table`, `content_id`, `content_type`, `reason`, `details`, `reporter`, `status`, `created_at`, `reviewed_by`, `reviewed_at`, `assigned_to`) VALUES
('1', 'videos', 'TQ671jx2LHK', 'video', 'other', 'testing', 'OwnerHunter', 'dismissed', '2026-10-11 21:59:24', 'OwnerHunter', '2026-10-11 21:59:45', NULL),
('2', 'videos', 'rqcUKdldcNy', 'short', 'other', 'testing', 'OwnerHunter', 'removed', '2026-10-12 19:27:05', 'OwnerHunter', '2026-10-12 19:28:36', NULL),
('4', 'videos', '5ABfNhJvTTs', 'short', 'other', 'testing', 'VibeStreams', 'dismissed', '2026-10-22 14:43:57', 'VibeStreams', '2026-10-22 14:49:03', NULL);

-- ----------------------------
-- Table `owner_notices`
-- ----------------------------
DROP TABLE IF EXISTS `owner_notices`;
CREATE TABLE `owner_notices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `from_name` varchar(100) NOT NULL DEFAULT '',
  `to_id` int(11) NOT NULL,
  `to_name` varchar(100) NOT NULL DEFAULT '',
  `body` varchar(1000) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'sent',
  `seen_at` datetime DEFAULT NULL,
  `done_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_to` (`to_id`,`status`),
  KEY `idx_from` (`from_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `owner_notices` (`id`, `from_id`, `from_name`, `to_id`, `to_name`, `body`, `status`, `seen_at`, `done_at`, `created_at`) VALUES
('3', '14', 'VibeStreams', '17', 'MuhammadAwais', 'testing', 'done', '2026-10-25 03:29:37', '2026-10-25 03:29:46', '2026-10-24 21:02:30');

-- ----------------------------
-- Table `payroll_adjust`
-- ----------------------------
DROP TABLE IF EXISTS `payroll_adjust`;
CREATE TABLE `payroll_adjust` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_key` varchar(100) NOT NULL,
  `pay_month` char(7) NOT NULL,
  `hours` decimal(6,2) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_month` (`admin_key`,`pay_month`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payroll_adjust` (`id`, `admin_key`, `pay_month`, `hours`, `reason`, `created_at`) VALUES
('1', 'muhammadawais', '2026-11', '-16.00', 'idk', '2026-10-23 23:19:55');

-- ----------------------------
-- Table `payroll_payments`
-- ----------------------------
DROP TABLE IF EXISTS `payroll_payments`;
CREATE TABLE `payroll_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_key` varchar(100) NOT NULL,
  `pay_month` char(7) NOT NULL,
  `status` varchar(10) NOT NULL,
  `hours` decimal(8,2) NOT NULL DEFAULT 0.00,
  `rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `note` varchar(255) NOT NULL DEFAULT '',
  `decided_at` datetime NOT NULL,
  `rate_usd` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount_usd` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(40) NOT NULL DEFAULT '',
  `payment_reference` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `one_per_month` (`admin_key`,`pay_month`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payroll_payments` (`id`, `admin_key`, `pay_month`, `status`, `hours`, `rate`, `amount`, `note`, `decided_at`, `rate_usd`, `amount_usd`, `payment_method`, `payment_reference`) VALUES
('2', 'muhammadawais', '2026-10', 'hold', '0.00', '200.00', '0.00', '', '2026-10-23 22:55:02', '16.00', '0.00', '', '');

-- ----------------------------
-- Table `payroll_rates`
-- ----------------------------
DROP TABLE IF EXISTS `payroll_rates`;
CREATE TABLE `payroll_rates` (
  `admin_key` varchar(100) NOT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `hourly_rate_usd` decimal(10,2) NOT NULL DEFAULT 16.00,
  PRIMARY KEY (`admin_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payroll_rates` (`admin_key`, `hourly_rate`, `hourly_rate_usd`) VALUES
('muhammadawais', '200.00', '16.00');

-- ----------------------------
-- Table `playlist_videos`
-- ----------------------------
DROP TABLE IF EXISTS `playlist_videos`;
CREATE TABLE `playlist_videos` (
  `playlist_id` int(10) unsigned NOT NULL,
  `video_id` varchar(191) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`playlist_id`,`video_id`),
  KEY `idx_playlist_videos_video` (`video_id`),
  CONSTRAINT `fk_playlist_videos_playlist` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `playlists`
-- ----------------------------
DROP TABLE IF EXISTS `playlists`;
CREATE TABLE `playlists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `visibility` enum('private','public') NOT NULL DEFAULT 'private',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_playlists_user` (`user_id`),
  KEY `idx_playlists_visibility` (`visibility`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `premium_end_alerts`
-- ----------------------------
DROP TABLE IF EXISTS `premium_end_alerts`;
CREATE TABLE `premium_end_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `plan` varchar(10) NOT NULL,
  `started_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `ended_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `seen_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_period` (`username`,`started_at`,`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1845 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `premium_end_alerts` (`id`, `username`, `plan`, `started_at`, `expires_at`, `ended_at`, `created_at`, `seen_at`) VALUES
('1', 'aqsa', 'monthly', '2026-10-11 19:23:52', '2026-11-11 19:23:52', '2026-10-11 19:24:12', '2026-10-11 19:55:47', '2026-10-11 19:58:50'),
('438', 'VibeStream', 'yearly', '2026-10-11 01:37:10', '2027-10-12 01:37:10', '2026-10-16 10:01:44', '2026-10-16 10:01:44', '2026-10-16 10:02:00'),
('449', 'VibeStream', 'monthly', '2026-10-16 19:39:28', '2026-11-16 19:39:28', '2026-10-16 19:39:54', '2026-10-16 19:39:55', '2026-10-16 19:40:58'),
('450', 'MuhammadAwais', 'plusmonth', '2026-10-16 19:42:13', '2026-11-16 19:42:13', '2026-10-21 19:57:16', '2026-10-21 19:57:16', '2026-10-21 19:57:52');

-- ----------------------------
-- Table `premium_members`
-- ----------------------------
DROP TABLE IF EXISTS `premium_members`;
CREATE TABLE `premium_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `plan` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'active',
  `started_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `premium_members` (`id`, `username`, `plan`, `status`, `started_at`, `expires_at`, `updated_at`) VALUES
('3', 'VibeStream', 'plusyear', 'active', '2026-10-16 19:40:10', '2029-10-16 19:40:10', '2026-10-16 19:40:10'),
('9', 'MuhammadAwais', 'plusmonth', 'cancelled', '2026-10-16 19:42:13', '2026-11-16 19:42:13', '2026-10-21 19:57:16'),
('10', 'aqsa', 'monthly', 'active', '2026-10-22 17:51:18', '2026-11-22 17:51:18', '2026-10-22 17:51:18');

-- ----------------------------
-- Table `premium_reminders`
-- ----------------------------
DROP TABLE IF EXISTS `premium_reminders`;
CREATE TABLE `premium_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `expires_at` datetime NOT NULL,
  `kind` varchar(10) NOT NULL,
  `sent_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reminder` (`username`,`expires_at`,`kind`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `premium_requests`
-- ----------------------------
DROP TABLE IF EXISTS `premium_requests`;
CREATE TABLE `premium_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `plan` varchar(10) NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `txn_ref` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_txn_ref` (`txn_ref`),
  KEY `idx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `premium_requests` (`id`, `username`, `plan`, `amount`, `txn_ref`, `status`, `created_at`, `updated_at`) VALUES
('1', 'MuhammadAwais', 'plusmonth', '9.99', '5448554454', 'approved', '2026-10-16 19:41:37', '2026-10-16 19:42:13');

-- ----------------------------
-- Table `reward_points_accounts`
-- ----------------------------
DROP TABLE IF EXISTS `reward_points_accounts`;
CREATE TABLE `reward_points_accounts` (
  `username` varchar(100) NOT NULL,
  `points` int(10) unsigned NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `reward_points_accounts` (`username`, `points`, `updated_at`) VALUES
('VibeStream', '5', '2026-11-02 22:18:41');

-- ----------------------------
-- Table `reward_points_ledger`
-- ----------------------------
DROP TABLE IF EXISTS `reward_points_ledger`;
CREATE TABLE `reward_points_ledger` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `amount` int(11) NOT NULL,
  `reason` varchar(32) NOT NULL,
  `reference_key` char(64) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reward_points_reference` (`reference_key`),
  KEY `idx_reward_points_username_created` (`username`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `reward_points_ledger` (`id`, `username`, `amount`, `reason`, `reference_key`, `created_at`) VALUES
('1', 'VibeStream', '5', 'upload', '394f7a97456be45bfdf25e239e02a19af98d110e7219965b50400ad543dab2db', '2026-11-02 22:18:41');

-- ----------------------------
-- Table `search_logs`
-- ----------------------------
DROP TABLE IF EXISTS `search_logs`;
CREATE TABLE `search_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `query` varchar(100) NOT NULL,
  `results` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_search_logs_created_at` (`created_at`),
  KEY `idx_search_logs_query` (`query`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
-- Table `signup_ip_hashes`
-- ----------------------------
DROP TABLE IF EXISTS `signup_ip_hashes`;
CREATE TABLE `signup_ip_hashes` (
  `user_id` bigint(20) unsigned NOT NULL,
  `ip_hash` char(64) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`),
  KEY `idx_signup_ip_hashes_hash` (`ip_hash`),
  KEY `idx_signup_ip_hashes_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `signup_ip_hashes` (`user_id`, `ip_hash`, `created_at`) VALUES
('20', '3db0233b9bf564ed51e3c852676da719289ac42d633e6bf6d3eaedcee4129b41', '2026-10-26 01:06:55');

-- ----------------------------
-- Table `site_announcements`
-- ----------------------------
DROP TABLE IF EXISTS `site_announcements`;
CREATE TABLE `site_announcements` (
  `id` tinyint(3) unsigned NOT NULL,
  `message` varchar(500) NOT NULL DEFAULT '',
  `updated_by` varchar(191) NOT NULL DEFAULT '',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `site_announcements` (`id`, `message`, `updated_by`, `updated_at`) VALUES
('1', '', '', '2026-10-21 22:10:06');

-- ----------------------------
-- Table `subscription_seen`
-- ----------------------------
DROP TABLE IF EXISTS `subscription_seen`;
CREATE TABLE `subscription_seen` (
  `user_id` int(11) NOT NULL,
  `channel_key` varchar(191) NOT NULL,
  `seen_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`channel_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
-- Table `upload_failure_events`
-- ----------------------------
DROP TABLE IF EXISTS `upload_failure_events`;
CREATE TABLE `upload_failure_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `content_type` varchar(16) NOT NULL,
  `upload_mode` varchar(16) NOT NULL,
  `failure_code` varchar(40) NOT NULL,
  `php_error_code` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_upload_failure_events_created` (`created_at`),
  KEY `idx_upload_failure_events_code_created` (`failure_code`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `upload_failure_events` (`id`, `username`, `content_type`, `upload_mode`, `failure_code`, `php_error_code`, `created_at`) VALUES
('1', '', 'short', 'link', 'invalid_video_link', '0', '2026-10-27 22:57:17'),
('2', '', 'short', 'link', 'invalid_video_link', '0', '2026-10-27 22:57:35');

-- ----------------------------
-- Table `user_activity_days`
-- ----------------------------
DROP TABLE IF EXISTS `user_activity_days`;
CREATE TABLE `user_activity_days` (
  `user_id` bigint(20) unsigned NOT NULL,
  `active_date` date NOT NULL,
  PRIMARY KEY (`user_id`,`active_date`),
  KEY `idx_user_activity_days_date` (`active_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_activity_days` (`user_id`, `active_date`) VALUES
('14', '2026-10-21'),
('14', '2026-10-22'),
('14', '2026-10-23'),
('14', '2026-10-24'),
('14', '2026-10-25'),
('14', '2026-10-27'),
('14', '2026-10-28'),
('14', '2026-10-29'),
('14', '2026-10-31'),
('14', '2026-11-01'),
('14', '2026-11-02'),
('17', '2026-10-25'),
('18', '2026-10-21'),
('19', '2026-10-22'),
('19', '2026-10-24'),
('19', '2026-10-25'),
('20', '2026-10-26'),
('21', '2026-10-26'),
('21', '2026-10-31');

-- ----------------------------
-- Table `user_notification_prefs`
-- ----------------------------
DROP TABLE IF EXISTS `user_notification_prefs`;
CREATE TABLE `user_notification_prefs` (
  `user_id` int(11) NOT NULL,
  `uploads` tinyint(1) NOT NULL DEFAULT 1,
  `comments` tinyint(1) NOT NULL DEFAULT 1,
  `likes` tinyint(1) NOT NULL DEFAULT 1,
  `subscribers` tinyint(1) NOT NULL DEFAULT 1,
  `desktop_notifs` tinyint(1) NOT NULL DEFAULT 0,
  `subscriptions` tinyint(1) NOT NULL DEFAULT 1,
  `recommended` tinyint(1) NOT NULL DEFAULT 1,
  `channel_activity` tinyint(1) NOT NULL DEFAULT 1,
  `comment_activity` tinyint(1) NOT NULL DEFAULT 1,
  `mentions` tinyint(1) NOT NULL DEFAULT 1,
  `content_reuse` tinyint(1) NOT NULL DEFAULT 1,
  `promotions` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_notification_prefs` (`user_id`, `uploads`, `comments`, `likes`, `subscribers`, `desktop_notifs`, `subscriptions`, `recommended`, `channel_activity`, `comment_activity`, `mentions`, `content_reuse`, `promotions`) VALUES
('9', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '1', '0'),
('14', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');

-- ----------------------------
-- Table `user_notifications`
-- ----------------------------
DROP TABLE IF EXISTS `user_notifications`;
CREATE TABLE `user_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'upload',
  `channel_name` varchar(255) NOT NULL DEFAULT '',
  `actor` varchar(255) NOT NULL DEFAULT '',
  `video_id` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `message` varchar(500) NOT NULL DEFAULT '',
  `link` varchar(500) NOT NULL DEFAULT '',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_notifications_user` (`user_id`,`is_read`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_notifications` (`id`, `user_id`, `type`, `channel_name`, `actor`, `video_id`, `title`, `message`, `link`, `is_read`, `created_at`) VALUES
('4', '9', 'like', 'aqsa', 'aqsa', '6nvdR8clMIk', 'Eat Everything In A Grocery Store, Win $1,000,000', 'aqsa liked your video: Eat Everything In A Grocery Store, Win $1,000,000', 'watch.php?id=6nvdR8clMIk', '0', '2026-10-10 01:38:03'),
('7', '1', 'comment', 'deleted_11', 'Instant', 'IFUtsXdwk-A', 'Clean Transformation 🔥 | One Piece EP 1001 👒 | #onepiece #luffy', 'Instant commented on your short: \"gg\"', 'shorts.php?id=IFUtsXdwk-A', '1', '2026-10-10 12:35:27'),
('8', '11', 'like', 'VibeStream', 'OwnerHunter', 'aNsGJAzNt0h', '$10,000 Every Day You Survive In The Wilderness', 'OwnerHunter liked your video: $10,000 Every Day You Survive In The Wilderness', 'watch.php?id=aNsGJAzNt0h', '0', '2026-10-11 02:57:06'),
('9', '10', 'comment', 'VibeStream', 'OwnerHunter', '-4BzpL7pcnj', 'Even Gods Like Ice cream 😭', 'OwnerHunter commented on your short: \"gg\"', 'shorts.php?id=-4BzpL7pcnj', '0', '2026-10-11 03:19:10'),
('11', '10', 'like', 'VibeStream', 'OwnerHunter', 'MO1j8vJHKNl', 'Making a song in the style of…', 'OwnerHunter liked your short: Making a song in the style of…', 'shorts.php?id=MO1j8vJHKNl', '0', '2026-10-12 22:24:03'),
('13', '10', 'comment', 'VibeStream', 'OwnerHunter', 'MO1j8vJHKNl', 'Making a song in the style of…', 'OwnerHunter commented on your short: \"@OwnerHunter gg\"', 'shorts.php?id=MO1j8vJHKNl', '0', '2026-10-12 22:24:20'),
('14', '10', 'like', 'VibeStream', 'OwnerHunter', '-4BzpL7pcnj', 'Even Gods Like Ice cream 😭', 'OwnerHunter liked your short: Even Gods Like Ice cream 😭', 'shorts.php?id=-4BzpL7pcnj', '0', '2026-10-12 22:26:07'),
('15', '10', 'like', 'VibeStream', 'OwnerHunter', '4ZLZUhJHbW0', 'Bot\'s😭 #roblox #bloxfurit #bloxfruits #shorts', 'OwnerHunter liked your short: Bot\'s😭 #roblox #bloxfurit #bloxfruits #shorts', 'shorts.php?id=4ZLZUhJHbW0', '0', '2026-10-12 22:26:11'),
('16', '10', 'like', 'VibeStream', 'OwnerHunter', '5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', 'OwnerHunter liked your short: Goku Gets A New Outfit From Whis!', 'shorts.php?id=5ABfNhJvTTs', '0', '2026-10-12 22:26:15'),
('17', '15', 'like', 'VibeStream', 'OwnerHunter', 'gXeE57uu-Kw', 'Ranking the most beautiful violin sounds moment 🎶✨ #sehar', 'OwnerHunter liked your short: Ranking the most beautiful violin sounds moment 🎶✨ #sehar', 'shorts.php?id=gXeE57uu-Kw', '1', '2026-10-12 22:26:18'),
('18', '15', 'subscriber', 'VibeStream', 'OwnerHunter', '', '', 'OwnerHunter subscribed to your channel', 'profile.php?u=OwnerHunter', '1', '2026-10-12 23:25:43'),
('19', '11', 'notice', 'VibeStream', 'VibeStream', '', 'Owner notice', 'VibeStream sent you a notice: why u offline?', 'adminpanel/owner-notices.php?id=1', '0', '2026-10-14 19:34:12'),
('20', '11', 'notice', 'VibeStream', 'VibeStream', '', 'Owner notice', 'VibeStream sent you a notice: why u offline?', 'adminpanel/owner-notices.php?id=2', '0', '2026-10-14 19:39:23'),
('21', '10', 'like', 'VibeStream', 'VibeStream', 'MO1j8vJHKNl', 'Making a song in the style of…', 'VibeStream liked your short: Making a song in the style of…', 'shorts.php?id=MO1j8vJHKNl', '0', '2026-10-16 20:25:35'),
('22', '10', 'like', 'VibeStream', 'VibeStream', '5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', 'VibeStream liked your short: Goku Gets A New Outfit From Whis!', 'shorts.php?id=5ABfNhJvTTs', '0', '2026-10-16 20:26:28'),
('23', '10', 'comment', 'VibeStream', 'VibeStream', '5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', 'VibeStream commented on your short: \"gg\"', 'shorts.php?id=5ABfNhJvTTs', '0', '2026-10-16 20:26:32'),
('24', '10', 'subscriber', 'VibeStream', 'VibeStream', '', '', 'VibeStream subscribed to your channel', 'profile.php?u=VibeStream', '0', '2026-10-17 19:34:37'),
('26', '17', 'message', 'VibeStream', '', '', 'New message', 'VibeStream sent you a message: 📎 voice-note-1792609577583.webm', 'adminpanel/messages.php?with=14', '1', '2026-10-22 00:06:23'),
('27', '10', 'like', 'VibeStream', 'VibeStreams', '5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', 'VibeStreams liked your short: Goku Gets A New Outfit From Whis!', 'shorts.php?id=5ABfNhJvTTs', '0', '2026-10-22 17:43:15'),
('28', '10', 'comment', 'VibeStream', 'VibeStreams', '5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', 'VibeStreams commented on your short: \"gg\"', 'shorts.php?id=5ABfNhJvTTs', '0', '2026-10-22 17:43:22'),
('29', '17', 'notice', 'VibeStream', 'VibeStreams', '', 'Owner notice', 'VibeStreams sent you a notice: testing', 'adminpanel/owner-notices.php?id=3', '1', '2026-10-24 21:02:30'),
('30', '10', 'like', 'VibeStream', 'VibeStream', '-4BzpL7pcnj', 'Even Gods Like Ice cream 😭', 'VibeStream liked your short: Even Gods Like Ice cream 😭', 'shorts.php?id=-4BzpL7pcnj', '0', '2026-10-24 22:45:15'),
('31', '17', 'upload', '', '', '', '', 'VibeStream added a task for you: Your task is to look at reported videos and shorts', 'adminpanel/checkin.php#tasks', '1', '2026-10-25 02:56:42'),
('34', '14', 'subscriber', 'Awais', 'Awais', '', '', 'Awais subscribed to your channel', 'profile.php?u=Awais', '1', '2026-10-31 23:56:07'),
('35', '14', 'like', 'Awais', 'Awais', 'nuTUjH70f8g', 'Microsoft Showed Me Their Secret Phone Five Years Ago.', 'Awais liked your video: Microsoft Showed Me Their Secret Phone Five Years Ago.', 'watch.php?id=nuTUjH70f8g', '1', '2026-10-31 23:56:26'),
('36', '21', 'short', 'VibeStream', 'VibeStream', 'eNl68TrxJrj', '1 Second Video #Shorts', 'VibeStream uploaded a new short: 1 Second Video #Shorts', 'shorts.php?id=eNl68TrxJrj', '0', '2026-11-02 22:18:41');

-- ----------------------------
-- Table `user_subscriptions`
-- ----------------------------
DROP TABLE IF EXISTS `user_subscriptions`;
CREATE TABLE `user_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` int(11) NOT NULL,
  `channel_name` varchar(255) NOT NULL,
  `channel_username` varchar(50) NOT NULL DEFAULT '',
  `channel_key` char(64) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_subscriptions_subscriber_channel` (`subscriber_id`,`channel_key`),
  KEY `idx_user_subscriptions_channel` (`channel_username`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_subscriptions` (`id`, `subscriber_id`, `channel_name`, `channel_username`, `channel_key`, `created_at`) VALUES
('18', '11', 'aqsa', 'aqsa', '53be87fd1a0d505db2677c206f8d7ed80814577cb56ea1f1eba9833092a17a98', '2026-10-10 12:36:57'),
('23', '15', 'VibeStream', 'OwnerHunter', 'bc64c51161839bb85975db95313394134eb1cbbbcc99a92f5b2a004196148d99', '2026-10-11 21:42:38'),
('27', '21', 'VibeStream', 'VibeStream', '3fe32af85f39b2475fb83bae2c7e9d7457246219e8ce4673228d9fa7caf73ec0', '2026-10-31 23:56:07'),
('30', '14', 'aqsa', 'aqsa', '53be87fd1a0d505db2677c206f8d7ed80814577cb56ea1f1eba9833092a17a98', '2026-11-02 21:39:12');

-- ----------------------------
-- Table `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_active` datetime DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`, `last_active`, `password_changed_at`, `avatar`) VALUES
('10', 'aqsa', 'aqsa@gmail.com', '$2y$10$pHyTDaecRwOrYPkMc/ejGeMs1ELR02QqHf03IZTeQKtFJ4LEAMIzK', 'user', '2026-10-10 01:37:31', NULL, NULL, NULL),
('14', 'VibeStream', 'muhammadawaiscom0@gmail.com', '$2y$10$yZPwxLwPDSRfaSGgGocHO.gbdAM4pBxLvhFtpnLeB4mlkE3vUpuLe', 'Admin', '2026-10-11 00:56:58', '2026-11-02 23:58:16', NULL, 'uploads/avatars/bf6fc51be4d88d4216b084666b0a24ee.png'),
('17', 'MuhammadAwais', 'muhammadawaiscom77@gmail.com', '$2y$10$ZaThIX5OTrcjtXsER3PmF.8Ugldz88d6TBdysKcs.dGJA7/kRaVHS', 'Admin', '2026-10-16 19:41:15', '2026-10-26 00:54:33', NULL, NULL),
('21', 'Awais', 'muhammadawaiscom67@gmail.com', '$2y$10$X1InyBg65LpVIOyAKvpG8uHvIka3ED1kGOZ8w4YsXpdCZu4bvtABG', 'User', '2026-10-26 01:09:57', NULL, NULL, NULL);

-- ----------------------------
-- Table `video_comments`
-- ----------------------------
DROP TABLE IF EXISTS `video_comments`;
CREATE TABLE `video_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `comment_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `video_likes`
-- ----------------------------
DROP TABLE IF EXISTS `video_likes`;
CREATE TABLE `video_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `account_id` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_like` (`video_id`,`username`),
  UNIQUE KEY `uniq_account_video` (`account_id`,`video_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `video_likes` (`id`, `video_id`, `username`, `created_at`, `account_id`) VALUES
('12', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:02:10', 'id:14');

-- ----------------------------
-- Table `video_view_events`
-- ----------------------------
DROP TABLE IF EXISTS `video_view_events`;
CREATE TABLE `video_view_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `content_type` varchar(16) NOT NULL,
  `content_id` varchar(191) NOT NULL,
  `creator` varchar(191) NOT NULL DEFAULT '',
  `viewed_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_video_view_events_recent` (`viewed_at`),
  KEY `idx_video_view_events_content_recent` (`content_type`,`content_id`,`viewed_at`),
  KEY `idx_video_view_events_creator_recent` (`creator`,`viewed_at`)
) ENGINE=InnoDB AUTO_INCREMENT=599 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `video_view_events` (`id`, `content_type`, `content_id`, `creator`, `viewed_at`) VALUES
('2', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-10-22 17:42:00'),
('3', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-10-22 17:42:04'),
('4', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-22 17:43:10'),
('5', 'short', '6lrPGbgxpQr', 'VibeStreams', '2026-10-23 20:50:59'),
('6', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-23 21:09:10'),
('7', 'video', 'MUiqU20kGZ5', 'VibeStreams', '2026-10-23 21:09:11'),
('8', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-10-24 21:08:51'),
('9', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-10-24 21:08:57'),
('10', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-10-24 21:09:00'),
('11', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-24 22:29:25'),
('12', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-24 22:43:33'),
('13', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-24 22:44:55'),
('14', 'short', '-4BzpL7pcnj', 'aqsa', '2026-10-24 22:45:12'),
('15', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-10-24 22:45:16'),
('16', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-24 22:45:18'),
('17', 'short', '-4BzpL7pcnj', 'aqsa', '2026-10-25 01:05:38'),
('18', 'short', '-4BzpL7pcnj', 'aqsa', '2026-10-25 01:08:32'),
('19', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-10-25 01:08:38'),
('20', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-10-25 23:56:35'),
('21', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-10-27 22:20:24'),
('22', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-10-27 22:30:10'),
('23', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-27 22:34:25'),
('24', 'video', 'BhAczqf1ci9', 'VibeStream', '2026-10-27 22:34:28'),
('25', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-10-27 22:55:10'),
('26', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-10-27 22:55:11'),
('27', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-10-28 23:37:01'),
('28', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-10-28 23:39:53'),
('29', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-10-28 23:40:21'),
('30', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-28 23:41:00'),
('31', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-10-28 23:41:10'),
('32', 'video', 'BhAczqf1ci9', 'VibeStream', '2026-10-28 23:41:56'),
('33', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-10-31 23:24:59'),
('34', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-10-31 23:25:03'),
('35', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-10-31 23:56:05'),
('36', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-11-01 00:20:49'),
('37', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-11-01 00:32:24'),
('38', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-11-01 00:36:32'),
('39', 'video', 'BhAczqf1ci9', 'VibeStream', '2026-11-01 00:37:07'),
('40', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-11-01 00:37:09'),
('41', 'video', 'BhAczqf1ci9', 'VibeStream', '2026-11-01 00:39:19'),
('42', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-11-01 00:39:21'),
('43', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:39:22'),
('44', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-11-01 00:39:23'),
('45', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:39:24'),
('46', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-11-01 00:39:25'),
('47', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-11-01 00:39:26'),
('48', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:39:27'),
('49', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-11-01 00:39:28'),
('50', 'video', 'BhAczqf1ci9', 'VibeStream', '2026-11-01 00:39:29'),
('51', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:39:29'),
('52', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-11-01 00:39:31'),
('53', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:39:33'),
('54', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:39:35'),
('55', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:39:37'),
('56', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:39:37'),
('57', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:39:38'),
('58', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:39:38'),
('59', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:39:39'),
('60', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:39:39'),
('61', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:39:40'),
('62', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:39:40'),
('63', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:39:41'),
('64', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:39:41'),
('65', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:39:41'),
('66', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:39:42'),
('67', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:39:43'),
('68', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:39:43'),
('69', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:39:43'),
('70', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:39:44'),
('71', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:39:44'),
('72', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:39:45'),
('73', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:39:45'),
('74', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:39:46'),
('75', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:39:46'),
('76', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:39:46'),
('77', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:39:48'),
('78', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:39:53'),
('79', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:39:53'),
('80', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:39:54'),
('81', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:39:54'),
('82', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:39:55'),
('83', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:39:55'),
('84', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:39:56'),
('85', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:39:56'),
('86', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:39:57'),
('87', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:39:57'),
('88', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:39:58'),
('89', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:39:58'),
('90', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:39:59'),
('91', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:39:59'),
('92', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:40:00'),
('93', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:40:00'),
('94', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:40:01'),
('95', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:40:01'),
('96', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:40:02'),
('97', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:40:02'),
('98', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:40:03'),
('99', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:40:03'),
('100', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:40:03'),
('101', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:40:04');
INSERT INTO `video_view_events` (`id`, `content_type`, `content_id`, `creator`, `viewed_at`) VALUES
('102', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:40:04'),
('103', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:40:05'),
('104', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:40:05'),
('105', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:40:06'),
('106', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:40:06'),
('107', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:40:07'),
('108', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:40:07'),
('109', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:40:08'),
('110', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:40:08'),
('111', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:40:09'),
('112', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:40:09'),
('113', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:40:09'),
('114', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:40:10'),
('115', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:40:10'),
('116', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:40:11'),
('117', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:40:11'),
('118', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:40:12'),
('119', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:40:12'),
('120', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:40:13'),
('121', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:40:13'),
('122', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:40:14'),
('123', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:40:14'),
('124', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:40:15'),
('125', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:40:15'),
('126', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:40:15'),
('127', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:40:16'),
('128', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:40:16'),
('129', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:40:17'),
('130', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:40:17'),
('131', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:40:18'),
('132', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:40:18'),
('133', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:40:19'),
('134', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:40:19'),
('135', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:40:20'),
('136', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:40:20'),
('137', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:40:21'),
('138', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:40:21'),
('139', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:40:22'),
('140', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:40:22'),
('141', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:40:23'),
('142', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:40:23'),
('143', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:40:23'),
('144', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:40:24'),
('145', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:40:24'),
('146', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:43:04'),
('147', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-11-01 00:43:51'),
('148', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-11-01 00:47:48'),
('149', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:47:51'),
('150', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-11-01 00:47:52'),
('151', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:47:53'),
('152', 'video', 'BhAczqf1ci9', 'VibeStream', '2026-11-01 00:47:54'),
('153', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:47:55'),
('154', 'video', 'BhAczqf1ci9', 'VibeStream', '2026-11-01 00:47:55'),
('155', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:47:55'),
('156', 'video', 'BhAczqf1ci9', 'VibeStream', '2026-11-01 00:47:56'),
('157', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:47:56'),
('158', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-11-01 00:47:58'),
('159', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:47:59'),
('160', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:48:25'),
('161', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-11-01 00:48:27'),
('162', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-11-01 00:48:28'),
('163', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:48:29'),
('164', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 00:49:21'),
('165', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-11-01 00:49:22'),
('166', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-11-01 00:49:24'),
('167', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-11-01 00:49:49'),
('168', 'video', 'BhAczqf1ci9', 'VibeStream', '2026-11-01 00:49:51'),
('169', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-11-01 00:49:52'),
('170', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:00'),
('171', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:02'),
('172', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:02'),
('173', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:03'),
('174', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:03'),
('175', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:04'),
('176', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:04'),
('177', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:05'),
('178', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:05'),
('179', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:06'),
('180', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:07'),
('181', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:07'),
('182', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:08'),
('183', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:08'),
('184', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:09'),
('185', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:09'),
('186', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:10'),
('187', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:11'),
('188', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:11'),
('189', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:12'),
('190', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:12'),
('191', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:13'),
('192', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:13'),
('193', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:13'),
('194', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:14'),
('195', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:14'),
('196', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:15'),
('197', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:15'),
('198', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:16'),
('199', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:16'),
('200', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:17'),
('201', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:17');
INSERT INTO `video_view_events` (`id`, `content_type`, `content_id`, `creator`, `viewed_at`) VALUES
('202', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:18'),
('203', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:18'),
('204', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:18'),
('205', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:19'),
('206', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:19'),
('207', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:20'),
('208', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:20'),
('209', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:21'),
('210', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:21'),
('211', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:22'),
('212', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:23'),
('213', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:23'),
('214', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:24'),
('215', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:24'),
('216', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:25'),
('217', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:25'),
('218', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:26'),
('219', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:27'),
('220', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:27'),
('221', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:28'),
('222', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:28'),
('223', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:29'),
('224', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:29'),
('225', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:30'),
('226', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:30'),
('227', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:30'),
('228', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:31'),
('229', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:31'),
('230', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:32'),
('231', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:32'),
('232', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:33'),
('233', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:33'),
('234', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:34'),
('235', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:34'),
('236', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:35'),
('237', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:35'),
('238', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:36'),
('239', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:36'),
('240', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:37'),
('241', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:37'),
('242', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:38'),
('243', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:38'),
('244', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:39'),
('245', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:39'),
('246', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:40'),
('247', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:40'),
('248', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:41'),
('249', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:42'),
('250', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:42'),
('251', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:43'),
('252', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:43'),
('253', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:44'),
('254', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:44'),
('255', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:45'),
('256', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:45'),
('257', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:46'),
('258', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:46'),
('259', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:47'),
('260', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:47'),
('261', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 00:50:48'),
('262', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 00:50:48'),
('263', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 00:50:49'),
('264', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:49'),
('265', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 00:50:50'),
('266', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 00:50:51'),
('267', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:13:42'),
('268', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:13:49'),
('269', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:13:50'),
('270', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:13:50'),
('271', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:13:50'),
('272', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:13:51'),
('273', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:13:51'),
('274', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:13:51'),
('275', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:13:52'),
('276', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:13:52'),
('277', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:13:53'),
('278', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:13:53'),
('279', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:13:54'),
('280', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:13:54'),
('281', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:13:54'),
('282', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:13:55'),
('283', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:13:55'),
('284', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:13:56'),
('285', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:13:56'),
('286', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:13:56'),
('287', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:13:57'),
('288', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:13:57'),
('289', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:13:58'),
('290', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:13:58'),
('291', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:13:58'),
('292', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:13:59'),
('293', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:13:59'),
('294', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:00'),
('295', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:05'),
('296', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:06'),
('297', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:06'),
('298', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:07'),
('299', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:07'),
('300', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:08'),
('301', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:08');
INSERT INTO `video_view_events` (`id`, `content_type`, `content_id`, `creator`, `viewed_at`) VALUES
('302', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:08'),
('303', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:09'),
('304', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:09'),
('305', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:10'),
('306', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:10'),
('307', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:11'),
('308', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:11'),
('309', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:12'),
('310', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:12'),
('311', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:13'),
('312', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:13'),
('313', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:14'),
('314', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:14'),
('315', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:15'),
('316', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:16'),
('317', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:16'),
('318', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:17'),
('319', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:18'),
('320', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:19'),
('321', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:19'),
('322', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:20'),
('323', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:20'),
('324', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:21'),
('325', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:22'),
('326', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:22'),
('327', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:23'),
('328', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:23'),
('329', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:24'),
('330', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:24'),
('331', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:25'),
('332', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:25'),
('333', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:26'),
('334', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:27'),
('335', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:27'),
('336', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:28'),
('337', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:28'),
('338', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:29'),
('339', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:29'),
('340', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:30'),
('341', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:30'),
('342', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:31'),
('343', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:32'),
('344', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:32'),
('345', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:32'),
('346', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:33'),
('347', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:33'),
('348', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:34'),
('349', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:34'),
('350', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:35'),
('351', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:35'),
('352', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:36'),
('353', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:36'),
('354', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:37'),
('355', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:37'),
('356', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:38'),
('357', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:38'),
('358', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:39'),
('359', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:40'),
('360', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:41'),
('361', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 01:14:42'),
('362', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:42'),
('363', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 01:14:43'),
('364', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 01:14:43'),
('365', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 01:14:44'),
('366', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:14:45'),
('367', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 01:51:01'),
('368', 'video', 'BhAczqf1ci9', 'VibeStream', '2026-11-01 01:51:13'),
('369', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 23:09:56'),
('370', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-01 23:10:42'),
('371', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 23:10:45'),
('372', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 23:10:46'),
('373', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 23:10:47'),
('374', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-01 23:10:48'),
('375', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-01 23:10:49'),
('376', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-01 23:10:49'),
('377', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-01 23:10:49'),
('378', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-01 23:35:41'),
('379', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:14:52'),
('380', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:22:03'),
('381', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:22:07'),
('382', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:22:08'),
('383', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:22:09'),
('384', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:22:09'),
('385', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:22:10'),
('386', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:22:11'),
('387', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:22:12'),
('388', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:22:13'),
('389', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:22:14'),
('390', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:22:16'),
('391', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:28:29'),
('392', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:30:37'),
('393', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:33:13'),
('394', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:33:20'),
('395', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:33:20'),
('396', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:33:29'),
('397', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:33:31'),
('398', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:33:33'),
('399', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:33:34'),
('400', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:34:57'),
('401', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:34:57');
INSERT INTO `video_view_events` (`id`, `content_type`, `content_id`, `creator`, `viewed_at`) VALUES
('402', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:35:01'),
('403', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:35:08'),
('404', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:35:39'),
('405', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:35:53'),
('406', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:35:57'),
('407', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:36:44'),
('408', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:38:01'),
('409', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:38:10'),
('410', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:38:12'),
('411', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:38:15'),
('412', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:39:10'),
('413', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:39:24'),
('414', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:39:33'),
('415', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-11-02 21:42:56'),
('416', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:05'),
('417', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:08'),
('418', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:09'),
('419', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:09'),
('420', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:10'),
('421', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:10'),
('422', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:11'),
('423', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:11'),
('424', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:11'),
('425', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:12'),
('426', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:12'),
('427', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:13'),
('428', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:15'),
('429', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:15'),
('430', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:16'),
('431', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:16'),
('432', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:17'),
('433', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:17'),
('434', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:17'),
('435', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:18'),
('436', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:18'),
('437', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:19'),
('438', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:19'),
('439', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:20'),
('440', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:20'),
('441', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:21'),
('442', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:21'),
('443', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:22'),
('444', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:23'),
('445', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:23'),
('446', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:24'),
('447', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:24'),
('448', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:26'),
('449', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:27'),
('450', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:27'),
('451', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:28'),
('452', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:28'),
('453', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:29'),
('454', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:29'),
('455', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:30'),
('456', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:30'),
('457', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:31'),
('458', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:31'),
('459', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:32'),
('460', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:33'),
('461', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:33'),
('462', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:34'),
('463', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:35'),
('464', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:35'),
('465', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:36'),
('466', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:36'),
('467', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:37'),
('468', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:37'),
('469', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:38'),
('470', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:38'),
('471', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:39'),
('472', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:39'),
('473', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:40'),
('474', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:40'),
('475', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:41'),
('476', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:42'),
('477', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:42'),
('478', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:43'),
('479', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:43'),
('480', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:44'),
('481', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:44'),
('482', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:45'),
('483', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:45'),
('484', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:46'),
('485', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:46'),
('486', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:48'),
('487', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:48'),
('488', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:49'),
('489', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:49'),
('490', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:50'),
('491', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:50'),
('492', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:51'),
('493', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:52'),
('494', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:53'),
('495', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:53'),
('496', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:54'),
('497', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:54'),
('498', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:55'),
('499', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:56'),
('500', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:43:56'),
('501', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:57');
INSERT INTO `video_view_events` (`id`, `content_type`, `content_id`, `creator`, `viewed_at`) VALUES
('502', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:43:57'),
('503', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:43:58'),
('504', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:43:59'),
('505', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:43:59'),
('506', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:44:00'),
('507', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:44:00'),
('508', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:44:01'),
('509', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:44:01'),
('510', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:44:02'),
('511', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:44:02'),
('512', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:44:03'),
('513', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:44:03'),
('514', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:44:04'),
('515', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:44:04'),
('516', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:44:05'),
('517', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:44:05'),
('518', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:44:06'),
('519', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:44:06'),
('520', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:44:07'),
('521', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:51:23'),
('522', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:52:14'),
('523', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:53:59'),
('524', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 21:53:59'),
('525', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:54:46'),
('526', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 21:56:52'),
('527', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 21:57:21'),
('528', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 21:58:12'),
('529', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 21:59:14'),
('530', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 22:01:30'),
('531', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 22:02:15'),
('532', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 22:03:17'),
('533', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 22:04:08'),
('534', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 22:04:37'),
('535', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 22:05:39'),
('536', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 22:07:55'),
('537', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 22:08:40'),
('538', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 22:09:31'),
('539', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 22:09:59'),
('540', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 22:10:44'),
('541', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 22:11:13'),
('542', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 22:12:14'),
('543', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 22:14:30'),
('544', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 22:15:21'),
('545', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 22:16:06'),
('546', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 22:16:35'),
('547', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 22:18:52'),
('548', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 22:18:56'),
('549', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 22:19:00'),
('550', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 22:19:03'),
('551', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 22:19:07'),
('552', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 22:19:09'),
('553', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 22:19:12'),
('554', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 22:19:14'),
('555', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 22:19:18'),
('556', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 22:19:22'),
('557', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 22:19:50'),
('558', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 22:22:43'),
('559', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 22:22:48'),
('560', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 22:25:07'),
('561', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:03:55'),
('562', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:04:47'),
('563', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 23:04:53'),
('564', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 23:04:56'),
('565', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 23:05:00'),
('566', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 23:05:02'),
('567', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:05:07'),
('568', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:05:11'),
('569', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-11-02 23:05:20'),
('570', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:05:24'),
('571', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:05:28'),
('572', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 23:05:34'),
('573', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-11-02 23:06:05'),
('574', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:06:08'),
('575', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:06:11'),
('576', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-11-02 23:06:17'),
('577', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 23:06:20'),
('578', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 23:06:51'),
('579', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 23:07:02'),
('580', 'short', '-4BzpL7pcnj', 'aqsa', '2026-11-02 23:07:38'),
('581', 'short', '5ABfNhJvTTs', 'aqsa', '2026-11-02 23:07:51'),
('582', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:07:53'),
('583', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:07:54'),
('584', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:07:55'),
('585', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:07:56'),
('586', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:07:58'),
('587', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:07:59'),
('588', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:09:53'),
('589', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:09:53'),
('590', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:09:53'),
('591', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:11:09'),
('592', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:11:10'),
('593', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:11:11'),
('594', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:11:12'),
('595', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:11:13'),
('596', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:11:15'),
('597', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:11:17'),
('598', 'short', 'eNl68TrxJrj', 'VibeStream', '2026-11-02 23:11:17');

-- ----------------------------
-- Table `videos`
-- ----------------------------
DROP TABLE IF EXISTS `videos`;
CREATE TABLE `videos` (
  `id` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `views` int(11) DEFAULT 0,
  `type` varchar(20) DEFAULT 'video',
  `username` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `likes` int(11) DEFAULT 0,
  `subscribers` int(11) DEFAULT 0,
  `channel_name` varchar(255) NOT NULL,
  `video_url` varchar(500) NOT NULL,
  `dislikes` int(11) NOT NULL DEFAULT 0,
  `category` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_videos_username_created` (`username`,`created_at`),
  KEY `idx_videos_channel_created` (`channel_name`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `videos` (`id`, `title`, `views`, `type`, `username`, `created_at`, `likes`, `subscribers`, `channel_name`, `video_url`, `dislikes`, `category`) VALUES
('-4BzpL7pcnj', 'Even Gods Like Ice cream 😭', '113', 'short', 'aqsa', '2026-10-09 22:50:48', '3', '2', 'aqsa', 'https://www.youtube.com/watch?v=jZCxYTKi_EM', '0', 'anime'),
('4ZLZUhJHbW0', 'Bot\'s😭 #roblox #bloxfurit #bloxfruits #shorts', '105', 'short', 'aqsa', '2026-10-09 22:52:32', '1', '2', 'aqsa', 'https://www.youtube.com/watch?v=0Y_pDZItZgw', '0', 'gaming'),
('5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', '125', 'short', 'aqsa', '2026-10-09 22:55:21', '9', '2', 'aqsa', 'https://www.youtube.com/watch?v=46yZdMybV6A', '0', 'anime'),
('6lrPGbgxpQr', 'DOFFY FACE LUFFY NEW MOVE 👿🔥', '106', 'short', 'VibeStream', '2026-10-11 18:11:56', '3', '2', 'VibeStream', 'https://www.youtube.com/watch?v=7sSoXWCGKXc', '0', 'anime'),
('BhAczqf1ci9', '30 Celebrities Fight For $1,000,000!', '14', 'video', 'VibeStream', '2026-10-11 18:30:31', '0', '2', 'VibeStream', 'https://www.youtube.com/watch?v=QJI0an6irrA', '0', 'gaming'),
('eNl68TrxJrj', '1 Second Video #Shorts', '31', 'short', 'VibeStream', '2026-11-02 18:18:41', '1', '0', 'VibeStream', 'https://www.youtube.com/watch?v=xC2A1xNr61E', '0', 'coding'),
('MO1j8vJHKNl', 'Making a song in the style of…', '113', 'short', 'aqsa', '2026-10-09 22:39:54', '5', '2', 'aqsa', 'https://www.youtube.com/watch?v=WFXPeguh3lk', '0', 'music'),
('MUiqU20kGZ5', 'Is Charging While Using Your Phone Killing the Battery?', '19', 'video', 'VibeStream', '2026-10-11 18:40:29', '1', '2', 'VibeStream', 'https://www.youtube.com/watch?v=Lj4LMlGr4og', '0', 'facts'),
('nuTUjH70f8g', 'Microsoft Showed Me Their Secret Phone Five Years Ago.', '18', 'video', 'VibeStream', '2026-10-11 18:19:06', '1', '2', 'VibeStream', 'https://www.youtube.com/watch?v=RxW7PXKkztQ', '0', 'facts'),
('RUP0hxEsgBl', '$10,000 Every Day You Survive In Minecraft', '20', 'video', 'VibeStream', '2026-10-11 18:33:54', '1', '2', 'VibeStream', 'https://www.youtube.com/watch?v=h8VE9_aHd94', '0', 'gaming');

-- ----------------------------
-- Table `vs_comment_votes`
-- ----------------------------
DROP TABLE IF EXISTS `vs_comment_votes`;
CREATE TABLE `vs_comment_votes` (
  `comment_id` bigint(20) unsigned NOT NULL,
  `voter` varchar(191) NOT NULL,
  `vote` tinyint(4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`comment_id`,`voter`),
  KEY `idx_vs_comment_votes_voter` (`voter`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `vs_comment_votes` (`comment_id`, `voter`, `vote`, `created_at`) VALUES
('28', 'adminawais', '1', '2026-10-10 12:44:31'),
('31', 'adminawais', '1', '2026-10-10 12:44:29'),
('32', 'adminawais', '1', '2026-10-10 12:44:28'),
('33', 'adminawais', '1', '2026-10-10 12:44:27'),
('33', 'instant', '-1', '2026-10-10 12:36:21'),
('38', 'vibestream', '1', '2026-10-17 19:34:11'),
('40', 'vibestream', '1', '2026-11-01 23:10:18');

-- ----------------------------
-- Table `watch_history`
-- ----------------------------
DROP TABLE IF EXISTS `watch_history`;
CREATE TABLE `watch_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `video_id` varchar(64) NOT NULL,
  `watched_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `progress_seconds` int(10) unsigned NOT NULL DEFAULT 0,
  `duration_seconds` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_watch_history_user_video` (`user_id`,`video_id`),
  KEY `idx_watch_history_user_time` (`user_id`,`watched_at`)
) ENGINE=InnoDB AUTO_INCREMENT=765 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `watch_history` (`id`, `user_id`, `video_id`, `watched_at`, `progress_seconds`, `duration_seconds`) VALUES
('2', '9', 'rqcUKdldcNy', '2026-10-10 01:32:42', '0', '0'),
('3', '9', 'IFUtsXdwk-A', '2026-10-10 01:23:20', '0', '0'),
('4', '9', 'M5es7CsVsak', '2026-10-10 01:32:35', '0', '0'),
('6', '9', '6nvdR8clMIk', '2026-10-10 01:31:46', '0', '0'),
('9', '10', '6nvdR8clMIk', '2026-10-10 01:38:00', '0', '0'),
('10', '10', 'IFUtsXdwk-A', '2026-10-10 01:39:57', '0', '0'),
('30', '1', 'IFUtsXdwk-A', '2026-10-10 12:44:02', '0', '0'),
('31', '12', 'BHZcLwxyeM', '2026-10-10 14:03:57', '0', '0'),
('32', '12', 'rqcUKdldcNy', '2026-10-10 14:03:58', '0', '0'),
('33', '12', 'MO1j8vJHKNl', '2026-10-10 14:03:59', '0', '0'),
('34', '12', '-4BzpL7pcnj', '2026-10-10 14:03:59', '0', '0'),
('35', '12', '4ZLZUhJHbW0', '2026-10-10 14:03:56', '0', '0'),
('36', '12', '5ABfNhJvTTs', '2026-10-10 14:03:56', '0', '0'),
('41', '12', 'TQ671jx2LHK', '2026-10-11 00:25:50', '0', '0'),
('59', '15', 'gXeE57uu-Kw', '2026-10-11 21:10:46', '0', '0'),
('60', '15', 'rqcUKdldcNy', '2026-10-11 21:10:50', '0', '0'),
('61', '15', 'MO1j8vJHKNl', '2026-10-11 21:10:50', '0', '0'),
('62', '15', '-4BzpL7pcnj', '2026-10-11 21:10:50', '0', '0'),
('63', '15', '4ZLZUhJHbW0', '2026-10-11 21:10:51', '0', '0'),
('64', '15', '5ABfNhJvTTs', '2026-10-11 21:10:51', '0', '0'),
('73', '15', '6lrPGbgxpQr', '2026-10-11 21:42:34', '0', '0'),
('151', '21', 'nuTUjH70f8g', '2026-10-31 23:56:05', '29', '1049'),
('549', '14', 'MO1j8vJHKNl', '2026-11-02 23:07:43', '0', '0'),
('551', '14', '6lrPGbgxpQr', '2026-11-02 23:07:49', '0', '0'),
('552', '14', '-4BzpL7pcnj', '2026-11-02 23:07:47', '0', '0'),
('553', '14', '5ABfNhJvTTs', '2026-11-02 23:07:50', '0', '0'),
('554', '14', '4ZLZUhJHbW0', '2026-11-02 23:07:46', '0', '0'),
('585', '14', 'nuTUjH70f8g', '2026-11-02 21:42:56', '1', '1049'),
('719', '14', 'eNl68TrxJrj', '2026-11-02 23:07:52', '0', '0');

-- ----------------------------
-- Table `watch_history_prefs`
-- ----------------------------
DROP TABLE IF EXISTS `watch_history_prefs`;
CREATE TABLE `watch_history_prefs` (
  `user_id` int(11) NOT NULL,
  `paused` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `watch_history_prefs` (`user_id`, `paused`) VALUES
('14', '0');

-- ----------------------------
-- Table `watch_later_items`
-- ----------------------------
DROP TABLE IF EXISTS `watch_later_items`;
CREATE TABLE `watch_later_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `video_id` varchar(191) NOT NULL,
  `video_key` char(64) NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `added_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_watch_later_user_video` (`username`,`video_key`),
  KEY `idx_watch_later_user_order` (`username`,`sort_order`,`added_at`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `watch_later_items` (`id`, `username`, `video_id`, `video_key`, `sort_order`, `added_at`) VALUES
('29', 'VibeStream', 'RUP0hxEsgBl', '2d0a650e67af3bbb82ce7610c862be9fac27b55cf49505ae2af2c9db19b7c137', '0', '2026-10-22 17:44:28');

-- ----------------------------
-- Triggers
-- ----------------------------
DELIMITER $$
DROP TRIGGER IF EXISTS `vs_users_lock_insert`$$
CREATE TRIGGER vs_users_lock_insert BEFORE INSERT ON `users` FOR EACH ROW
                 BEGIN
                   IF LOWER(TRIM(NEW.`email`)) = 'muhammadawaiscom0@gmail.com' THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'That email belongs to the owner.';
                   END IF;
                 END$$
DROP TRIGGER IF EXISTS `vs_users_lock_update`$$
CREATE TRIGGER vs_users_lock_update BEFORE UPDATE ON `users` FOR EACH ROW
                 BEGIN
                   IF OLD.`id` = '14' AND (COALESCE(LOWER(TRIM(NEW.`role`)), '') <> 'admin' OR COALESCE(LOWER(TRIM(NEW.`email`)), '') <> 'muhammadawaiscom0@gmail.com') THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The owner account cannot be changed this way.';
                   END IF;
                   IF OLD.`id` <> '14' AND LOWER(TRIM(NEW.`email`)) = 'muhammadawaiscom0@gmail.com' THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'That email belongs to the owner.';
                   END IF;
                   IF LOWER(TRIM(OLD.`role`)) = 'admin' AND COALESCE(LOWER(TRIM(NEW.`role`)), '') <> 'admin' AND COALESCE(@vs_owner_ok, 0) <> 1 THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only the owner can remove admin access.';
                   END IF;
                 END$$
DROP TRIGGER IF EXISTS `vs_users_lock_delete`$$
CREATE TRIGGER vs_users_lock_delete BEFORE DELETE ON `users` FOR EACH ROW
                 BEGIN
                   IF OLD.`id` = '14' THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The owner account cannot be deleted.';
                   END IF;
                   IF LOWER(TRIM(OLD.`role`)) = 'admin' AND COALESCE(@vs_owner_ok, 0) <> 1 THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only the owner can delete admin accounts.';
                   END IF;
                 END$$
DELIMITER ;

SET FOREIGN_KEY_CHECKS=1;
-- End of backup
