-- VibeStream database backup
-- Created: 2026-10-27 19:58:39
-- Database: vibestream

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

-- ----------------------------
-- Table `admin_activity_log`
-- ----------------------------
DROP TABLE IF EXISTS `admin_activity_log`;
CREATE TABLE `admin_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(100) NOT NULL,
  `action` varchar(30) NOT NULL,
  `details` varchar(500) NOT NULL DEFAULT '',
  `page` varchar(100) NOT NULL DEFAULT '',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_time` (`admin_username`,`created_at`),
  KEY `idx_time` (`created_at`),
  KEY `idx_action` (`action`)
) ENGINE=InnoDB AUTO_INCREMENT=1286 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('521', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-21 22:00:03'),
('522', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-21 22:00:07'),
('523', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-21 22:00:11'),
('524', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-21 22:08:07'),
('525', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-21 22:08:47'),
('526', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-21 22:10:20'),
('527', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-21 22:10:49'),
('528', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-21 22:10:52'),
('529', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-21 22:10:56'),
('530', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-21 22:10:59'),
('531', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-21 22:11:01'),
('532', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-21 22:19:59'),
('533', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-21 22:19:59'),
('534', 'VibeStream', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-21 22:20:05'),
('535', 'VibeStream', 'premium', 'Declined Premium request #2', 'notifications.php', '::1', '2026-10-21 22:20:09'),
('536', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-21 23:21:16'),
('537', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-21 23:21:16'),
('538', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-21 23:22:46'),
('539', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-21 23:28:02'),
('540', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-21 23:28:04'),
('541', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-21 23:28:12'),
('542', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-21 23:32:17'),
('543', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-21 23:32:31'),
('544', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-21 23:33:35'),
('545', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-21 23:33:43'),
('546', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-21 23:34:13'),
('547', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-21 23:34:19'),
('548', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-21 23:42:24'),
('549', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-21 23:42:26'),
('550', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-21 23:45:10'),
('551', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-21 23:57:05'),
('552', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-21 23:57:11'),
('553', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-22 00:05:45'),
('554', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-22 00:13:48'),
('555', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-22 00:13:58'),
('556', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-22 00:18:08'),
('557', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-22 00:18:12'),
('558', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-22 00:25:22'),
('559', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-22 00:25:29'),
('560', 'VibeStream', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-22 00:26:03'),
('561', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-22 00:26:05'),
('562', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-22 00:26:06'),
('563', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-22 00:26:07'),
('564', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-22 00:26:09'),
('565', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-22 00:26:10'),
('566', 'VibeStream', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-22 00:26:14'),
('567', 'VibeStream', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-22 00:40:16'),
('568', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-22 00:40:19'),
('569', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-22 00:40:24'),
('570', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-22 00:40:26'),
('571', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-22 00:40:28'),
('572', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-22 00:40:30'),
('573', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-22 00:40:31'),
('574', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-22 00:40:36'),
('575', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-22 00:40:43'),
('576', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-22 17:41:36'),
('577', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-22 17:41:36'),
('578', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-22 17:46:09'),
('579', 'VibeStreams', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-22 17:48:55'),
('580', 'VibeStreams', 'content', 'Dismissed the reports on video 5ABfNhJvTTs', 'reported.php', '::1', '2026-10-22 17:49:03'),
('581', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-22 17:49:08'),
('582', 'VibeStreams', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-22 17:49:13'),
('583', 'VibeStreams', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-22 17:49:15'),
('584', 'VibeStreams', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-22 17:49:17'),
('585', 'VibeStreams', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-22 17:49:19'),
('586', 'VibeStreams', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-22 17:49:33'),
('587', 'VibeStreams', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-22 17:49:35'),
('588', 'VibeStreams', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-22 17:49:39'),
('589', 'VibeStreams', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-22 17:49:44'),
('590', 'VibeStreams', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-22 17:49:47'),
('591', 'VibeStreams', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-22 17:49:49'),
('592', 'VibeStreams', 'user', 'Made \"Awais\" an admin', 'user_profile.php', '::1', '2026-10-22 17:49:56'),
('593', 'VibeStreams', 'user', 'Removed admin access from \"Awais\"', 'user_profile.php', '::1', '2026-10-22 17:50:08'),
('594', 'VibeStreams', 'user', 'Deleted user account \"Awais\" and 0 upload(s)', 'user_profile.php', '::1', '2026-10-22 17:50:15'),
('595', 'VibeStreams', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-22 17:50:18'),
('596', 'VibeStreams', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-22 17:50:36'),
('597', 'VibeStreams', 'premium', 'Gave Premium (monthly) to aqsa', 'premium.php', '::1', '2026-10-22 17:51:18'),
('598', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-22 17:51:26'),
('599', 'VibeStreams', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-22 17:51:34'),
('600', 'VibeStreams', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-22 17:51:43'),
('601', 'VibeStreams', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-22 17:51:48'),
('602', 'VibeStreams', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-22 17:52:00'),
('603', 'VibeStreams', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-22 17:52:33'),
('604', 'VibeStreams', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-22 22:02:55'),
('605', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-22 22:02:55'),
('606', 'VibeStreams', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-22 22:03:03'),
('607', 'VibeStreams', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-22 22:03:06'),
('608', 'VibeStreams', 'premium', 'Declined Premium request #3', 'notifications.php', '::1', '2026-10-22 22:03:11'),
('609', 'VibeStreams', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-22 22:05:55'),
('610', 'VibeStreams', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-22 22:12:30'),
('611', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-22 22:44:43'),
('612', 'VibeStreams', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-22 22:45:19'),
('613', 'VibeStreams', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-22 22:49:46'),
('614', 'VibeStreams', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-22 22:57:42'),
('615', 'VibeStreams', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-22 23:04:45'),
('616', 'VibeStreams', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-22 23:04:53'),
('617', 'VibeStreams', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-22 23:09:12'),
('618', 'VibeStreams', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-22 23:11:48'),
('619', 'VibeStreams', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-22 23:30:52'),
('620', 'VibeStreams', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-22 23:31:00');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('621', 'VibeStreams', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-23 20:39:04'),
('622', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 20:39:04'),
('623', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 20:49:15'),
('624', 'VibeStreams', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-23 20:49:45'),
('625', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 20:49:45'),
('626', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 20:56:02'),
('627', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 21:09:28'),
('628', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-23 21:09:34'),
('629', 'VibeStreams', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-23 21:09:35'),
('630', 'VibeStreams', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-23 21:09:36'),
('631', 'VibeStreams', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-23 21:09:40'),
('632', 'VibeStreams', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-23 21:09:44'),
('633', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 21:21:54'),
('634', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 21:30:00'),
('635', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 21:30:46'),
('636', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 21:36:17'),
('637', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 21:36:19'),
('638', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 21:36:26'),
('639', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 21:54:09'),
('640', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-23 21:54:24'),
('641', 'VibeStreams', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-23 21:54:25'),
('642', 'VibeStreams', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-23 21:54:32'),
('643', 'VibeStreams', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-23 22:00:07'),
('644', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 22:00:47'),
('645', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-23 22:00:49'),
('646', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-23 22:03:19'),
('647', 'VibeStreams', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-23 22:03:30'),
('648', 'VibeStreams', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-23 22:03:33'),
('649', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 22:03:36'),
('650', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 22:05:36'),
('651', 'VibeStreams', 'settings', 'Held payment for MuhammadAwais (2026-10)', 'admin-payroll.php', '::1', '2026-10-23 22:06:14'),
('652', 'VibeStreams', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-23 22:06:28'),
('653', 'VibeStreams', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-23 22:06:30'),
('654', 'VibeStreams', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-23 22:06:32'),
('655', 'VibeStreams', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-23 22:06:34'),
('656', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-23 22:06:35'),
('657', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-23 22:17:35'),
('658', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-23 22:26:38'),
('659', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-23 22:30:28'),
('660', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-23 22:33:46'),
('661', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-23 22:35:52'),
('662', 'VibeStreams', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-23 22:36:26'),
('663', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 22:36:32'),
('664', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 22:45:45'),
('665', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 22:49:19'),
('666', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 22:54:35'),
('667', 'VibeStreams', 'settings', 'Held payment for MuhammadAwais (2026-10)', 'admin-payroll.php', '::1', '2026-10-23 22:55:02'),
('668', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 23:00:59'),
('669', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 23:10:19'),
('670', 'VibeStreams', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-23 23:15:24'),
('671', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 23:15:24'),
('672', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 23:15:36'),
('673', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 23:15:52'),
('674', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 23:19:27'),
('675', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 23:21:29'),
('676', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 23:26:50'),
('677', 'VibeStreams', 'page_view', 'Opened admin-payroll.php', 'admin-payroll.php', '::1', '2026-10-23 23:29:26'),
('678', 'VibeStreams', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-23 23:31:16'),
('679', 'VibeStreams', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-23 23:33:34'),
('680', 'VibeStreams', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-23 23:34:45'),
('681', 'VibeStreams', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-23 23:43:57'),
('682', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-23 23:46:32'),
('683', 'VibeStreams', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-23 23:51:46'),
('684', 'VibeStreams', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-23 23:51:56'),
('685', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 23:52:39'),
('686', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-23 23:52:44'),
('687', 'VibeStreams', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-23 23:52:50'),
('688', 'VibeStreams', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-23 23:52:51'),
('689', 'VibeStreams', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-23 23:52:52'),
('690', 'VibeStreams', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-23 23:52:55'),
('691', 'VibeStreams', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-23 23:53:00'),
('692', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-23 23:53:18'),
('693', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-23 23:53:25'),
('694', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-23 23:53:35'),
('695', 'VibeStreams', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-23 23:55:03'),
('696', 'VibeStreams', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-23 23:55:08'),
('697', 'VibeStreams', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-24 00:04:40'),
('698', 'VibeStreams', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-24 00:04:50'),
('699', 'VibeStreams', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-24 00:04:53'),
('700', 'VibeStreams', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-24 00:22:49'),
('701', 'VibeStreams', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 00:25:21'),
('702', 'VibeStreams', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 00:29:20'),
('703', 'VibeStreams', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-24 00:29:46'),
('704', 'VibeStreams', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-24 00:29:49'),
('705', 'VibeStreams', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 00:29:51'),
('706', 'VibeStreams', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 00:29:53'),
('707', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-24 00:29:54'),
('708', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 00:29:59'),
('709', 'VibeStreams', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-24 00:30:06'),
('710', 'VibeStreams', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-24 00:34:20'),
('711', 'VibeStreams', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-24 17:58:06'),
('712', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 17:58:06'),
('713', 'VibeStreams', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-24 17:58:10'),
('714', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 17:59:11'),
('715', 'VibeStreams', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-24 18:00:35'),
('716', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 18:00:42'),
('717', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 18:09:57'),
('718', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 18:13:18'),
('719', 'VibeStreams', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-24 18:14:43'),
('720', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 18:14:43');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('721', 'VibeStreams', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-24 18:15:06'),
('722', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-24 18:16:00'),
('723', 'VibeStreams', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-24 18:16:06'),
('724', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 18:16:28'),
('725', 'VibeStreams', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-24 18:17:17'),
('726', 'VibeStreams', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-24 18:22:20'),
('727', 'VibeStreams', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-24 18:26:49'),
('728', 'VibeStreams', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-24 18:26:57'),
('729', 'VibeStreams', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-24 18:27:09'),
('730', 'VibeStreams', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-24 18:27:32'),
('731', 'VibeStreams', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 18:28:01'),
('732', 'VibeStreams', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-24 18:28:10'),
('733', 'VibeStreams', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-24 18:28:13'),
('734', 'VibeStreams', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-24 18:28:19'),
('735', 'VibeStreams', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-24 18:32:51'),
('736', 'VibeStreams', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-24 18:32:59'),
('737', 'VibeStreams', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 18:37:21'),
('738', 'VibeStreams', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-24 18:37:24'),
('739', 'VibeStreams', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 18:41:21'),
('740', 'VibeStreams', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-24 18:41:23'),
('741', 'VibeStreams', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-24 18:41:26'),
('742', 'VibeStreams', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-24 18:43:30'),
('743', 'VibeStreams', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-24 18:46:36'),
('744', 'VibeStreams', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-24 18:46:38'),
('745', 'VibeStreams', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 18:46:41'),
('746', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-24 18:47:45'),
('747', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 18:47:47'),
('748', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-24 18:48:21'),
('749', 'VibeStreams', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 18:48:34'),
('750', 'VibeStreams', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-24 18:48:37'),
('751', 'VibeStreams', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 18:48:38'),
('752', 'VibeStreams', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-24 18:48:41'),
('753', 'VibeStreams', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-24 18:49:14'),
('754', 'VibeStreams', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-24 18:50:53'),
('755', 'VibeStreams', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-24 18:51:20'),
('756', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 18:52:41'),
('757', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-24 18:53:04'),
('758', 'VibeStreams', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 18:53:12'),
('759', 'VibeStreams', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 18:53:17'),
('760', 'VibeStreams', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-24 18:53:21'),
('761', 'VibeStreams', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-24 18:53:23'),
('762', 'VibeStreams', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 18:53:29'),
('763', 'VibeStreams', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-24 18:53:32'),
('764', 'VibeStreams', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-24 18:53:39'),
('765', 'VibeStreams', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-24 18:53:43'),
('766', 'VibeStreams', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-24 18:53:46'),
('767', 'VibeStreams', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-24 18:53:54'),
('768', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 18:54:05'),
('769', 'VibeStreams', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-24 18:54:17'),
('770', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 18:54:23'),
('771', 'VibeStreams', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-24 18:54:38'),
('772', 'VibeStreams', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-24 18:55:28'),
('773', 'VibeStreams', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-24 18:55:34'),
('774', 'VibeStreams', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 18:55:40'),
('775', 'VibeStreams', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 19:05:46'),
('776', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 19:06:01'),
('777', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 19:06:05'),
('778', 'VibeStreams', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-24 19:06:08'),
('779', 'VibeStreams', 'settings', 'App settings saved: app name \"VibeStreams\" → \"VibeStream\"', 'platform-settings.php', '::1', '2026-10-24 19:06:39'),
('780', 'VibeStreams', 'settings', 'App settings saved: app name \"VibeStream\" → \"VibeStreams\"', 'platform-settings.php', '::1', '2026-10-24 19:06:48'),
('781', 'VibeStreams', 'settings', 'App settings saved: app name \"VibeStreams\" → \"VibeStream\"', 'platform-settings.php', '::1', '2026-10-24 19:07:00'),
('782', 'VibeStreams', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-24 19:07:09'),
('783', 'VibeStreams', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-24 19:07:14'),
('784', 'VibeStreams', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-24 19:11:00'),
('785', 'VibeStreams', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-24 19:11:15'),
('786', 'VibeStreams', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-24 19:11:17'),
('787', 'VibeStreams', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-24 19:11:18'),
('788', 'VibeStreams', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-24 19:11:30'),
('789', 'VibeStreams', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-24 20:49:20'),
('790', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 20:49:20'),
('791', 'VibeStreams', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 20:51:15'),
('792', 'VibeStreams', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-24 20:51:17'),
('793', 'VibeStreams', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-24 20:51:18'),
('794', 'VibeStreams', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-24 20:51:19'),
('795', 'VibeStreams', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-24 20:51:21'),
('796', 'VibeStreams', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 20:52:28'),
('797', 'VibeStreams', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-24 20:52:30'),
('798', 'VibeStreams', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-24 20:52:50'),
('799', 'VibeStreams', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 20:53:10'),
('800', 'VibeStreams', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-24 20:53:15'),
('801', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 20:53:18'),
('802', 'VibeStreams', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-24 20:53:39'),
('803', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 20:53:48'),
('804', 'VibeStreams', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 20:55:25'),
('805', 'VibeStreams', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-24 20:55:29'),
('806', 'VibeStreams', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-24 20:55:31'),
('807', 'VibeStreams', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-24 20:55:35'),
('808', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 20:55:48'),
('809', 'VibeStreams', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-24 20:56:17'),
('810', 'VibeStreams', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-24 20:56:36'),
('811', 'VibeStreams', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-24 20:57:05'),
('812', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 20:57:26'),
('813', 'VibeStreams', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-24 20:57:47'),
('814', 'VibeStreams', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-24 20:57:54'),
('815', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 20:58:38'),
('816', 'VibeStreams', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-24 20:59:02'),
('817', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 20:59:08'),
('818', 'VibeStreams', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-24 20:59:57'),
('819', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 21:00:02'),
('820', 'VibeStreams', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-24 21:00:13');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('821', 'VibeStreams', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 21:00:16'),
('822', 'VibeStreams', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-24 21:00:25'),
('823', 'VibeStreams', 'settings', 'App settings saved: app name \"VibeStream\" → \"VibeStreams\"', 'platform-settings.php', '::1', '2026-10-24 21:00:45'),
('824', 'VibeStreams', 'settings', 'App settings saved: app name \"VibeStreams\" → \"VibeStream\"', 'platform-settings.php', '::1', '2026-10-24 21:00:53'),
('825', 'VibeStreams', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-24 21:01:51'),
('826', 'VibeStreams', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-24 21:02:03'),
('827', 'VibeStreams', 'other', 'Sent an owner notice to MuhammadAwais', 'owner-notices.php', '::1', '2026-10-24 21:02:30'),
('828', 'VibeStreams', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-24 21:02:36'),
('829', 'VibeStreams', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-24 21:03:17'),
('830', 'VibeStreams', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-24 21:03:42'),
('831', 'VibeStreams', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-24 21:04:31'),
('832', 'VibeStreams', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 21:05:40'),
('833', 'VibeStreams', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-24 21:05:47'),
('834', 'VibeStreams', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-24 21:05:54'),
('835', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 21:10:12'),
('836', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 21:21:29'),
('837', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 21:22:21'),
('838', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-24 21:22:28'),
('839', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 21:22:44'),
('840', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-24 21:23:27'),
('841', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 21:26:06'),
('842', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 21:27:01'),
('843', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-24 21:27:39'),
('844', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 21:28:03'),
('845', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 21:33:32'),
('846', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 21:33:42'),
('847', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-24 21:33:51'),
('848', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 21:37:19'),
('849', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 21:40:22'),
('850', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 21:46:18'),
('851', 'VibeStream', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-24 21:52:57'),
('852', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 21:53:20'),
('853', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 22:03:28'),
('854', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 22:07:19'),
('855', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 22:07:57'),
('856', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 22:23:10'),
('857', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 22:26:27'),
('858', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 22:29:17'),
('859', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 22:31:23'),
('860', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 22:38:02'),
('861', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 22:43:10'),
('862', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 22:45:38'),
('863', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 22:45:46'),
('864', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 22:45:52'),
('865', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 22:48:29'),
('866', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 22:56:23'),
('867', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 22:56:28'),
('868', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 22:56:30'),
('869', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 22:58:32'),
('870', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 22:58:34'),
('871', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 23:09:26'),
('872', 'VibeStream', 'page_view', 'Opened Add video', 'addvideos.php', '::1', '2026-10-24 23:09:51'),
('873', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:09:53'),
('874', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 23:09:54'),
('875', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-24 23:09:55'),
('876', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 23:09:57'),
('877', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:11:22'),
('878', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 23:11:24'),
('879', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-24 23:11:25'),
('880', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 23:11:26'),
('881', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 23:14:33'),
('882', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 23:16:14'),
('883', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:16:16'),
('884', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 23:16:18'),
('885', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:16:19'),
('886', 'VibeStream', 'page_view', 'Opened content_page.php', 'content_page.php', '::1', '2026-10-24 23:16:58'),
('887', 'VibeStream', 'page_view', 'Opened content_page.php', 'content_page.php', '::1', '2026-10-24 23:19:38'),
('888', 'VibeStream', 'page_view', 'Opened Edit video', 'editvideos.php', '::1', '2026-10-24 23:19:45'),
('889', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 23:21:09'),
('890', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:22:01'),
('891', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-24 23:22:04'),
('892', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 23:22:25'),
('893', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:22:48'),
('894', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:28:13'),
('895', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:33:37'),
('896', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:36:23'),
('897', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 23:36:35'),
('898', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:36:51'),
('899', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-24 23:37:24'),
('900', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 23:37:25'),
('901', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-24 23:37:26'),
('902', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 23:39:29'),
('903', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 23:46:07'),
('904', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-24 23:46:41'),
('905', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:46:43'),
('906', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 23:46:44'),
('907', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-24 23:46:45'),
('908', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 23:46:47'),
('909', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 23:48:00'),
('910', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-24 23:50:33'),
('911', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:51:05'),
('912', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 23:51:07'),
('913', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-24 23:51:10'),
('914', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 23:51:12'),
('915', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 23:54:50'),
('916', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-24 23:54:56'),
('917', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 23:54:57'),
('918', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-24 23:54:59'),
('919', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-24 23:55:05'),
('920', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-24 23:55:07');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('921', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-24 23:55:17'),
('922', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-24 23:55:19'),
('923', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-24 23:58:07'),
('924', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-24 23:58:10'),
('925', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-24 23:58:11'),
('926', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-24 23:58:15'),
('927', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-24 23:58:19'),
('928', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-24 23:58:22'),
('929', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-24 23:58:26'),
('930', 'VibeStream', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-24 23:58:34'),
('931', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-24 23:58:40'),
('932', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-24 23:58:44'),
('933', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-24 23:58:53'),
('934', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 00:04:28'),
('935', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 00:14:50'),
('936', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 00:19:46'),
('937', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 00:26:30'),
('938', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 00:29:41'),
('939', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 00:31:48'),
('940', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-25 00:32:12'),
('941', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 00:32:14'),
('942', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-25 00:32:16'),
('943', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-25 00:32:19'),
('944', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-25 00:34:34'),
('945', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-25 00:34:49'),
('946', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 00:35:00'),
('947', 'VibeStream', 'page_view', 'Opened icons.php', 'icons.php', '::1', '2026-10-25 00:35:30'),
('948', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 00:37:54'),
('949', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 00:43:44'),
('950', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-25 00:43:47'),
('951', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-25 00:46:06'),
('952', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-25 00:46:54'),
('953', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-25 00:47:00'),
('954', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-25 00:54:12'),
('955', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-25 00:56:31'),
('956', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 00:56:38'),
('957', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 01:19:40'),
('958', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-25 01:21:22'),
('959', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 01:21:24'),
('960', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 01:25:29'),
('961', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-25 01:25:32'),
('962', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-25 01:25:34'),
('963', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-25 01:25:36'),
('964', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 01:25:37'),
('965', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-25 01:25:42'),
('966', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-25 01:25:45'),
('967', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-25 01:29:58'),
('968', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-25 01:30:00'),
('969', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 01:30:02'),
('970', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-25 01:30:03'),
('971', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-25 01:30:04'),
('972', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-25 01:30:05'),
('973', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-25 01:30:07'),
('974', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-25 01:30:09'),
('975', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-25 01:30:13'),
('976', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-25 01:30:15'),
('977', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-25 01:37:57'),
('978', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-25 01:38:07'),
('979', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-25 01:38:10'),
('980', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-25 01:38:18'),
('981', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-25 01:38:22'),
('982', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-25 01:38:26'),
('983', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-25 01:40:35'),
('984', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-25 01:42:31'),
('985', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-25 01:42:37'),
('986', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-25 01:46:10'),
('987', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-25 01:46:27'),
('988', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-25 01:46:32'),
('989', 'VibeStream', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-25 01:46:50'),
('990', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-25 01:47:04'),
('991', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-25 01:47:26'),
('992', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-25 01:47:36'),
('993', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 01:47:57'),
('994', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 01:53:06'),
('995', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-25 01:53:13'),
('996', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-25 02:01:32'),
('997', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-25 02:01:37'),
('998', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 02:01:41'),
('999', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 02:04:24'),
('1000', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-25 02:04:27'),
('1001', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-25 02:04:29'),
('1002', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-25 02:04:36'),
('1003', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-25 02:08:29'),
('1004', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-25 02:08:38'),
('1005', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 02:09:24'),
('1006', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 02:14:27'),
('1007', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 02:19:18'),
('1008', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 02:24:40'),
('1009', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 02:27:37'),
('1010', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 02:46:59'),
('1011', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-25 02:47:16'),
('1012', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 02:47:16'),
('1013', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-25 02:47:27'),
('1014', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-25 02:47:33'),
('1015', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-25 02:47:38'),
('1016', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-25 02:55:35'),
('1017', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-25 02:55:48'),
('1018', 'MuhammadAwais', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-25 02:57:48'),
('1019', 'MuhammadAwais', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 02:57:48'),
('1020', 'MuhammadAwais', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 03:00:15');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('1021', 'MuhammadAwais', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-10-25 03:00:18'),
('1022', 'MuhammadAwais', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-10-25 03:03:39'),
('1023', 'MuhammadAwais', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-25 03:03:49'),
('1024', 'MuhammadAwais', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-10-25 03:03:54'),
('1025', 'MuhammadAwais', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-10-25 03:06:57'),
('1026', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-25 03:07:21'),
('1027', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 03:07:21'),
('1028', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-25 03:07:26'),
('1029', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 03:07:48'),
('1030', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-25 03:11:53'),
('1031', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-25 03:12:54'),
('1032', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-25 03:13:19'),
('1033', 'MuhammadAwais', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-25 03:14:02'),
('1034', 'MuhammadAwais', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 03:14:02'),
('1035', 'MuhammadAwais', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-10-25 03:14:06'),
('1036', 'MuhammadAwais', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-25 03:14:18'),
('1037', 'MuhammadAwais', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-25 03:14:26'),
('1038', 'MuhammadAwais', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 03:14:49'),
('1039', 'MuhammadAwais', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-25 03:15:46'),
('1040', 'MuhammadAwais', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 03:15:55'),
('1041', 'MuhammadAwais', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-25 03:16:01'),
('1042', 'MuhammadAwais', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 03:20:46'),
('1043', 'MuhammadAwais', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-25 03:22:48'),
('1044', 'MuhammadAwais', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-25 03:22:58'),
('1045', 'MuhammadAwais', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-25 03:23:02'),
('1046', 'MuhammadAwais', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-25 03:23:13'),
('1047', 'MuhammadAwais', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-25 03:23:30'),
('1048', 'MuhammadAwais', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-10-25 03:23:39'),
('1049', 'MuhammadAwais', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-25 03:29:04'),
('1050', 'MuhammadAwais', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-25 03:29:06'),
('1051', 'MuhammadAwais', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-25 03:29:07'),
('1052', 'MuhammadAwais', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 03:29:08'),
('1053', 'MuhammadAwais', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-25 03:29:09'),
('1054', 'MuhammadAwais', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-25 03:29:11'),
('1055', 'MuhammadAwais', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-25 03:29:12'),
('1056', 'MuhammadAwais', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-25 03:29:14'),
('1057', 'MuhammadAwais', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-25 03:29:16'),
('1058', 'MuhammadAwais', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-25 03:29:19'),
('1059', 'MuhammadAwais', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 03:29:34'),
('1060', 'MuhammadAwais', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-25 03:29:37'),
('1061', 'MuhammadAwais', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-25 03:29:52'),
('1062', 'MuhammadAwais', 'page_view', 'Opened my-tasks.php', 'my-tasks.php', '::1', '2026-10-25 03:29:55'),
('1063', 'MuhammadAwais', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 03:30:07'),
('1064', 'MuhammadAwais', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-25 03:31:35'),
('1065', 'MuhammadAwais', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 03:31:42'),
('1066', 'MuhammadAwais', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-25 03:33:32'),
('1067', 'MuhammadAwais', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 03:35:54'),
('1068', 'MuhammadAwais', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 03:37:59'),
('1069', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-25 12:33:05'),
('1070', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 12:33:05'),
('1071', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-25 12:33:58'),
('1072', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 12:34:07'),
('1073', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-25 12:37:04'),
('1074', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 12:37:04'),
('1075', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-25 12:37:15'),
('1076', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-25 12:37:23'),
('1077', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-25 12:37:28'),
('1078', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-25 12:37:31'),
('1079', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-25 12:37:33'),
('1080', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 12:37:36'),
('1081', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-25 18:30:22'),
('1082', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 18:30:22'),
('1083', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 18:30:26'),
('1084', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 18:34:09'),
('1085', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 18:37:29'),
('1086', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 18:41:54'),
('1087', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-25 18:42:16'),
('1088', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-25 18:43:54'),
('1089', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-25 18:43:58'),
('1090', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-25 18:52:04'),
('1091', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 18:52:35'),
('1092', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-25 18:57:55'),
('1093', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 18:57:55'),
('1094', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-25 18:58:23'),
('1095', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-25 18:58:27'),
('1096', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-25 18:58:28'),
('1097', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 18:58:29'),
('1098', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-25 18:58:48'),
('1099', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 18:58:52'),
('1100', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-25 18:59:04'),
('1101', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-25 19:00:21'),
('1102', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 19:00:21'),
('1103', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-25 19:00:26'),
('1104', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-25 19:00:31'),
('1105', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-25 19:00:45'),
('1106', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-25 19:00:52'),
('1107', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-25 19:01:36'),
('1108', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-25 19:01:39'),
('1109', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-25 19:01:50'),
('1110', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-25 19:02:08'),
('1111', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-25 23:59:53'),
('1112', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-25 23:59:53'),
('1113', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-26 00:00:06'),
('1114', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-26 00:12:08'),
('1115', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-26 00:12:33'),
('1116', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-26 00:19:46'),
('1117', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-26 00:25:44'),
('1118', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-26 00:27:17'),
('1119', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-26 00:28:54'),
('1120', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-26 00:29:59');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('1121', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-26 00:36:24'),
('1122', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-26 00:38:15'),
('1123', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-26 00:38:28'),
('1124', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-26 00:43:31'),
('1125', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-26 00:43:41'),
('1126', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-26 00:45:54'),
('1127', 'MuhammadAwais', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-26 00:46:48'),
('1128', 'MuhammadAwais', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-26 00:46:48'),
('1129', 'MuhammadAwais', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-26 00:46:51'),
('1130', 'MuhammadAwais', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-26 00:54:17'),
('1131', 'MuhammadAwais', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-26 00:54:25'),
('1132', 'MuhammadAwais', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-26 00:54:33'),
('1133', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-26 00:55:45'),
('1134', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-26 00:55:45'),
('1135', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-26 00:55:50'),
('1136', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-26 00:56:42'),
('1137', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-26 00:59:23'),
('1138', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-26 00:59:45'),
('1139', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-26 01:08:40'),
('1140', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-26 01:08:40'),
('1141', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-26 01:08:44'),
('1142', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-26 01:08:50'),
('1143', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-26 01:08:54'),
('1144', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-26 01:09:00'),
('1145', 'VibeStream', 'user', 'Deleted user account \"duhf\" and 0 upload(s)', 'user_profile.php', '::1', '2026-10-26 01:09:08'),
('1146', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-26 01:09:11'),
('1147', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-26 01:09:14'),
('1148', 'VibeStream', 'user', 'Deleted user account \"Awais\" and 0 upload(s)', 'user_profile.php', '::1', '2026-10-26 01:09:29'),
('1149', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-27 21:26:16'),
('1150', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 21:26:16'),
('1151', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 21:28:19'),
('1152', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 21:28:43'),
('1153', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 21:28:47'),
('1154', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 21:28:48'),
('1155', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 21:28:49'),
('1156', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-27 21:35:09'),
('1157', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 21:35:23'),
('1158', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-27 21:35:28'),
('1159', 'VibeStream', 'user', 'Set the title of \"MuhammadAwais\" to CEO', 'user_profile.php', '::1', '2026-10-27 21:35:37'),
('1160', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 21:35:54'),
('1161', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-27 21:36:05'),
('1162', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 21:56:02'),
('1163', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 21:56:15'),
('1164', 'VibeStream', 'page_view', 'Opened video-categories.php', 'video-categories.php', '::1', '2026-10-27 21:57:11'),
('1165', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:00:58'),
('1166', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 22:02:08'),
('1167', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 22:02:10'),
('1168', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 22:02:11'),
('1169', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 22:02:11'),
('1170', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 22:02:12'),
('1171', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:05:30'),
('1172', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:07:56'),
('1173', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:31:08'),
('1174', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 22:33:19'),
('1175', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 22:33:20'),
('1176', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 22:33:22'),
('1177', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:33:23'),
('1178', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:37:22'),
('1179', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 22:38:00'),
('1180', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 22:38:12'),
('1181', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 22:38:13'),
('1182', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 22:38:15'),
('1183', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-27 22:38:18'),
('1184', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-27 22:39:30'),
('1185', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-27 22:40:11'),
('1186', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 22:40:15'),
('1187', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-27 22:40:24'),
('1188', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-27 22:41:25'),
('1189', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-27 22:41:45'),
('1190', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:41:49'),
('1191', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:44:27'),
('1192', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 22:45:29'),
('1193', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 22:47:32'),
('1194', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 22:47:56'),
('1195', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 22:48:00'),
('1196', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 22:48:02'),
('1197', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:49:18'),
('1198', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 22:49:58'),
('1199', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 22:50:09'),
('1200', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 22:50:15'),
('1201', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 22:50:28'),
('1202', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 22:50:32'),
('1203', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-27 22:50:39'),
('1204', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 22:50:43'),
('1205', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-27 22:50:48'),
('1206', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-27 22:50:50'),
('1207', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-27 22:50:54'),
('1208', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-27 22:50:58'),
('1209', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-27 22:51:12'),
('1210', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-27 22:51:29'),
('1211', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:54:56'),
('1212', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-27 22:58:11'),
('1213', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 22:58:11'),
('1214', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:00:25'),
('1215', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-27 23:00:48'),
('1216', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-27 23:01:39'),
('1217', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 23:01:39'),
('1218', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 23:01:57'),
('1219', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-27 23:02:10'),
('1220', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-27 23:02:25');
INSERT INTO `admin_activity_log` (`id`, `admin_username`, `action`, `details`, `page`, `ip`, `created_at`) VALUES
('1221', 'VibeStream', 'session', 'Started an admin panel session', 'index.php', '::1', '2026-10-27 23:03:26'),
('1222', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 23:03:26'),
('1223', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 23:03:59'),
('1224', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 23:04:03'),
('1225', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:04:09'),
('1226', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-27 23:06:26'),
('1227', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:06:32'),
('1228', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 23:06:55'),
('1229', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 23:07:05'),
('1230', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-27 23:08:06'),
('1231', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-27 23:08:11'),
('1232', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:08:15'),
('1233', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-27 23:08:34'),
('1234', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 23:08:52'),
('1235', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 23:08:57'),
('1236', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 23:09:20'),
('1237', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 23:09:33'),
('1238', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 23:09:41'),
('1239', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 23:09:59'),
('1240', 'VibeStream', 'page_view', 'Opened Users', 'Users.php', '::1', '2026-10-27 23:10:10'),
('1241', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 23:10:13'),
('1242', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-27 23:10:22'),
('1243', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-27 23:10:36'),
('1244', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-27 23:10:46'),
('1245', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-27 23:11:01'),
('1246', 'VibeStream', 'page_view', 'Opened App settings', 'platform-settings.php', '::1', '2026-10-27 23:11:11'),
('1247', 'VibeStream', 'page_view', 'Opened owner-notices.php', 'owner-notices.php', '::1', '2026-10-27 23:11:15'),
('1248', 'VibeStream', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-27 23:11:20'),
('1249', 'VibeStream', 'page_view', 'Opened site-icons.php', 'site-icons.php', '::1', '2026-10-27 23:11:29'),
('1250', 'VibeStream', 'page_view', 'Opened backup.php', 'backup.php', '::1', '2026-10-27 23:11:40'),
('1251', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:11:50'),
('1252', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-27 23:12:13'),
('1253', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-27 23:12:25'),
('1254', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-27 23:12:36'),
('1255', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 23:18:50'),
('1256', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-27 23:18:51'),
('1257', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 23:21:17'),
('1258', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 23:21:18'),
('1259', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 23:21:18'),
('1260', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 23:21:19'),
('1261', 'VibeStream', 'page_view', 'Opened Reported content', 'reported.php', '::1', '2026-10-27 23:21:19'),
('1262', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 23:21:20'),
('1263', 'VibeStream', 'page_view', 'Opened Messages', 'messages.php', '::1', '2026-10-27 23:21:20'),
('1264', 'VibeStream', 'page_view', 'Opened Premium', 'premium.php', '::1', '2026-10-27 23:21:21'),
('1265', 'VibeStream', 'page_view', 'Opened profit-loss.php', 'profit-loss.php', '::1', '2026-10-27 23:21:38'),
('1266', 'VibeStream', 'page_view', 'Opened Profile', 'profile.php', '::1', '2026-10-27 23:21:38'),
('1267', 'VibeStream', 'page_view', 'Opened Notifications', 'notifications.php', '::1', '2026-10-27 23:21:39'),
('1268', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:21:39'),
('1269', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-27 23:21:40'),
('1270', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-27 23:21:41'),
('1271', 'VibeStream', 'page_view', 'Opened insights.php', 'insights.php', '::1', '2026-10-27 23:23:38'),
('1272', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 23:23:42'),
('1273', 'VibeStream', 'page_view', 'Opened Shorts', 'shorts.php', '::1', '2026-10-27 23:24:13'),
('1274', 'VibeStream', 'page_view', 'Opened Categories', 'categories.php', '::1', '2026-10-27 23:24:48'),
('1275', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-27 23:24:59'),
('1276', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-27 23:28:16'),
('1277', 'VibeStream', 'page_view', 'Opened admin-pay.php', 'admin-pay.php', '::1', '2026-10-27 23:31:30'),
('1278', 'VibeStream', 'page_view', 'Opened Videos', 'videos.php', '::1', '2026-10-27 23:38:04'),
('1279', 'VibeStream', 'page_view', 'Opened Users profile', 'user_profile.php', '::1', '2026-10-27 23:39:53'),
('1280', 'VibeStream', 'page_view', 'Opened Admins', 'admins.php', '::1', '2026-10-27 23:40:07'),
('1281', 'VibeStream', 'page_view', 'Opened Dashboard', 'index.php', '::1', '2026-10-27 23:44:58'),
('1282', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:48:09'),
('1283', 'VibeStream', 'page_view', 'Opened system-check.php', 'system-check.php', '::1', '2026-10-27 23:54:22'),
('1284', 'VibeStream', 'page_view', 'Opened assign-task.php', 'assign-task.php', '::1', '2026-10-27 23:57:59'),
('1285', 'VibeStream', 'page_view', 'Opened my-pay.php', 'my-pay.php', '::1', '2026-10-27 23:58:02');

-- ----------------------------
-- Table `admin_alert_reads`
-- ----------------------------
DROP TABLE IF EXISTS `admin_alert_reads`;
CREATE TABLE `admin_alert_reads` (
  `alert_id` bigint(20) unsigned NOT NULL,
  `admin_username` varchar(100) NOT NULL,
  `read_at` datetime NOT NULL,
  PRIMARY KEY (`alert_id`,`admin_username`),
  KEY `admin_alert_read_by` (`admin_username`,`read_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_alert_reads` (`alert_id`, `admin_username`, `read_at`) VALUES
('1', 'MuhammadAwais', '2026-10-25 02:57:56'),
('1', 'VibeStream', '2026-10-24 21:10:17'),
('2', 'VibeStream', '2026-10-27 23:01:45'),
('1', 'VibeStreams', '2026-10-22 22:05:50');

-- ----------------------------
-- Table `admin_alerts`
-- ----------------------------
DROP TABLE IF EXISTS `admin_alerts`;
CREATE TABLE `admin_alerts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `alert_key` varchar(190) NOT NULL,
  `kind` varchar(40) NOT NULL,
  `title` varchar(190) NOT NULL,
  `message` varchar(500) NOT NULL DEFAULT '',
  `href` varchar(255) NOT NULL DEFAULT 'index.php',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alert_key_unique` (`alert_key`),
  KEY `alert_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_alerts` (`id`, `alert_key`, `kind`, `title`, `message`, `href`, `created_at`) VALUES
('1', 'content-report-0', 'report', 'New content report', 'Short reported for other by VibeStreams.', 'reported.php?status=open', '2026-10-22 17:43:57'),
('2', 'admin-login-failed-a4401e329dd0aa14bed468e9a6f52e5f7035965563decab58198f32e1d5c3401', 'admin_login_failed', 'Failed admin sign-in', 'A sign-in attempt for VibeStream failed from IP ::1.', 'admin-activity.php', '2026-10-27 23:00:08');

-- ----------------------------
-- Table `admin_call_reads`
-- ----------------------------
DROP TABLE IF EXISTS `admin_call_reads`;
CREATE TABLE `admin_call_reads` (
  `call_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `read_at` datetime NOT NULL,
  PRIMARY KEY (`call_id`,`user_id`),
  KEY `idx_admin_call_reads_user` (`user_id`,`read_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `admin_call_signals`
-- ----------------------------
DROP TABLE IF EXISTS `admin_call_signals`;
CREATE TABLE `admin_call_signals` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `call_id` char(32) NOT NULL,
  `from_user` int(11) NOT NULL,
  `to_user` int(11) NOT NULL,
  `event_type` varchar(12) NOT NULL,
  `payload` mediumtext NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_call_signals_poll` (`call_id`,`to_user`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_call_signals` (`id`, `call_id`, `from_user`, `to_user`, `event_type`, `payload`, `created_at`) VALUES
('1', '4d45b50e7757dae4f686900fa55f5e53', '14', '17', 'hangup', '', '2026-10-22 00:05:59');

-- ----------------------------
-- Table `admin_calls`
-- ----------------------------
DROP TABLE IF EXISTS `admin_calls`;
CREATE TABLE `admin_calls` (
  `call_id` char(32) NOT NULL,
  `caller_id` int(11) NOT NULL,
  `callee_id` int(11) NOT NULL,
  `media` varchar(8) NOT NULL,
  `status` varchar(12) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`call_id`),
  KEY `idx_admin_calls_caller` (`caller_id`,`status`,`updated_at`),
  KEY `idx_admin_calls_callee` (`callee_id`,`status`,`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_calls` (`call_id`, `caller_id`, `callee_id`, `media`, `status`, `updated_at`) VALUES
('4d45b50e7757dae4f686900fa55f5e53', '14', '17', 'audio', 'ended', '2026-10-22 00:05:59');

-- ----------------------------
-- Table `admin_chat_prefs`
-- ----------------------------
DROP TABLE IF EXISTS `admin_chat_prefs`;
CREATE TABLE `admin_chat_prefs` (
  `user_id` int(11) NOT NULL,
  `chat_key` varchar(20) NOT NULL,
  `pinned` tinyint(4) NOT NULL DEFAULT 0,
  `muted` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`,`chat_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `admin_dashboard_goals`
-- ----------------------------
DROP TABLE IF EXISTS `admin_dashboard_goals`;
CREATE TABLE `admin_dashboard_goals` (
  `goal_month` char(7) NOT NULL,
  `metric` varchar(16) NOT NULL,
  `target` int(10) unsigned NOT NULL,
  `updated_by` varchar(191) NOT NULL DEFAULT '',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`goal_month`,`metric`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_dashboard_goals` (`goal_month`, `metric`, `target`, `updated_by`, `updated_at`) VALUES
('2026-10', 'signups', '5', 'VibeStream', '2026-10-21 23:23:10'),
('2026-10', 'uploads', '5', 'VibeStream', '2026-10-21 23:23:16');

-- ----------------------------
-- Table `admin_group_members`
-- ----------------------------
DROP TABLE IF EXISTS `admin_group_members`;
CREATE TABLE `admin_group_members` (
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_read_id` int(11) NOT NULL DEFAULT 0,
  `joined_at` datetime NOT NULL,
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_group_members` (`group_id`, `user_id`, `last_read_id`, `joined_at`) VALUES
('1', '10', '0', '2026-10-11 21:53:25');

-- ----------------------------
-- Table `admin_group_messages`
-- ----------------------------
DROP TABLE IF EXISTS `admin_group_messages`;
CREATE TABLE `admin_group_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `sender_name` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `created_at` datetime NOT NULL,
  `edited_at` datetime DEFAULT NULL,
  `reply_to` int(11) DEFAULT NULL,
  `att_name` varchar(255) DEFAULT NULL,
  `att_path` varchar(120) DEFAULT NULL,
  `att_type` varchar(100) DEFAULT NULL,
  `att_size` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_group` (`group_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `admin_groups`
-- ----------------------------
DROP TABLE IF EXISTS `admin_groups`;
CREATE TABLE `admin_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_groups` (`id`, `name`, `created_by`, `created_at`) VALUES
('1', 'WHY', '10', '2026-10-11 21:53:25');

-- ----------------------------
-- Table `admin_message_history`
-- ----------------------------
DROP TABLE IF EXISTS `admin_message_history`;
CREATE TABLE `admin_message_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `kind` char(1) NOT NULL,
  `conversation_key` varchar(64) NOT NULL,
  `message_id` int(11) NOT NULL,
  `action` varchar(8) NOT NULL,
  `actor_id` int(11) NOT NULL,
  `actor_name` varchar(100) NOT NULL,
  `old_body` text NOT NULL,
  `attachment_name` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_conversation_history` (`conversation_key`,`id`),
  KEY `idx_message_history` (`kind`,`message_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_message_history` (`id`, `kind`, `conversation_key`, `message_id`, `action`, `actor_id`, `actor_name`, `old_body`, `attachment_name`, `created_at`) VALUES
('1', 'd', 'd:14:17', '5', 'deleted', '14', 'VibeStream', '📎 voice-note-1792609577583.webm', 'voice-note-1792609577583.webm', '2026-10-22 00:06:42');

-- ----------------------------
-- Table `admin_messages`
-- ----------------------------
DROP TABLE IF EXISTS `admin_messages`;
CREATE TABLE `admin_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `edited_at` datetime DEFAULT NULL,
  `reply_to` int(11) DEFAULT NULL,
  `att_name` varchar(255) DEFAULT NULL,
  `att_path` varchar(120) DEFAULT NULL,
  `att_type` varchar(100) DEFAULT NULL,
  `att_size` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_messages_inbox` (`recipient_id`,`is_read`),
  KEY `idx_admin_messages_pair` (`sender_id`,`recipient_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
-- Table `admin_msg_reactions`
-- ----------------------------
DROP TABLE IF EXISTS `admin_msg_reactions`;
CREATE TABLE `admin_msg_reactions` (
  `kind` char(1) NOT NULL,
  `msg_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `emoji` varchar(16) NOT NULL,
  PRIMARY KEY (`kind`,`msg_id`,`user_id`),
  KEY `idx_msg` (`kind`,`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `admin_pay_adjust`
-- ----------------------------
DROP TABLE IF EXISTS `admin_pay_adjust`;
CREATE TABLE `admin_pay_adjust` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month` char(7) NOT NULL,
  `username` varchar(100) NOT NULL,
  `hours` decimal(7,2) NOT NULL,
  `reason` varchar(200) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_month_user` (`month`,`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_pay_adjust` (`id`, `month`, `username`, `hours`, `reason`, `created_at`) VALUES
('1', '2026-10', 'muhammadawais', '100.00', 'idk', '2026-10-25 02:16:09'),
('2', '2026-10', 'muhammadawais', '-100.00', 'idk', '2026-10-25 02:20:42'),
('3', '2026-10', 'muhammadawais', '2.00', 'Work hard', '2026-10-25 02:27:37');

-- ----------------------------
-- Table `admin_pay_bonus`
-- ----------------------------
DROP TABLE IF EXISTS `admin_pay_bonus`;
CREATE TABLE `admin_pay_bonus` (
  `task_id` varchar(32) NOT NULL,
  `month` char(7) NOT NULL,
  `username` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `reason` varchar(200) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`task_id`),
  KEY `idx_month_user` (`month`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `admin_pay_log`
-- ----------------------------
DROP TABLE IF EXISTS `admin_pay_log`;
CREATE TABLE `admin_pay_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_pay_log` (`id`, `text`, `created_at`) VALUES
('1', 'Pay rates updated', '2026-10-24 18:15:27'),
('2', 'Pay rates updated', '2026-10-25 00:30:11'),
('3', 'MuhammadAwais marked as pending (2026-10)', '2026-10-25 00:31:48'),
('4', 'MuhammadAwais marked as pending (2026-10)', '2026-10-25 00:31:52'),
('5', 'MuhammadAwais marked as paid (2026-10)', '2026-10-25 00:31:57'),
('6', 'MuhammadAwais marked as do not pay (2026-10): not working', '2026-10-25 02:14:47'),
('7', '+100 hrs for MuhammadAwais: idk', '2026-10-25 02:16:09'),
('8', 'MuhammadAwais marked as allowed to be paid (owner override) (2026-10)', '2026-10-25 02:19:18'),
('9', 'MuhammadAwais marked as do not pay (2026-10): not working', '2026-10-25 02:19:31'),
('10', '-100 hrs for MuhammadAwais: idk', '2026-10-25 02:20:42'),
('11', '+2 hrs for MuhammadAwais: Work hard', '2026-10-25 02:27:37'),
('12', 'MuhammadAwais marked as allowed to be paid (owner override) (2026-10)', '2026-10-25 03:12:13'),
('13', 'MuhammadAwais marked as paid (2026-10)', '2026-10-25 03:12:24'),
('14', 'Pay rates and work times updated', '2026-10-27 23:32:31');

-- ----------------------------
-- Table `admin_pay_months`
-- ----------------------------
DROP TABLE IF EXISTS `admin_pay_months`;
CREATE TABLE `admin_pay_months` (
  `month` char(7) NOT NULL,
  `username` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending',
  `paid_amount` decimal(12,2) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `note` varchar(200) NOT NULL DEFAULT '',
  `override` tinyint(1) NOT NULL DEFAULT 0,
  `paid_by` varchar(100) NOT NULL DEFAULT '',
  `paid_at` datetime DEFAULT NULL,
  PRIMARY KEY (`month`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_pay_months` (`month`, `username`, `status`, `paid_amount`, `updated_at`, `note`, `override`, `paid_by`, `paid_at`) VALUES
('2026-10', 'muhammadawais', 'paid', '430.50', '2026-10-25 03:12:24', '', '1', '', NULL);

-- ----------------------------
-- Table `admin_pay_settings`
-- ----------------------------
DROP TABLE IF EXISTS `admin_pay_settings`;
CREATE TABLE `admin_pay_settings` (
  `username` varchar(100) NOT NULL,
  `rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `title` varchar(60) NOT NULL DEFAULT '',
  `shift_start` char(5) NOT NULL DEFAULT '',
  `shift_end` char(5) NOT NULL DEFAULT '',
  `work_days` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_pay_settings` (`username`, `rate`, `title`, `shift_start`, `shift_end`, `work_days`) VALUES
('muhammadawais', '200.00', 'Admin', '12:32', '13:14', '1,2,7');

-- ----------------------------
-- Table `admin_presence`
-- ----------------------------
DROP TABLE IF EXISTS `admin_presence`;
CREATE TABLE `admin_presence` (
  `user_id` int(11) NOT NULL,
  `last_seen` datetime NOT NULL,
  `typing_chat` varchar(20) DEFAULT NULL,
  `typing_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_presence` (`user_id`, `last_seen`, `typing_chat`, `typing_at`) VALUES
('14', '2026-10-27 23:21:20', NULL, NULL),
('17', '2026-10-25 03:29:16', NULL, NULL);

-- ----------------------------
-- Table `admin_summary_settings`
-- ----------------------------
DROP TABLE IF EXISTS `admin_summary_settings`;
CREATE TABLE `admin_summary_settings` (
  `admin_key` varchar(191) NOT NULL,
  `email` varchar(254) NOT NULL,
  `frequency` varchar(8) NOT NULL,
  `last_sent_on` date DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`admin_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_summary_settings` (`admin_key`, `email`, `frequency`, `last_sent_on`, `updated_at`) VALUES
('14', 'muhammadawaiscom0@gmail.com', 'weekly', NULL, '2026-10-23 22:07:21');

-- ----------------------------
-- Table `admin_user_notes`
-- ----------------------------
DROP TABLE IF EXISTS `admin_user_notes`;
CREATE TABLE `admin_user_notes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `admin_name` varchar(191) NOT NULL,
  `note` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_admin_user_notes_user` (`user_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
-- Table `channel_profiles`
-- ----------------------------
DROP TABLE IF EXISTS `channel_profiles`;
CREATE TABLE `channel_profiles` (
  `username` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL DEFAULT '',
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `channel_profiles` (`username`, `description`, `updated_at`) VALUES
('VibeStream', 'This is the offical VibeStream Channel', '2026-10-24 21:08:31');

-- ----------------------------
-- Table `comment_votes`
-- ----------------------------
DROP TABLE IF EXISTS `comment_votes`;
CREATE TABLE `comment_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `vote` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_comment_votes_comment_user` (`comment_id`,`username`),
  KEY `idx_comment_votes_comment` (`comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `comment_votes` (`id`, `comment_id`, `username`, `vote`, `created_at`) VALUES
('1', '29', 'deleted_c6849d61', '-1', '2026-10-10 01:30:28');

-- ----------------------------
-- Table `comments`
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `comment_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `hearted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `comments` (`id`, `video_id`, `username`, `comment_text`, `created_at`, `hearted`) VALUES
('34', '-4BzpL7pcnj', 'VibeStream', 'gg', '2026-10-11 03:19:10', '0'),
('37', '5ABfNhJvTTs', 'VibeStream', 'gg', '2026-10-16 20:26:32', '0'),
('38', 'MUiqU20kGZ5', 'VibeStream', 'gg', '2026-10-17 19:34:06', '0'),
('39', '5ABfNhJvTTs', 'VibeStream', 'gg', '2026-10-22 17:43:22', '0');

-- ----------------------------
-- Table `content_reports`
-- ----------------------------
DROP TABLE IF EXISTS `content_reports`;
CREATE TABLE `content_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_table` varchar(20) NOT NULL,
  `content_id` varchar(64) NOT NULL,
  `content_type` varchar(10) NOT NULL,
  `reason` varchar(30) NOT NULL,
  `details` varchar(500) NOT NULL DEFAULT '',
  `reporter` varchar(100) NOT NULL,
  `status` varchar(12) NOT NULL DEFAULT 'open',
  `created_at` datetime NOT NULL,
  `reviewed_by` varchar(100) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `assigned_to` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `one_report_per_user` (`content_table`,`content_id`,`reporter`),
  KEY `status_idx` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `content_reports` (`id`, `content_table`, `content_id`, `content_type`, `reason`, `details`, `reporter`, `status`, `created_at`, `reviewed_by`, `reviewed_at`, `assigned_to`) VALUES
('1', 'videos', 'TQ671jx2LHK', 'video', 'other', 'testing', 'OwnerHunter', 'dismissed', '2026-10-11 21:59:24', 'OwnerHunter', '2026-10-11 21:59:45', NULL),
('2', 'videos', 'rqcUKdldcNy', 'short', 'other', 'testing', 'OwnerHunter', 'removed', '2026-10-12 19:27:05', 'OwnerHunter', '2026-10-12 19:28:36', NULL),
('4', 'videos', '5ABfNhJvTTs', 'short', 'other', 'testing', 'VibeStreams', 'dismissed', '2026-10-22 14:43:57', 'VibeStreams', '2026-10-22 14:49:03', NULL);

-- ----------------------------
-- Table `owner_notices`
-- ----------------------------
DROP TABLE IF EXISTS `owner_notices`;
CREATE TABLE `owner_notices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `from_name` varchar(100) NOT NULL DEFAULT '',
  `to_id` int(11) NOT NULL,
  `to_name` varchar(100) NOT NULL DEFAULT '',
  `body` varchar(1000) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'sent',
  `seen_at` datetime DEFAULT NULL,
  `done_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_to` (`to_id`,`status`),
  KEY `idx_from` (`from_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `owner_notices` (`id`, `from_id`, `from_name`, `to_id`, `to_name`, `body`, `status`, `seen_at`, `done_at`, `created_at`) VALUES
('3', '14', 'VibeStreams', '17', 'MuhammadAwais', 'testing', 'done', '2026-10-25 03:29:37', '2026-10-25 03:29:46', '2026-10-24 21:02:30');

-- ----------------------------
-- Table `payroll_adjust`
-- ----------------------------
DROP TABLE IF EXISTS `payroll_adjust`;
CREATE TABLE `payroll_adjust` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_key` varchar(100) NOT NULL,
  `pay_month` char(7) NOT NULL,
  `hours` decimal(6,2) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_month` (`admin_key`,`pay_month`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payroll_adjust` (`id`, `admin_key`, `pay_month`, `hours`, `reason`, `created_at`) VALUES
('1', 'muhammadawais', '2026-11', '-16.00', 'idk', '2026-10-23 23:19:55');

-- ----------------------------
-- Table `payroll_payments`
-- ----------------------------
DROP TABLE IF EXISTS `payroll_payments`;
CREATE TABLE `payroll_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_key` varchar(100) NOT NULL,
  `pay_month` char(7) NOT NULL,
  `status` varchar(10) NOT NULL,
  `hours` decimal(8,2) NOT NULL DEFAULT 0.00,
  `rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `note` varchar(255) NOT NULL DEFAULT '',
  `decided_at` datetime NOT NULL,
  `rate_usd` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount_usd` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(40) NOT NULL DEFAULT '',
  `payment_reference` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `one_per_month` (`admin_key`,`pay_month`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payroll_payments` (`id`, `admin_key`, `pay_month`, `status`, `hours`, `rate`, `amount`, `note`, `decided_at`, `rate_usd`, `amount_usd`, `payment_method`, `payment_reference`) VALUES
('2', 'muhammadawais', '2026-10', 'hold', '0.00', '200.00', '0.00', '', '2026-10-23 22:55:02', '16.00', '0.00', '', '');

-- ----------------------------
-- Table `payroll_rates`
-- ----------------------------
DROP TABLE IF EXISTS `payroll_rates`;
CREATE TABLE `payroll_rates` (
  `admin_key` varchar(100) NOT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `hourly_rate_usd` decimal(10,2) NOT NULL DEFAULT 16.00,
  PRIMARY KEY (`admin_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payroll_rates` (`admin_key`, `hourly_rate`, `hourly_rate_usd`) VALUES
('muhammadawais', '200.00', '16.00');

-- ----------------------------
-- Table `playlist_videos`
-- ----------------------------
DROP TABLE IF EXISTS `playlist_videos`;
CREATE TABLE `playlist_videos` (
  `playlist_id` int(10) unsigned NOT NULL,
  `video_id` varchar(191) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`playlist_id`,`video_id`),
  KEY `idx_playlist_videos_video` (`video_id`),
  CONSTRAINT `fk_playlist_videos_playlist` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `playlists`
-- ----------------------------
DROP TABLE IF EXISTS `playlists`;
CREATE TABLE `playlists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `visibility` enum('private','public') NOT NULL DEFAULT 'private',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_playlists_user` (`user_id`),
  KEY `idx_playlists_visibility` (`visibility`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `premium_end_alerts`
-- ----------------------------
DROP TABLE IF EXISTS `premium_end_alerts`;
CREATE TABLE `premium_end_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `plan` varchar(10) NOT NULL,
  `started_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `ended_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `seen_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_period` (`username`,`started_at`,`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1470 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `premium_end_alerts` (`id`, `username`, `plan`, `started_at`, `expires_at`, `ended_at`, `created_at`, `seen_at`) VALUES
('1', 'aqsa', 'monthly', '2026-10-11 19:23:52', '2026-11-11 19:23:52', '2026-10-11 19:24:12', '2026-10-11 19:55:47', '2026-10-11 19:58:50'),
('438', 'VibeStream', 'yearly', '2026-10-11 01:37:10', '2027-10-12 01:37:10', '2026-10-16 10:01:44', '2026-10-16 10:01:44', '2026-10-16 10:02:00'),
('449', 'VibeStream', 'monthly', '2026-10-16 19:39:28', '2026-11-16 19:39:28', '2026-10-16 19:39:54', '2026-10-16 19:39:55', '2026-10-16 19:40:58'),
('450', 'MuhammadAwais', 'plusmonth', '2026-10-16 19:42:13', '2026-11-16 19:42:13', '2026-10-21 19:57:16', '2026-10-21 19:57:16', '2026-10-21 19:57:52');

-- ----------------------------
-- Table `premium_members`
-- ----------------------------
DROP TABLE IF EXISTS `premium_members`;
CREATE TABLE `premium_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `plan` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'active',
  `started_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `premium_members` (`id`, `username`, `plan`, `status`, `started_at`, `expires_at`, `updated_at`) VALUES
('3', 'VibeStream', 'plusyear', 'active', '2026-10-16 19:40:10', '2029-10-16 19:40:10', '2026-10-16 19:40:10'),
('9', 'MuhammadAwais', 'plusmonth', 'cancelled', '2026-10-16 19:42:13', '2026-11-16 19:42:13', '2026-10-21 19:57:16'),
('10', 'aqsa', 'monthly', 'active', '2026-10-22 17:51:18', '2026-11-22 17:51:18', '2026-10-22 17:51:18');

-- ----------------------------
-- Table `premium_reminders`
-- ----------------------------
DROP TABLE IF EXISTS `premium_reminders`;
CREATE TABLE `premium_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `expires_at` datetime NOT NULL,
  `kind` varchar(10) NOT NULL,
  `sent_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reminder` (`username`,`expires_at`,`kind`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `premium_requests`
-- ----------------------------
DROP TABLE IF EXISTS `premium_requests`;
CREATE TABLE `premium_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `plan` varchar(10) NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `txn_ref` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_txn_ref` (`txn_ref`),
  KEY `idx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `premium_requests` (`id`, `username`, `plan`, `amount`, `txn_ref`, `status`, `created_at`, `updated_at`) VALUES
('1', 'MuhammadAwais', 'plusmonth', '9.99', '5448554454', 'approved', '2026-10-16 19:41:37', '2026-10-16 19:42:13');

-- ----------------------------
-- Table `search_logs`
-- ----------------------------
DROP TABLE IF EXISTS `search_logs`;
CREATE TABLE `search_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `query` varchar(100) NOT NULL,
  `results` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_search_logs_created_at` (`created_at`),
  KEY `idx_search_logs_query` (`query`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
-- Table `signup_ip_hashes`
-- ----------------------------
DROP TABLE IF EXISTS `signup_ip_hashes`;
CREATE TABLE `signup_ip_hashes` (
  `user_id` bigint(20) unsigned NOT NULL,
  `ip_hash` char(64) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`),
  KEY `idx_signup_ip_hashes_hash` (`ip_hash`),
  KEY `idx_signup_ip_hashes_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `signup_ip_hashes` (`user_id`, `ip_hash`, `created_at`) VALUES
('20', '3db0233b9bf564ed51e3c852676da719289ac42d633e6bf6d3eaedcee4129b41', '2026-10-26 01:06:55');

-- ----------------------------
-- Table `site_announcements`
-- ----------------------------
DROP TABLE IF EXISTS `site_announcements`;
CREATE TABLE `site_announcements` (
  `id` tinyint(3) unsigned NOT NULL,
  `message` varchar(500) NOT NULL DEFAULT '',
  `updated_by` varchar(191) NOT NULL DEFAULT '',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `site_announcements` (`id`, `message`, `updated_by`, `updated_at`) VALUES
('1', '', '', '2026-10-21 22:10:06');

-- ----------------------------
-- Table `subscription_seen`
-- ----------------------------
DROP TABLE IF EXISTS `subscription_seen`;
CREATE TABLE `subscription_seen` (
  `user_id` int(11) NOT NULL,
  `channel_key` varchar(191) NOT NULL,
  `seen_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`channel_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
-- Table `upload_failure_events`
-- ----------------------------
DROP TABLE IF EXISTS `upload_failure_events`;
CREATE TABLE `upload_failure_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `content_type` varchar(16) NOT NULL,
  `upload_mode` varchar(16) NOT NULL,
  `failure_code` varchar(40) NOT NULL,
  `php_error_code` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_upload_failure_events_created` (`created_at`),
  KEY `idx_upload_failure_events_code_created` (`failure_code`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `upload_failure_events` (`id`, `username`, `content_type`, `upload_mode`, `failure_code`, `php_error_code`, `created_at`) VALUES
('1', '', 'short', 'link', 'invalid_video_link', '0', '2026-10-27 22:57:17'),
('2', '', 'short', 'link', 'invalid_video_link', '0', '2026-10-27 22:57:35');

-- ----------------------------
-- Table `user_activity_days`
-- ----------------------------
DROP TABLE IF EXISTS `user_activity_days`;
CREATE TABLE `user_activity_days` (
  `user_id` bigint(20) unsigned NOT NULL,
  `active_date` date NOT NULL,
  PRIMARY KEY (`user_id`,`active_date`),
  KEY `idx_user_activity_days_date` (`active_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_activity_days` (`user_id`, `active_date`) VALUES
('14', '2026-10-21'),
('14', '2026-10-22'),
('14', '2026-10-23'),
('14', '2026-10-24'),
('14', '2026-10-25'),
('14', '2026-10-27'),
('17', '2026-10-25'),
('18', '2026-10-21'),
('19', '2026-10-22'),
('19', '2026-10-24'),
('19', '2026-10-25'),
('20', '2026-10-26'),
('21', '2026-10-26');

-- ----------------------------
-- Table `user_notification_prefs`
-- ----------------------------
DROP TABLE IF EXISTS `user_notification_prefs`;
CREATE TABLE `user_notification_prefs` (
  `user_id` int(11) NOT NULL,
  `uploads` tinyint(1) NOT NULL DEFAULT 1,
  `comments` tinyint(1) NOT NULL DEFAULT 1,
  `likes` tinyint(1) NOT NULL DEFAULT 1,
  `subscribers` tinyint(1) NOT NULL DEFAULT 1,
  `desktop_notifs` tinyint(1) NOT NULL DEFAULT 0,
  `subscriptions` tinyint(1) NOT NULL DEFAULT 1,
  `recommended` tinyint(1) NOT NULL DEFAULT 1,
  `channel_activity` tinyint(1) NOT NULL DEFAULT 1,
  `comment_activity` tinyint(1) NOT NULL DEFAULT 1,
  `mentions` tinyint(1) NOT NULL DEFAULT 1,
  `content_reuse` tinyint(1) NOT NULL DEFAULT 1,
  `promotions` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_notification_prefs` (`user_id`, `uploads`, `comments`, `likes`, `subscribers`, `desktop_notifs`, `subscriptions`, `recommended`, `channel_activity`, `comment_activity`, `mentions`, `content_reuse`, `promotions`) VALUES
('9', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '1', '0'),
('14', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');

-- ----------------------------
-- Table `user_notifications`
-- ----------------------------
DROP TABLE IF EXISTS `user_notifications`;
CREATE TABLE `user_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'upload',
  `channel_name` varchar(255) NOT NULL DEFAULT '',
  `actor` varchar(255) NOT NULL DEFAULT '',
  `video_id` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `message` varchar(500) NOT NULL DEFAULT '',
  `link` varchar(500) NOT NULL DEFAULT '',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_notifications_user` (`user_id`,`is_read`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_notifications` (`id`, `user_id`, `type`, `channel_name`, `actor`, `video_id`, `title`, `message`, `link`, `is_read`, `created_at`) VALUES
('4', '9', 'like', 'aqsa', 'aqsa', '6nvdR8clMIk', 'Eat Everything In A Grocery Store, Win $1,000,000', 'aqsa liked your video: Eat Everything In A Grocery Store, Win $1,000,000', 'watch.php?id=6nvdR8clMIk', '0', '2026-10-10 01:38:03'),
('7', '1', 'comment', 'deleted_11', 'Instant', 'IFUtsXdwk-A', 'Clean Transformation 🔥 | One Piece EP 1001 👒 | #onepiece #luffy', 'Instant commented on your short: \"gg\"', 'shorts.php?id=IFUtsXdwk-A', '1', '2026-10-10 12:35:27'),
('8', '11', 'like', 'VibeStream', 'OwnerHunter', 'aNsGJAzNt0h', '$10,000 Every Day You Survive In The Wilderness', 'OwnerHunter liked your video: $10,000 Every Day You Survive In The Wilderness', 'watch.php?id=aNsGJAzNt0h', '0', '2026-10-11 02:57:06'),
('9', '10', 'comment', 'VibeStream', 'OwnerHunter', '-4BzpL7pcnj', 'Even Gods Like Ice cream 😭', 'OwnerHunter commented on your short: \"gg\"', 'shorts.php?id=-4BzpL7pcnj', '0', '2026-10-11 03:19:10'),
('11', '10', 'like', 'VibeStream', 'OwnerHunter', 'MO1j8vJHKNl', 'Making a song in the style of…', 'OwnerHunter liked your short: Making a song in the style of…', 'shorts.php?id=MO1j8vJHKNl', '0', '2026-10-12 22:24:03'),
('13', '10', 'comment', 'VibeStream', 'OwnerHunter', 'MO1j8vJHKNl', 'Making a song in the style of…', 'OwnerHunter commented on your short: \"@OwnerHunter gg\"', 'shorts.php?id=MO1j8vJHKNl', '0', '2026-10-12 22:24:20'),
('14', '10', 'like', 'VibeStream', 'OwnerHunter', '-4BzpL7pcnj', 'Even Gods Like Ice cream 😭', 'OwnerHunter liked your short: Even Gods Like Ice cream 😭', 'shorts.php?id=-4BzpL7pcnj', '0', '2026-10-12 22:26:07'),
('15', '10', 'like', 'VibeStream', 'OwnerHunter', '4ZLZUhJHbW0', 'Bot\'s😭 #roblox #bloxfurit #bloxfruits #shorts', 'OwnerHunter liked your short: Bot\'s😭 #roblox #bloxfurit #bloxfruits #shorts', 'shorts.php?id=4ZLZUhJHbW0', '0', '2026-10-12 22:26:11'),
('16', '10', 'like', 'VibeStream', 'OwnerHunter', '5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', 'OwnerHunter liked your short: Goku Gets A New Outfit From Whis!', 'shorts.php?id=5ABfNhJvTTs', '0', '2026-10-12 22:26:15'),
('17', '15', 'like', 'VibeStream', 'OwnerHunter', 'gXeE57uu-Kw', 'Ranking the most beautiful violin sounds moment 🎶✨ #sehar', 'OwnerHunter liked your short: Ranking the most beautiful violin sounds moment 🎶✨ #sehar', 'shorts.php?id=gXeE57uu-Kw', '1', '2026-10-12 22:26:18'),
('18', '15', 'subscriber', 'VibeStream', 'OwnerHunter', '', '', 'OwnerHunter subscribed to your channel', 'profile.php?u=OwnerHunter', '1', '2026-10-12 23:25:43'),
('19', '11', 'notice', 'VibeStream', 'VibeStream', '', 'Owner notice', 'VibeStream sent you a notice: why u offline?', 'adminpanel/owner-notices.php?id=1', '0', '2026-10-14 19:34:12'),
('20', '11', 'notice', 'VibeStream', 'VibeStream', '', 'Owner notice', 'VibeStream sent you a notice: why u offline?', 'adminpanel/owner-notices.php?id=2', '0', '2026-10-14 19:39:23'),
('21', '10', 'like', 'VibeStream', 'VibeStream', 'MO1j8vJHKNl', 'Making a song in the style of…', 'VibeStream liked your short: Making a song in the style of…', 'shorts.php?id=MO1j8vJHKNl', '0', '2026-10-16 20:25:35'),
('22', '10', 'like', 'VibeStream', 'VibeStream', '5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', 'VibeStream liked your short: Goku Gets A New Outfit From Whis!', 'shorts.php?id=5ABfNhJvTTs', '0', '2026-10-16 20:26:28'),
('23', '10', 'comment', 'VibeStream', 'VibeStream', '5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', 'VibeStream commented on your short: \"gg\"', 'shorts.php?id=5ABfNhJvTTs', '0', '2026-10-16 20:26:32'),
('24', '10', 'subscriber', 'VibeStream', 'VibeStream', '', '', 'VibeStream subscribed to your channel', 'profile.php?u=VibeStream', '0', '2026-10-17 19:34:37'),
('26', '17', 'message', 'VibeStream', '', '', 'New message', 'VibeStream sent you a message: 📎 voice-note-1792609577583.webm', 'adminpanel/messages.php?with=14', '1', '2026-10-22 00:06:23'),
('27', '10', 'like', 'VibeStream', 'VibeStreams', '5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', 'VibeStreams liked your short: Goku Gets A New Outfit From Whis!', 'shorts.php?id=5ABfNhJvTTs', '0', '2026-10-22 17:43:15'),
('28', '10', 'comment', 'VibeStream', 'VibeStreams', '5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', 'VibeStreams commented on your short: \"gg\"', 'shorts.php?id=5ABfNhJvTTs', '0', '2026-10-22 17:43:22'),
('29', '17', 'notice', 'VibeStream', 'VibeStreams', '', 'Owner notice', 'VibeStreams sent you a notice: testing', 'adminpanel/owner-notices.php?id=3', '1', '2026-10-24 21:02:30'),
('30', '10', 'like', 'VibeStream', 'VibeStream', '-4BzpL7pcnj', 'Even Gods Like Ice cream 😭', 'VibeStream liked your short: Even Gods Like Ice cream 😭', 'shorts.php?id=-4BzpL7pcnj', '0', '2026-10-24 22:45:15'),
('31', '17', 'upload', '', '', '', '', 'VibeStream added a task for you: Your task is to look at reported videos and shorts', 'adminpanel/checkin.php#tasks', '1', '2026-10-25 02:56:42');

-- ----------------------------
-- Table `user_subscriptions`
-- ----------------------------
DROP TABLE IF EXISTS `user_subscriptions`;
CREATE TABLE `user_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` int(11) NOT NULL,
  `channel_name` varchar(255) NOT NULL,
  `channel_username` varchar(50) NOT NULL DEFAULT '',
  `channel_key` char(64) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_subscriptions_subscriber_channel` (`subscriber_id`,`channel_key`),
  KEY `idx_user_subscriptions_channel` (`channel_username`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_subscriptions` (`id`, `subscriber_id`, `channel_name`, `channel_username`, `channel_key`, `created_at`) VALUES
('18', '11', 'aqsa', 'aqsa', '53be87fd1a0d505db2677c206f8d7ed80814577cb56ea1f1eba9833092a17a98', '2026-10-10 12:36:57'),
('23', '15', 'VibeStream', 'OwnerHunter', 'bc64c51161839bb85975db95313394134eb1cbbbcc99a92f5b2a004196148d99', '2026-10-11 21:42:38'),
('26', '14', 'aqsa', 'aqsa', '53be87fd1a0d505db2677c206f8d7ed80814577cb56ea1f1eba9833092a17a98', '2026-10-21 21:32:19');

-- ----------------------------
-- Table `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_active` datetime DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`, `last_active`, `password_changed_at`, `avatar`) VALUES
('10', 'aqsa', 'aqsa@gmail.com', '$2y$10$pHyTDaecRwOrYPkMc/ejGeMs1ELR02QqHf03IZTeQKtFJ4LEAMIzK', 'user', '2026-10-10 01:37:31', NULL, NULL, NULL),
('14', 'VibeStream', 'muhammadawaiscom0@gmail.com', '$2y$10$yZPwxLwPDSRfaSGgGocHO.gbdAM4pBxLvhFtpnLeB4mlkE3vUpuLe', 'Admin', '2026-10-11 00:56:58', '2026-10-27 23:58:02', NULL, 'uploads/avatars/bf6fc51be4d88d4216b084666b0a24ee.png'),
('17', 'MuhammadAwais', 'muhammadawaiscom77@gmail.com', '$2y$10$ZaThIX5OTrcjtXsER3PmF.8Ugldz88d6TBdysKcs.dGJA7/kRaVHS', 'Admin', '2026-10-16 19:41:15', '2026-10-26 00:54:33', NULL, NULL),
('21', 'Awais', 'muhammadawaiscom67@gmail.com', '$2y$10$X1InyBg65LpVIOyAKvpG8uHvIka3ED1kGOZ8w4YsXpdCZu4bvtABG', 'User', '2026-10-26 01:09:57', NULL, NULL, NULL);

-- ----------------------------
-- Table `video_comments`
-- ----------------------------
DROP TABLE IF EXISTS `video_comments`;
CREATE TABLE `video_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `comment_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- ----------------------------
-- Table `video_likes`
-- ----------------------------
DROP TABLE IF EXISTS `video_likes`;
CREATE TABLE `video_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_like` (`video_id`,`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `video_likes` (`id`, `video_id`, `username`, `created_at`) VALUES
('1', 'MUiqU20kGZ5', 'VibeStream', '2026-10-17 14:14:33'),
('2', '5ABfNhJvTTs', 'VibeStream', '2026-10-17 19:11:20'),
('3', 'MO1j8vJHKNl', 'VibeStream', '2026-10-17 19:34:38'),
('6', '-4BzpL7pcnj', 'VibeStream', '2026-10-25 01:12:56');

-- ----------------------------
-- Table `video_view_events`
-- ----------------------------
DROP TABLE IF EXISTS `video_view_events`;
CREATE TABLE `video_view_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `content_type` varchar(16) NOT NULL,
  `content_id` varchar(191) NOT NULL,
  `creator` varchar(191) NOT NULL DEFAULT '',
  `viewed_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_video_view_events_recent` (`viewed_at`),
  KEY `idx_video_view_events_content_recent` (`content_type`,`content_id`,`viewed_at`),
  KEY `idx_video_view_events_creator_recent` (`creator`,`viewed_at`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `video_view_events` (`id`, `content_type`, `content_id`, `creator`, `viewed_at`) VALUES
('2', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-10-22 17:42:00'),
('3', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-10-22 17:42:04'),
('4', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-22 17:43:10'),
('5', 'short', '6lrPGbgxpQr', 'VibeStreams', '2026-10-23 20:50:59'),
('6', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-23 21:09:10'),
('7', 'video', 'MUiqU20kGZ5', 'VibeStreams', '2026-10-23 21:09:11'),
('8', 'short', '6lrPGbgxpQr', 'VibeStream', '2026-10-24 21:08:51'),
('9', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-10-24 21:08:57'),
('10', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-10-24 21:09:00'),
('11', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-24 22:29:25'),
('12', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-24 22:43:33'),
('13', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-24 22:44:55'),
('14', 'short', '-4BzpL7pcnj', 'aqsa', '2026-10-24 22:45:12'),
('15', 'short', '4ZLZUhJHbW0', 'aqsa', '2026-10-24 22:45:16'),
('16', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-24 22:45:18'),
('17', 'short', '-4BzpL7pcnj', 'aqsa', '2026-10-25 01:05:38'),
('18', 'short', '-4BzpL7pcnj', 'aqsa', '2026-10-25 01:08:32'),
('19', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-10-25 01:08:38'),
('20', 'video', 'RUP0hxEsgBl', 'VibeStream', '2026-10-25 23:56:35'),
('21', 'video', 'MUiqU20kGZ5', 'VibeStream', '2026-10-27 22:20:24'),
('22', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-10-27 22:30:10'),
('23', 'short', '5ABfNhJvTTs', 'aqsa', '2026-10-27 22:34:25'),
('24', 'video', 'BhAczqf1ci9', 'VibeStream', '2026-10-27 22:34:28'),
('25', 'short', 'MO1j8vJHKNl', 'aqsa', '2026-10-27 22:55:10'),
('26', 'video', 'nuTUjH70f8g', 'VibeStream', '2026-10-27 22:55:11');

-- ----------------------------
-- Table `videos`
-- ----------------------------
DROP TABLE IF EXISTS `videos`;
CREATE TABLE `videos` (
  `id` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `views` int(11) DEFAULT 0,
  `type` varchar(20) DEFAULT 'video',
  `username` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `likes` int(11) DEFAULT 0,
  `subscribers` int(11) DEFAULT 0,
  `channel_name` varchar(255) NOT NULL,
  `video_url` varchar(500) NOT NULL,
  `dislikes` int(11) NOT NULL DEFAULT 0,
  `category` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_videos_username_created` (`username`,`created_at`),
  KEY `idx_videos_channel_created` (`channel_name`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `videos` (`id`, `title`, `views`, `type`, `username`, `created_at`, `likes`, `subscribers`, `channel_name`, `video_url`, `dislikes`, `category`) VALUES
('-4BzpL7pcnj', 'Even Gods Like Ice cream 😭', '14', 'short', 'aqsa', '2026-10-09 22:50:48', '3', '2', 'aqsa', 'https://www.youtube.com/watch?v=jZCxYTKi_EM', '0', 'anime'),
('4ZLZUhJHbW0', 'Bot\'s😭 #roblox #bloxfurit #bloxfruits #shorts', '10', 'short', 'aqsa', '2026-10-09 22:52:32', '1', '2', 'aqsa', 'https://www.youtube.com/watch?v=0Y_pDZItZgw', '0', 'gaming'),
('5ABfNhJvTTs', 'Goku Gets A New Outfit From Whis!', '21', 'short', 'aqsa', '2026-10-09 22:55:21', '7', '2', 'aqsa', 'https://www.youtube.com/watch?v=46yZdMybV6A', '0', 'anime'),
('6lrPGbgxpQr', 'DOFFY FACE LUFFY NEW MOVE 👿🔥', '9', 'short', 'VibeStream', '2026-10-11 18:11:56', '2', '1', 'VibeStream', 'https://www.youtube.com/watch?v=7sSoXWCGKXc', '0', 'anime'),
('BhAczqf1ci9', '30 Celebrities Fight For $1,000,000!', '5', 'video', 'VibeStream', '2026-10-11 18:30:31', '0', '1', 'VibeStream', 'https://www.youtube.com/watch?v=QJI0an6irrA', '0', 'gaming'),
('MO1j8vJHKNl', 'Making a song in the style of…', '15', 'short', 'aqsa', '2026-10-09 22:39:54', '3', '2', 'aqsa', 'https://www.youtube.com/watch?v=WFXPeguh3lk', '0', 'music'),
('MUiqU20kGZ5', 'Is Charging While Using Your Phone Killing the Battery?', '9', 'video', 'VibeStream', '2026-10-11 18:40:29', '1', '1', 'VibeStream', 'https://www.youtube.com/watch?v=Lj4LMlGr4og', '0', 'facts'),
('nuTUjH70f8g', 'Microsoft Showed Me Their Secret Phone Five Years Ago.', '2', 'video', 'VibeStream', '2026-10-11 18:19:06', '0', '1', 'VibeStream', 'https://www.youtube.com/watch?v=RxW7PXKkztQ', '0', 'facts'),
('RUP0hxEsgBl', '$10,000 Every Day You Survive In Minecraft', '7', 'video', 'VibeStream', '2026-10-11 18:33:54', '1', '1', 'VibeStream', 'https://www.youtube.com/watch?v=h8VE9_aHd94', '0', 'gaming');

-- ----------------------------
-- Table `vs_comment_votes`
-- ----------------------------
DROP TABLE IF EXISTS `vs_comment_votes`;
CREATE TABLE `vs_comment_votes` (
  `comment_id` bigint(20) unsigned NOT NULL,
  `voter` varchar(191) NOT NULL,
  `vote` tinyint(4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`comment_id`,`voter`),
  KEY `idx_vs_comment_votes_voter` (`voter`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `vs_comment_votes` (`comment_id`, `voter`, `vote`, `created_at`) VALUES
('28', 'adminawais', '1', '2026-10-10 12:44:31'),
('31', 'adminawais', '1', '2026-10-10 12:44:29'),
('32', 'adminawais', '1', '2026-10-10 12:44:28'),
('33', 'adminawais', '1', '2026-10-10 12:44:27'),
('33', 'instant', '-1', '2026-10-10 12:36:21'),
('38', 'vibestream', '1', '2026-10-17 19:34:11');

-- ----------------------------
-- Table `watch_history`
-- ----------------------------
DROP TABLE IF EXISTS `watch_history`;
CREATE TABLE `watch_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `video_id` varchar(64) NOT NULL,
  `watched_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_watch_history_user_video` (`user_id`,`video_id`),
  KEY `idx_watch_history_user_time` (`user_id`,`watched_at`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `watch_history` (`id`, `user_id`, `video_id`, `watched_at`) VALUES
('2', '9', 'rqcUKdldcNy', '2026-10-10 01:32:42'),
('3', '9', 'IFUtsXdwk-A', '2026-10-10 01:23:20'),
('4', '9', 'M5es7CsVsak', '2026-10-10 01:32:35'),
('6', '9', '6nvdR8clMIk', '2026-10-10 01:31:46'),
('9', '10', '6nvdR8clMIk', '2026-10-10 01:38:00'),
('10', '10', 'IFUtsXdwk-A', '2026-10-10 01:39:57'),
('30', '1', 'IFUtsXdwk-A', '2026-10-10 12:44:02'),
('31', '12', 'BHZcLwxyeM', '2026-10-10 14:03:57'),
('32', '12', 'rqcUKdldcNy', '2026-10-10 14:03:58'),
('33', '12', 'MO1j8vJHKNl', '2026-10-10 14:03:59'),
('34', '12', '-4BzpL7pcnj', '2026-10-10 14:03:59'),
('35', '12', '4ZLZUhJHbW0', '2026-10-10 14:03:56'),
('36', '12', '5ABfNhJvTTs', '2026-10-10 14:03:56'),
('41', '12', 'TQ671jx2LHK', '2026-10-11 00:25:50'),
('59', '15', 'gXeE57uu-Kw', '2026-10-11 21:10:46'),
('60', '15', 'rqcUKdldcNy', '2026-10-11 21:10:50'),
('61', '15', 'MO1j8vJHKNl', '2026-10-11 21:10:50'),
('62', '15', '-4BzpL7pcnj', '2026-10-11 21:10:50'),
('63', '15', '4ZLZUhJHbW0', '2026-10-11 21:10:51'),
('64', '15', '5ABfNhJvTTs', '2026-10-11 21:10:51'),
('73', '15', '6lrPGbgxpQr', '2026-10-11 21:42:34'),
('120', '14', '6lrPGbgxpQr', '2026-10-24 21:08:51'),
('121', '14', '5ABfNhJvTTs', '2026-10-27 22:34:25'),
('122', '14', 'MUiqU20kGZ5', '2026-10-27 22:20:24'),
('124', '14', 'MO1j8vJHKNl', '2026-10-27 22:55:10'),
('125', '14', 'RUP0hxEsgBl', '2026-10-24 21:09:00'),
('129', '14', '-4BzpL7pcnj', '2026-10-25 01:08:32'),
('130', '14', '4ZLZUhJHbW0', '2026-10-24 22:45:16'),
('136', '14', 'nuTUjH70f8g', '2026-10-27 22:55:11'),
('138', '14', 'BhAczqf1ci9', '2026-10-27 22:34:28');

-- ----------------------------
-- Table `watch_history_prefs`
-- ----------------------------
DROP TABLE IF EXISTS `watch_history_prefs`;
CREATE TABLE `watch_history_prefs` (
  `user_id` int(11) NOT NULL,
  `paused` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `watch_history_prefs` (`user_id`, `paused`) VALUES
('14', '0');

-- ----------------------------
-- Table `watch_later_items`
-- ----------------------------
DROP TABLE IF EXISTS `watch_later_items`;
CREATE TABLE `watch_later_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `video_id` varchar(191) NOT NULL,
  `video_key` char(64) NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `added_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_watch_later_user_video` (`username`,`video_key`),
  KEY `idx_watch_later_user_order` (`username`,`sort_order`,`added_at`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `watch_later_items` (`id`, `username`, `video_id`, `video_key`, `sort_order`, `added_at`) VALUES
('29', 'VibeStream', 'RUP0hxEsgBl', '2d0a650e67af3bbb82ce7610c862be9fac27b55cf49505ae2af2c9db19b7c137', '0', '2026-10-22 17:44:28');

-- ----------------------------
-- Triggers
-- ----------------------------
DELIMITER $$
DROP TRIGGER IF EXISTS `vs_users_lock_insert`$$
CREATE TRIGGER vs_users_lock_insert BEFORE INSERT ON `users` FOR EACH ROW
                 BEGIN
                   IF LOWER(TRIM(NEW.`email`)) = 'muhammadawaiscom0@gmail.com' THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'That email belongs to the owner.';
                   END IF;
                 END$$
DROP TRIGGER IF EXISTS `vs_users_lock_update`$$
CREATE TRIGGER vs_users_lock_update BEFORE UPDATE ON `users` FOR EACH ROW
                 BEGIN
                   IF OLD.`id` = '14' AND (COALESCE(LOWER(TRIM(NEW.`role`)), '') <> 'admin' OR COALESCE(LOWER(TRIM(NEW.`email`)), '') <> 'muhammadawaiscom0@gmail.com') THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The owner account cannot be changed this way.';
                   END IF;
                   IF OLD.`id` <> '14' AND LOWER(TRIM(NEW.`email`)) = 'muhammadawaiscom0@gmail.com' THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'That email belongs to the owner.';
                   END IF;
                   IF LOWER(TRIM(OLD.`role`)) = 'admin' AND COALESCE(LOWER(TRIM(NEW.`role`)), '') <> 'admin' AND COALESCE(@vs_owner_ok, 0) <> 1 THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only the owner can remove admin access.';
                   END IF;
                 END$$
DROP TRIGGER IF EXISTS `vs_users_lock_delete`$$
CREATE TRIGGER vs_users_lock_delete BEFORE DELETE ON `users` FOR EACH ROW
                 BEGIN
                   IF OLD.`id` = '14' THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The owner account cannot be deleted.';
                   END IF;
                   IF LOWER(TRIM(OLD.`role`)) = 'admin' AND COALESCE(@vs_owner_ok, 0) <> 1 THEN
                     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only the owner can delete admin accounts.';
                   END IF;
                 END$$
DELIMITER ;

SET FOREIGN_KEY_CHECKS=1;
-- End of backup
